"""Five-primitive A1 controller with a contact-triggered jump in place of pronk."""
import torch

from .contact_jump_reflex_probe import ContactJumpReflex
from .equilibrium_dynamics import AdaptiveEquilibriumDynamics
from .rhythmic_dynamics import Interoceptive_Reflex_Dynamics


class JumpAdaptiveEquilibriumDynamics(AdaptiveEquilibriumDynamics):
    """Keep the 18 continuous actions; the fifth discrete choice arms one jump.

    The four locomotion gaits use the existing trajectories. Jump selection
    arms a one-shot reflex; contact and leg phase start it. Another selection
    requires leaving jump after recovery, so repeated gaps can be attempted.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.primitive_names = (*self.primitive_names[:4], 'jump')
        self.primitive_dict[4] = list(self.primitive_dict[3])
        self.primitive_duty_factors[4] = self.primitive_duty_factors[3]
        self.primitive_frequencies.pop('pronk')
        self.primitive_frequencies['jump'] = self.primitive_frequencies['bound']
        self._primitive_phases[4].copy_(self._primitive_phases[3])
        self._primitive_duty_factors[4] = self._primitive_duty_factors[3]
        self._primitive_frequencies[4] = self._primitive_frequencies[3]
        self.jump_reflex = ContactJumpReflex(
            self.num_envs, self._device, self._dt,
            robot_height=self._robot_height)
        self.jump_selected_prev = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self._device)

    def _foot_trajectory(self, command, vertical_phase):
        # Multi_Primitive_Dynamics adds the periodic pronk trajectory for ID 4.
        # The ordinary trajectory is the support gait until the reflex starts.
        return Interoceptive_Reflex_Dynamics._foot_trajectory(
            self, command, vertical_phase)

    @torch.no_grad()
    def reset(self, env_ids):
        super().reset(env_ids)
        if hasattr(self, 'jump_reflex'):
            self.jump_reflex.reset(env_ids)
            self.jump_selected_prev[env_ids] = False

    @torch.no_grad()
    def intrinsic_dynamics(self, actions, command, foot_contact=None,
                           contact_forces=None):
        if actions.shape != (self.num_envs, self.NUM_ACTIONS):
            raise ValueError('jump controller actions must have shape [num_envs, 19]')
        selected = actions[:, 0] == 4
        released = ~selected & (self.jump_reflex.state == ContactJumpReflex.IDLE)
        self.jump_reflex.completed[released] = False
        self.jump_reflex.arm(selected & ~self.jump_selected_prev)
        self.jump_selected_prev.copy_(selected)

        x, y, z = super().intrinsic_dynamics(
            actions, command, foot_contact=foot_contact,
            contact_forces=contact_forces)
        if contact_forces is not None:
            forces = contact_forces
        elif foot_contact is not None:
            forces = foot_contact.to(dtype=z.dtype) * 20.
        else:
            forces = torch.zeros_like(z)
        z = self.jump_reflex.step(z, forces, self._vertical_phase())
        self.z = z
        return x, y, z

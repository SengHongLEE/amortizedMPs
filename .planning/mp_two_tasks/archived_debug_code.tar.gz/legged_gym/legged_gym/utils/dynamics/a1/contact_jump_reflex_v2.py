"""Contact-triggered transient with coordinated sagittal and vertical feet."""
import torch

from .contact_jump_reflex_probe import ContactJumpReflex


class ContactJumpReflexV2(ContactJumpReflex):
    """One-shot preload, support-foot thrust, tuck and landing blend.

    ``step`` accepts and returns hip-frame foot x/z targets in FL/FR/RL/RR
    order. Only feet contacting at launch push against the ground.
    """

    def __init__(self, num_envs, device, dt, robot_height=.30,
                 preload_depth=.04, extension_depth=.08,
                 preload_time=.05, push_time=.10, min_push_time=.04,
                 max_push_time=.18, flight_clearance=.13,
                 tuck_time=.055, min_flight_time=.07,
                 max_flight_time=.45, recover_time=.15,
                 trigger_hold=.005, contact_hold=.005,
                 armed_timeout=.6, front_push_stroke=.05,
                 hind_push_stroke=.07, free_foot_advance=.04,
                 flight_foot_advance=.06, landing_deploy_delay=.10,
                 landing_deploy_time=.07, landing_depth=.30,
                 front_landing_x=.12, hind_landing_x=.10,
                 fresh_support_trigger=False, landing_min_contacts=1):
        super().__init__(
            num_envs, device, dt, robot_height=robot_height,
            preload_depth=preload_depth,
            extension_depth=extension_depth,
            preload_time=preload_time, push_time=push_time,
            min_push_time=min_push_time, max_push_time=max_push_time,
            flight_clearance=flight_clearance, tuck_time=tuck_time,
            min_flight_time=min_flight_time, max_flight_time=max_flight_time,
            recover_time=recover_time, trigger_hold=trigger_hold,
            contact_hold=contact_hold, armed_timeout=armed_timeout)
        self.push_stroke = torch.tensor(
            [front_push_stroke, front_push_stroke,
             hind_push_stroke, hind_push_stroke],
            device=device)
        self.free_foot_advance = free_foot_advance
        self.flight_foot_advance = flight_foot_advance
        self.landing_deploy_delay = landing_deploy_delay
        self.landing_deploy_time = landing_deploy_time
        self.landing_depth = landing_depth
        self.landing_x = torch.tensor(
            [front_landing_x, front_landing_x,
             hind_landing_x, hind_landing_x], device=device)
        self.fresh_support_trigger = bool(fresh_support_trigger)
        if landing_min_contacts not in (1, 2, 3, 4):
            raise ValueError('landing_min_contacts must be an integer in [1, 4]')
        self.landing_min_contacts = landing_min_contacts
        self.seen_support_break = torch.zeros(
            num_envs, dtype=torch.bool, device=device)
        self.latched_push_stroke = self.push_stroke[None].repeat(num_envs, 1)
        self.latched_extension_depth = torch.full(
            (num_envs, 1), self.extension_depth, device=device)
        self.latched_tuck_clearance = torch.full(
            (num_envs, 1), self.flight_clearance, device=device)
        self.latched_deploy_delay = torch.full(
            (num_envs, 1), self.landing_deploy_delay, device=device)
        self.latched_landing_x = self.landing_x[None].repeat(num_envs, 1)
        self.latched_push_time = torch.full(
            (num_envs, 1), self.push_time, device=device)
        self.support_mask = torch.zeros(num_envs, 4, dtype=torch.bool,
                                        device=device)
        self.start_x = torch.zeros(num_envs, 4, device=device)
        self.push_start_x = torch.zeros_like(self.start_x)
        self.push_start_z = torch.zeros_like(self.start_x)
        self.flight_start_x = torch.zeros_like(self.start_x)
        self.flight_target_x = torch.zeros_like(self.start_x)
        self.recover_start_x = torch.zeros_like(self.start_x)

    @torch.no_grad()
    def reset(self, env_ids):
        super().reset(env_ids)
        self.support_mask[env_ids] = False
        self.seen_support_break[env_ids] = False
        self.latched_push_stroke[env_ids] = self.push_stroke
        self.latched_extension_depth[env_ids] = self.extension_depth
        self.latched_tuck_clearance[env_ids] = self.flight_clearance
        self.latched_deploy_delay[env_ids] = self.landing_deploy_delay
        self.latched_landing_x[env_ids] = self.landing_x
        self.latched_push_time[env_ids] = self.push_time
        for name in ('start_x', 'push_start_x', 'push_start_z',
                     'flight_start_x', 'flight_target_x',
                     'recover_start_x'):
            getattr(self, name)[env_ids] = 0.

    @torch.no_grad()
    def arm(self, mask):
        mask = torch.as_tensor(mask, device=self.device, dtype=torch.bool)
        start = mask & (self.state == self.IDLE) & ~self.completed
        super().arm(mask)
        self.seen_support_break[start] = False

    @torch.no_grad()
    def step(self, base_x, base_z, contact_forces, modulation=None):
        if (base_x.shape != (self.num_envs, 4)
                or base_z.shape != base_x.shape
                or contact_forces.shape != base_x.shape):
            raise ValueError('foot x, z and contact forces must be [num_envs,4]')
        if modulation is not None and modulation.shape != (self.num_envs, 6):
            raise ValueError('jump modulation must be [num_envs,6]')
        contact = contact_forces > 5.
        qualified = ((contact.sum(-1) >= 2) & contact[:, 2:].any(-1))
        if self.fresh_support_trigger:
            self.seen_support_break |= ((self.state == self.ARMED)
                                        & ~qualified)
        self.trigger_streak = torch.where(
            qualified, self.trigger_streak + self.dt, 0.)
        all_off = (contact_forces < 1.).all(-1)
        self.off_streak = torch.where(
            all_off, self.off_streak + self.dt, 0.)
        self.landing_streak = torch.where(
            contact.sum(-1) >= self.landing_min_contacts,
            self.landing_streak + self.dt, 0.)

        trigger = ((self.state == self.ARMED)
                   & (self.trigger_streak >= self.trigger_hold))
        if self.fresh_support_trigger:
            trigger &= self.seen_support_break
        self.state[trigger] = self.PRELOAD
        self.elapsed[trigger] = 0.
        self.start_x[trigger] = base_x[trigger]
        self.start_z[trigger] = base_z[trigger]
        self.support_mask[trigger] = contact[trigger]
        self.launch_events += trigger.long()
        self.latched_push_stroke[trigger] = self.push_stroke
        self.latched_extension_depth[trigger] = self.extension_depth
        self.latched_tuck_clearance[trigger] = self.flight_clearance
        self.latched_deploy_delay[trigger] = self.landing_deploy_delay
        self.latched_landing_x[trigger] = self.landing_x
        self.latched_push_time[trigger] = self.push_time
        if modulation is not None and trigger.any():
            m = modulation[trigger].clamp(-1., 1.)
            self.latched_push_stroke[trigger] *= 1. + .5 * m[:, 0:1]
            self.latched_extension_depth[trigger] = .08 + .04 * m[:, 1:2]
            self.latched_deploy_delay[trigger] = .20 + .10 * m[:, 2:3]
            self.latched_landing_x[trigger] += .05 * m[:, 3:4]
            self.latched_tuck_clearance[trigger] = .13 + .04 * m[:, 4:5]
            self.latched_push_time[trigger] = .06 + .02 * m[:, 5:6]

        support = self.support_mask
        preload_z = base_z.new_full(base_z.shape,
                                    -self.robot_height + self.preload_depth)
        extension_z = -self.robot_height - self.latched_extension_depth
        tuck_z = -self.robot_height + self.latched_tuck_clearance
        age = self.elapsed[:, None]

        preload_progress = self._smooth(age / self.preload_time)
        preload_x_target = torch.where(
            support, self.start_x,
            (self.start_x + self.free_foot_advance).clamp(-.18, .18))
        preload_z_target = torch.where(support, preload_z, tuck_z)
        preload_x = self.start_x + preload_progress * (
            preload_x_target - self.start_x)
        preload_z_out = self.start_z + preload_progress * (
            preload_z_target - self.start_z)

        push_progress = self._smooth(age / self.latched_push_time)
        push_x_target = torch.where(
            support,
            (self.push_start_x - self.latched_push_stroke).clamp(-.18, .18),
            self.push_start_x)
        push_z_target = torch.where(support, extension_z, tuck_z)
        push_x = self.push_start_x + push_progress * (
            push_x_target - self.push_start_x)
        push_z = self.push_start_z + push_progress * (
            push_z_target - self.push_start_z)

        flight_progress = self._smooth(age / self.tuck_time)
        flight_x = self.flight_start_x + flight_progress * (
            self.flight_target_x - self.flight_start_x)
        flight_z = self.flight_start_z + flight_progress * (
            tuck_z - self.flight_start_z)
        deploy_progress = self._smooth(
            (age - self.latched_deploy_delay) / self.landing_deploy_time)
        flight_x = flight_x + deploy_progress * (
            self.latched_landing_x - flight_x)
        flight_z = flight_z + deploy_progress * (
            -self.landing_depth - flight_z)

        recover_progress = self._smooth(age / self.recover_time)
        recover_x = self.recover_start_x + recover_progress * (
            base_x - self.recover_start_x)
        recover_z = self.recover_start_z + recover_progress * (
            base_z - self.recover_start_z)

        x, z = base_x, base_z
        for stage, stage_x, stage_z in (
                (self.PRELOAD, preload_x, preload_z_out),
                (self.PUSH, push_x, push_z),
                (self.FLIGHT, flight_x, flight_z),
                (self.RECOVER, recover_x, recover_z)):
            active = (self.state == stage)[:, None]
            x = torch.where(active, stage_x, x)
            z = torch.where(active, stage_z, z)
        active = ((self.state == self.PRELOAD)
                  | (self.state == self.PUSH)
                  | (self.state == self.FLIGHT)
                  | (self.state == self.RECOVER))[:, None]
        x = torch.where(active, x.clamp(-.18, .18), x)
        z = torch.where(active, z.clamp(-.39, -.12), z)

        self.elapsed += self.dt
        preload_done = ((self.state == self.PRELOAD)
                        & (self.elapsed >= self.preload_time))
        self.push_start_x[preload_done] = x[preload_done]
        self.push_start_z[preload_done] = z[preload_done]
        self.state[preload_done] = self.PUSH
        self.elapsed[preload_done] = 0.

        took_off = ((self.state == self.PUSH)
                    & (self.elapsed >= self.min_push_time)
                    & (self.off_streak >= self.contact_hold))
        self.flight_start_x[took_off] = x[took_off]
        self.flight_start_z[took_off] = z[took_off]
        self.flight_target_x[took_off] = (
            x[took_off] + self.flight_foot_advance).clamp(-.12, .12)
        self.state[took_off] = self.FLIGHT
        self.elapsed[took_off] = 0.
        self.flight_events += took_off.long()

        push_timeout = ((self.state == self.PUSH)
                        & (self.elapsed >= self.max_push_time))
        self.recover_start_x[push_timeout] = x[push_timeout]
        self.recover_start_z[push_timeout] = z[push_timeout]
        self.state[push_timeout] = self.RECOVER
        self.elapsed[push_timeout] = 0.
        self.failed_launches += push_timeout.long()

        landed = ((self.state == self.FLIGHT)
                  & (self.elapsed >= self.min_flight_time)
                  & (self.landing_streak >= self.contact_hold))
        flight_timeout = ((self.state == self.FLIGHT)
                          & (self.elapsed >= self.max_flight_time))
        recovering = landed | flight_timeout
        self.recover_start_x[recovering] = x[recovering]
        self.recover_start_z[recovering] = z[recovering]
        self.state[recovering] = self.RECOVER
        self.elapsed[recovering] = 0.
        self.landing_events += landed.long()

        recovered = ((self.state == self.RECOVER)
                     & (self.elapsed >= self.recover_time))
        self.state[recovered] = self.IDLE
        self.elapsed[recovered] = 0.
        self.completed |= recovered

        timed_out = ((self.state == self.ARMED)
                     & (self.elapsed >= self.armed_timeout))
        self.state[timed_out] = self.IDLE
        self.elapsed[timed_out] = 0.
        self.completed |= timed_out
        return x, z

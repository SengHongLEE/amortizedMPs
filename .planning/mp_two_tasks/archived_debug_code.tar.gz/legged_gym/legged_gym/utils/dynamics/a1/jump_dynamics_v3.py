"""Isolated five-primitive controller with continuous jump modulation."""
import torch

from .contact_jump_reflex_v3 import ContactJumpReflexV3
from .equilibrium_dynamics import AdaptiveEquilibriumDynamics
from .jump_dynamics_v2 import JumpAdaptiveEquilibriumDynamicsV2


class JumpAdaptiveEquilibriumDynamicsV3(JumpAdaptiveEquilibriumDynamicsV2):
    """Use the same 19 actions; six summaries shape each contact jump."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.jump_reflex = ContactJumpReflexV3(
            self.num_envs, self._device, self._dt,
            robot_height=self._robot_height)

    @staticmethod
    def jump_modulation(actions):
        if actions.ndim != 2 or actions.shape[1] != 19:
            raise ValueError('V3 jump actions must have 19 columns')
        return torch.stack((
            actions[:, 1:5].mean(-1),
            actions[:, 5:9].mean(-1),
            actions[:, 9:13].mean(-1),
            actions[:, 13:17].mean(-1),
            actions[:, 17], actions[:, 18],
        ), dim=-1).clamp(-1., 1.)

    @staticmethod
    def support_actions(actions, previous_gait):
        if actions.ndim != 2 or actions.shape[1] != 19:
            raise ValueError('V3 jump actions must have 19 columns')
        support = actions.clone()
        selected = actions[:, 0] == 4
        support[selected, 0] = previous_gait[selected].clamp(0, 3).to(
            actions.dtype)
        return support

    @torch.no_grad()
    def intrinsic_dynamics(self, actions, command, foot_contact=None,
                           contact_forces=None):
        if actions.shape != (self.num_envs, self.NUM_ACTIONS):
            raise ValueError('V3 jump actions must have shape [num_envs,19]')
        selected = actions[:, 0] == 4
        released = ~selected & (self.jump_reflex.state == ContactJumpReflexV3.IDLE)
        self.jump_reflex.completed[released] = False
        self.jump_reflex.arm(selected & ~self.jump_selected_prev)
        self.jump_selected_prev.copy_(selected)

        support_actions = self.support_actions(actions, self._gait_ids)
        x, y, z = AdaptiveEquilibriumDynamics.intrinsic_dynamics(
            self, support_actions, command, foot_contact=foot_contact,
            contact_forces=contact_forces)
        if contact_forces is not None:
            forces = contact_forces
        elif foot_contact is not None:
            forces = foot_contact.to(dtype=z.dtype) * 20.
        else:
            forces = torch.zeros_like(z)
        x, z = self.jump_reflex.step(
            x, z, forces, self.jump_modulation(actions))
        self.x = x
        self.z = z
        return x, y, z

"""Isolated jump preparation from equilibrium motion and robot state."""
import math
import torch

from .contact_jump_reflex_v3 import ContactJumpReflexV3
from .equilibrium_dynamics import AdaptiveEquilibriumDynamics


class IntrinsicJumpDetector:
    """Emit one-shot gap/hurdle events without height maps or actor-side flags.

    Event 1 is a sharp lowering of the front-foot equilibrium target. Event 2
    is a forward-facing front-foot obstacle impulse. Targets and force vectors
    are physical controller inputs already available at each physics step.
    """

    NONE, GAP, HURDLE_CONTACT, HURDLE_PREPARE = range(4)

    def __init__(self, num_envs, device, dt, cooldown=.35,
                 front_x_limit=.07, rear_x_range=(-.07, -.02)):
        self.num_envs = num_envs
        self.device = device
        self.dt = float(dt)
        self.cooldown = float(cooldown)
        self.front_x_prepare = .56 * float(front_x_limit)
        self.rear_x_prepare = (float(rear_x_range[0])
                               + .62 * (float(rear_x_range[1])
                                        - float(rear_x_range[0])))
        self.previous_front_z = torch.zeros(num_envs, device=device)
        self.front_z_slow = torch.zeros(num_envs, device=device)
        self.rear_z_slow = torch.zeros(num_envs, device=device)
        self.trend_rate = -math.expm1(-self.dt / .10)
        self.previous_collision = torch.zeros(num_envs, dtype=torch.bool, device=device)
        self.previous_hurdle_pattern = torch.zeros(
            num_envs, dtype=torch.bool, device=device)
        self.enable_hurdle_contact = True
        self.enable_hurdle_prepare = True
        self.elapsed = torch.zeros(num_envs, device=device)
        self.since_event = torch.full((num_envs,), self.cooldown, device=device)
        # Count policy-generated trigger candidates across the 1 ms physics
        # steps so a 20 ms training reward cannot miss their one-shot pulses.
        self.raw_trigger_counts = torch.zeros(
            num_envs, 2, dtype=torch.long, device=device)
        self.accepted_trigger_counts = torch.zeros_like(self.raw_trigger_counts)

    @torch.no_grad()
    def reset(self, env_ids):
        ids = torch.as_tensor(env_ids, dtype=torch.long, device=self.device).flatten()
        self.previous_front_z[ids] = 0.
        self.front_z_slow[ids] = 0.
        self.rear_z_slow[ids] = 0.
        self.previous_collision[ids] = False
        self.previous_hurdle_pattern[ids] = False
        self.elapsed[ids] = 0.
        self.since_event[ids] = self.cooldown
        self.raw_trigger_counts[ids] = 0
        self.accepted_trigger_counts[ids] = 0

    @torch.no_grad()
    def consume_trigger_counts(self):
        raw = self.raw_trigger_counts.clone()
        accepted = self.accepted_trigger_counts.clone()
        self.raw_trigger_counts.zero_()
        self.accepted_trigger_counts.zero_()
        return raw, accepted

    @torch.no_grad()
    def step(self, equilibrium_z_target, foot_forces_xyz, ready,
             equilibrium_x_target=None, frequency_scale=None):
        if equilibrium_z_target.shape != (self.num_envs, 4):
            raise ValueError('equilibrium_z_target must have shape [num_envs, 4]')
        if foot_forces_xyz.shape != (self.num_envs, 4, 3):
            raise ValueError('foot_forces_xyz must have shape [num_envs, 4, 3]')
        if ready.shape != (self.num_envs,):
            raise ValueError('ready must have shape [num_envs]')
        if equilibrium_x_target is not None and equilibrium_x_target.shape != (self.num_envs, 4):
            raise ValueError('equilibrium_x_target must have shape [num_envs, 4]')
        if frequency_scale is not None and frequency_scale.shape != (self.num_envs, 1):
            raise ValueError('frequency_scale must have shape [num_envs, 1]')

        # The existing locomotion policy responds first with FL; averaging FR
        # masks this edge event because FR also carries independent balance.
        front_z = equilibrium_z_target[:, 0]
        rear_z = equilibrium_z_target[:, 2:].mean(-1)
        collision = (foot_forces_xyz[:, :2, 0] < -120.).any(-1)
        fresh_collision = collision & ~self.previous_collision
        front_drop = ((self.previous_front_z > .016)
                      & (front_z < .016)
                      & (front_z - self.previous_front_z < -.012))
        if equilibrium_x_target is None or frequency_scale is None:
            hurdle_pattern = torch.zeros_like(collision)
        else:
            hurdle_pattern = (
                (rear_z > .0295)
                & (equilibrium_x_target[:, :2].mean(-1) > self.front_x_prepare)
                & (equilibrium_x_target[:, 3] < self.rear_x_prepare)
                & (frequency_scale[:, 0] > 1.082)
                & (front_z < .028)
                & (front_z - self.front_z_slow > .0003)
                & (rear_z - self.rear_z_slow < .001))
        self.raw_trigger_counts[:, 0] += front_drop.long()
        self.raw_trigger_counts[:, 1] += (
            hurdle_pattern & ~self.previous_hurdle_pattern).long()
        eligible = ready & (self.since_event >= self.cooldown)
        event = torch.zeros(self.num_envs, dtype=torch.long, device=self.device)
        event[eligible & front_drop] = self.GAP
        if self.enable_hurdle_prepare:
            event[eligible & hurdle_pattern & ~self.previous_hurdle_pattern
                  & (self.elapsed > .4)] = self.HURDLE_PREPARE
        if self.enable_hurdle_contact:
            event[eligible & fresh_collision] = self.HURDLE_CONTACT
        self.accepted_trigger_counts[:, 0] += (event == self.GAP).long()
        self.accepted_trigger_counts[:, 1] += (
            (event == self.HURDLE_CONTACT)
            | (event == self.HURDLE_PREPARE)).long()
        self.since_event += self.dt
        self.elapsed += self.dt
        self.since_event[event != self.NONE] = 0.
        self.previous_front_z.copy_(front_z)
        self.front_z_slow.lerp_(front_z, self.trend_rate)
        self.rear_z_slow.lerp_(rear_z, self.trend_rate)
        # A collision seen while another maneuver is active remains available
        # if contact is still present when the controller becomes ready.
        self.previous_collision.copy_(collision & ready)
        self.previous_hurdle_pattern.copy_(hurdle_pattern)
        return event


class DynamicsOnlyJumpDynamics(AdaptiveEquilibriumDynamics):
    """Experimental four-gait controller with a state-triggered jump overlay."""

    def __init__(self, gap_runup_distance=.10,
                 gap_landing_x_modulation=None,
                 gap_speed_landing_shift=0., **kwargs):
        super().__init__(**kwargs)
        if not math.isfinite(gap_runup_distance) or gap_runup_distance < 0.:
            raise ValueError('gap_runup_distance must be finite and nonnegative')
        self.gap_runup_distance = float(gap_runup_distance)
        if (gap_landing_x_modulation is not None
                and (not math.isfinite(gap_landing_x_modulation)
                     or not -1. <= gap_landing_x_modulation <= 1.)):
            raise ValueError('gap_landing_x_modulation must be in [-1, 1]')
        self.gap_landing_x_modulation = gap_landing_x_modulation
        if (not math.isfinite(gap_speed_landing_shift)
                or not 0. <= gap_speed_landing_shift <= .12):
            raise ValueError('gap_speed_landing_shift must be in [0, 0.12] metres')
        self.gap_speed_landing_shift = float(gap_speed_landing_shift)
        self.pending_gap = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self._device)
        self.gap_runup = torch.zeros(self.num_envs, device=self._device)
        self.gap_wait_age = torch.zeros_like(self.gap_runup)
        self.jump_detector = IntrinsicJumpDetector(
            self.num_envs, self._device, self._dt,
            front_x_limit=float(self.offset_limits[0]),
            rear_x_range=self.rear_x_offset_range)
        self.jump_reflex = ContactJumpReflexV3(
            self.num_envs, self._device, self._dt,
            robot_height=self._robot_height)
        self.pending_jump_kind = torch.zeros(
            self.num_envs, dtype=torch.long, device=self._device)
        self.launch_kind_counts = torch.zeros(
            self.num_envs, 2, dtype=torch.long, device=self._device)
        self.jump_modulation = torch.tensor(
            [1., 0., -.5, 1., 1., -1.], device=self._device)
        # The reactive contact launch lost forward speed in the first paired
        # hurdle probe. Keep the detector event for diagnostics, but use the
        # predictive equilibrium event for jump arming.
        self.enable_reactive_hurdle = False

    @torch.no_grad()
    def reset(self, env_ids):
        super().reset(env_ids)
        if hasattr(self, 'jump_detector'):
            self.jump_detector.reset(env_ids)
            self.jump_reflex.reset(env_ids)
            self.pending_jump_kind[env_ids] = IntrinsicJumpDetector.NONE
            self.pending_gap[env_ids] = False
            self.gap_runup[env_ids] = 0.
            self.gap_wait_age[env_ids] = 0.
            self.launch_kind_counts[env_ids] = 0

    @torch.no_grad()
    def consume_launch_counts(self):
        launched = self.launch_kind_counts.clone()
        self.launch_kind_counts.zero_()
        return launched

    @torch.no_grad()
    def intrinsic_dynamics(self, actions, command, foot_contact=None,
                           contact_forces=None, foot_forces_xyz=None,
                           base_velocity_x=None):
        if (base_velocity_x is not None
                and base_velocity_x.shape != (self.num_envs,)):
            raise ValueError('base_velocity_x must have shape [num_envs]')
        if foot_forces_xyz is not None:
            if foot_forces_xyz.shape != (self.num_envs, 4, 3):
                raise ValueError('foot_forces_xyz must have shape [num_envs, 4, 3]')
            magnitudes = torch.linalg.vector_norm(foot_forces_xyz, dim=-1)
            if foot_contact is not None or contact_forces is not None:
                raise ValueError('pass either foot_forces_xyz or another contact input')
            contact_forces = magnitudes
        else:
            foot_forces_xyz = torch.zeros(
                self.num_envs, 4, 3, device=self._device)

        x, y, z = super().intrinsic_dynamics(
            actions, command, foot_contact=foot_contact,
            contact_forces=contact_forces)
        if contact_forces is None:
            if foot_contact is not None:
                contact_forces = foot_contact.to(z.dtype) * 20.
            else:
                contact_forces = torch.zeros_like(z)

        # Only gaits with measured gap or hurdle capability may start a jump.
        # The periodic phase still advances for every gait and during an
        # already-started reflex.
        capable_gait = ((self._gait_ids == 1) | (self._gait_ids == 2))
        self.pending_gap[~capable_gait] = False
        ready = ((self.jump_reflex.state == self.jump_reflex.IDLE)
                 & ~self.pending_gap & capable_gait)
        self.jump_detector.enable_hurdle_contact = self.enable_reactive_hurdle
        events = self.jump_detector.step(
            self.offset_target[:, :, 2], foot_forces_xyz, ready,
            self.offset_target[:, :, 0], self.frequency_scale)
        arm_events = events.clone()
        if base_velocity_x is not None and self.gap_runup_distance > 0.:
            fresh_gap = events == IntrinsicJumpDetector.GAP
            self.pending_gap[fresh_gap] = True
            self.gap_runup[fresh_gap] = 0.
            self.gap_wait_age[fresh_gap] = 0.
            arm_events[fresh_gap] = IntrinsicJumpDetector.NONE
            self.gap_runup[self.pending_gap] += (
                base_velocity_x[self.pending_gap].clamp(0., 4.) * self._dt)
            self.gap_wait_age[self.pending_gap] += self._dt
            matured = self.pending_gap & (
                self.gap_runup >= self.gap_runup_distance)
            timed_out = self.pending_gap & (self.gap_wait_age >= .5)
            arm_events[matured] = IntrinsicJumpDetector.GAP
            self.pending_gap[matured | timed_out] = False
        armed = arm_events != IntrinsicJumpDetector.NONE
        self.pending_jump_kind[armed] = arm_events[armed]
        self.jump_reflex.completed[ready | armed] = False
        self.jump_reflex.arm(armed)
        launches_before = self.jump_reflex.launch_events.clone()
        modulation = self.jump_modulation[None].expand(self.num_envs, -1)
        if self.gap_landing_x_modulation is not None:
            modulation = modulation.clone()
            modulation[self.pending_jump_kind == IntrinsicJumpDetector.GAP, 3] = (
                self.gap_landing_x_modulation)
        x, z = self.jump_reflex.step(x, z, contact_forces, modulation)
        launched = self.jump_reflex.launch_events > launches_before
        gap_launch = launched & (self.pending_jump_kind == IntrinsicJumpDetector.GAP)
        if (self.gap_speed_landing_shift > 0.
                and base_velocity_x is not None and gap_launch.any()):
            speed_fraction = ((base_velocity_x[gap_launch] - 1.2) / .8).clamp(0., 1.)
            self.jump_reflex.latched_landing_x[gap_launch] -= (
                speed_fraction[:, None] * self.gap_speed_landing_shift)
        self.launch_kind_counts[:, 0] += (
            gap_launch).long()
        self.launch_kind_counts[:, 1] += (
            launched & ((self.pending_jump_kind == IntrinsicJumpDetector.HURDLE_CONTACT)
                        | (self.pending_jump_kind == IntrinsicJumpDetector.HURDLE_PREPARE))).long()
        hurdle_launch = (launched
                         & (self.pending_jump_kind == IntrinsicJumpDetector.HURDLE_CONTACT))
        self.jump_reflex.support_mask[hurdle_launch, :2] = False
        self.x, self.z = x, z
        return x, y, z

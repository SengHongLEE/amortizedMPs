"""Isolated five-primitive controller with coordinated x/z jump transient."""
import torch

from .contact_jump_reflex_v2 import ContactJumpReflexV2
from .equilibrium_dynamics import AdaptiveEquilibriumDynamics
from .jump_dynamics import JumpAdaptiveEquilibriumDynamics


class JumpAdaptiveEquilibriumDynamicsV2(JumpAdaptiveEquilibriumDynamics):
    """Replace the V1 vertical-only reflex while retaining the action space."""

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.jump_reflex = ContactJumpReflexV2(
            self.num_envs, self._device, self._dt,
            robot_height=self._robot_height)

    @torch.no_grad()
    def intrinsic_dynamics(self, actions, command, foot_contact=None,
                           contact_forces=None):
        if actions.shape != (self.num_envs, self.NUM_ACTIONS):
            raise ValueError('V2 jump actions must have shape [num_envs,19]')
        selected = actions[:, 0] == 4
        released = ~selected & (self.jump_reflex.state == ContactJumpReflexV2.IDLE)
        self.jump_reflex.completed[released] = False
        self.jump_reflex.arm(selected & ~self.jump_selected_prev)
        self.jump_selected_prev.copy_(selected)

        x, y, z = AdaptiveEquilibriumDynamics.intrinsic_dynamics(
            self, actions, command, foot_contact=foot_contact,
            contact_forces=contact_forces)
        if contact_forces is not None:
            forces = contact_forces
        elif foot_contact is not None:
            forces = foot_contact.to(dtype=z.dtype) * 20.
        else:
            forces = torch.zeros_like(z)
        x, z = self.jump_reflex.step(x, z, forces)
        self.x = x
        self.z = z
        return x, y, z

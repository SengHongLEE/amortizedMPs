"""One-shot jump selection layered over the four locomotion primitives."""
import torch
import torch.nn.functional as F

from .contact_jump_reflex_v3 import ContactJumpReflexV3
from .equilibrium_dynamics import AdaptiveEquilibriumDynamics


class OneShotJumpDynamics(AdaptiveEquilibriumDynamics):
    """ID 4 requests a latched jump; the prior gait supplies the base trajectory."""

    ACTION_SPACE = 'cpg_equilibrium_jump_v1'
    NUM_OBSERVATIONS = AdaptiveEquilibriumDynamics.NUM_OBSERVATIONS + 6

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.primitive_names = (*self.primitive_names[:4], 'jump')
        self.jump_reflex = ContactJumpReflexV3(
            self.num_envs, self._device, self._dt,
            robot_height=self._robot_height)
        self.jump_selected_prev = torch.zeros(
            self.num_envs, dtype=torch.bool, device=self._device)
        self._jump_events = {
            name: torch.zeros(self.num_envs, dtype=torch.long, device=self._device)
            for name in ('request', 'launch', 'flight', 'landed', 'failed')
        }

    @staticmethod
    def jump_modulation(actions):
        """Reuse the existing 18 continuous controls at jump launch."""
        if actions.ndim != 2 or actions.shape[1] != 19:
            raise ValueError('jump actions must have 19 columns')
        return torch.stack((
            actions[:, 1:5].mean(-1),
            actions[:, 5:9].mean(-1),
            actions[:, 9:13].mean(-1),
            actions[:, 13:17].mean(-1),
            actions[:, 17], actions[:, 18],
        ), dim=-1).clamp(-1., 1.)

    @torch.no_grad()
    def reset(self, env_ids):
        super().reset(env_ids)
        if hasattr(self, 'jump_reflex'):
            self.jump_reflex.reset(env_ids)
            self.jump_selected_prev[env_ids] = False
            for events in self._jump_events.values():
                events[env_ids] = 0

    @torch.no_grad()
    def consume_jump_events(self):
        events = {name: values.clone() for name, values in self._jump_events.items()}
        for values in self._jump_events.values():
            values.zero_()
        return events

    @torch.no_grad()
    def intrinsic_dynamics(self, actions, command, foot_contact=None,
                           contact_forces=None):
        if actions.shape != (self.num_envs, self.NUM_ACTIONS):
            raise ValueError('jump actions must have shape [num_envs,19]')
        gait = actions[:, 0]
        if not (torch.isfinite(gait) & (gait == gait.long())
                & (gait >= 0) & (gait <= 4)).all():
            raise ValueError('primitive IDs must be integers in [0,4]')
        selected = gait == 4
        idle = self.jump_reflex.state == self.jump_reflex.IDLE
        self.jump_reflex.completed[~selected & idle] = False
        requested = selected & ~self.jump_selected_prev & idle & ~self.jump_reflex.completed
        self.jump_reflex.arm(requested)
        self._jump_events['request'] += requested.long()
        self.jump_selected_prev.copy_(selected)

        support_actions = actions.clone()
        support_actions[selected, 0] = self._gait_ids[selected].to(actions.dtype)
        x, y, z = AdaptiveEquilibriumDynamics.intrinsic_dynamics(
            self, support_actions, command, foot_contact, contact_forces)
        if contact_forces is not None:
            forces = contact_forces
        elif foot_contact is not None:
            forces = foot_contact.to(dtype=z.dtype) * 20.
        else:
            forces = torch.zeros_like(z)
        before = {name: getattr(self.jump_reflex, field).clone() for name, field in (
            ('launch', 'launch_events'), ('flight', 'flight_events'),
            ('landed', 'landing_events'), ('failed', 'failed_launches'))}
        x, z = self.jump_reflex.step(x, z, forces, self.jump_modulation(actions))
        for name, field in (('launch', 'launch_events'), ('flight', 'flight_events'),
                            ('landed', 'landing_events'), ('failed', 'failed_launches')):
            self._jump_events[name] += getattr(self.jump_reflex, field) - before[name]
        self.x, self.z = x, z
        return x, y, z

    def controller_observations(self):
        stages = F.one_hot(self.jump_reflex.state, num_classes=6).to(self.X.dtype)
        return torch.cat((super().controller_observations(), stages), dim=-1)

"""Isolated one-shot jump probe; it is not registered with MP_full_a1."""
import math

import torch


class ContactJumpReflex:
    IDLE, ARMED, PRELOAD, PUSH, FLIGHT, RECOVER = range(6)

    def __init__(self, num_envs, device, dt, robot_height=.30,
                 preload_depth=.03, extension_depth=.045,
                 preload_time=.055, push_time=.105, min_push_time=.045,
                 max_push_time=.18, flight_clearance=.14,
                 tuck_time=.085, min_flight_time=.04,
                 max_flight_time=.4, recover_time=.12,
                 trigger_hold=.005, contact_hold=.004,
                 armed_timeout=.6):
        if not math.isfinite(dt) or dt <= 0:
            raise ValueError('dt must be positive and finite')
        self.num_envs = num_envs
        self.device = device
        self.dt = dt
        self.robot_height = robot_height
        self.preload_depth = preload_depth
        self.extension_depth = extension_depth
        self.preload_time = preload_time
        self.push_time = push_time
        self.min_push_time = min_push_time
        self.max_push_time = max_push_time
        self.flight_clearance = flight_clearance
        self.tuck_time = tuck_time
        self.min_flight_time = min_flight_time
        self.max_flight_time = max_flight_time
        self.recover_time = recover_time
        self.trigger_hold = trigger_hold
        self.contact_hold = contact_hold
        self.armed_timeout = armed_timeout
        self.state = torch.zeros(num_envs, dtype=torch.long, device=device)
        self.elapsed = torch.zeros(num_envs, device=device)
        self.trigger_streak = torch.zeros_like(self.elapsed)
        self.off_streak = torch.zeros_like(self.elapsed)
        self.landing_streak = torch.zeros_like(self.elapsed)
        self.start_z = torch.zeros(num_envs, 4, device=device)
        self.flight_start_z = torch.zeros_like(self.start_z)
        self.recover_start_z = torch.zeros_like(self.start_z)
        self.completed = torch.zeros(num_envs, dtype=torch.bool, device=device)
        self.launch_events = torch.zeros(num_envs, dtype=torch.long, device=device)
        self.flight_events = torch.zeros_like(self.launch_events)
        self.landing_events = torch.zeros_like(self.launch_events)
        self.failed_launches = torch.zeros_like(self.launch_events)

    @staticmethod
    def _smooth(progress):
        progress = progress.clamp(0., 1.)
        return progress.square() * (3. - 2. * progress)

    @torch.no_grad()
    def reset(self, env_ids):
        ids = torch.as_tensor(env_ids, device=self.device, dtype=torch.long).flatten()
        self.state[ids] = self.IDLE
        self.elapsed[ids] = 0.
        self.trigger_streak[ids] = 0.
        self.off_streak[ids] = 0.
        self.landing_streak[ids] = 0.
        self.start_z[ids] = 0.
        self.flight_start_z[ids] = 0.
        self.recover_start_z[ids] = 0.
        self.completed[ids] = False
        self.launch_events[ids] = 0
        self.flight_events[ids] = 0
        self.landing_events[ids] = 0
        self.failed_launches[ids] = 0

    @torch.no_grad()
    def arm(self, mask):
        mask = torch.as_tensor(mask, device=self.device, dtype=torch.bool)
        if mask.shape != (self.num_envs,):
            raise ValueError('arm mask must have shape [num_envs]')
        start = mask & (self.state == self.IDLE) & ~self.completed
        self.state[start] = self.ARMED
        self.elapsed[start] = 0.

    @torch.no_grad()
    def step(self, base_z, contact_forces, vertical_phase):
        if (base_z.shape != (self.num_envs, 4)
                or contact_forces.shape != base_z.shape
                or vertical_phase.shape != base_z.shape):
            raise ValueError('base_z, contact_forces and vertical_phase must be [num_envs,4]')
        contact = contact_forces > 5.
        hind_stance = ((vertical_phase[:, 2:] >= math.pi)
                       & (vertical_phase[:, 2:] <= 1.75 * math.pi))
        qualified = ((contact.sum(-1) >= 2)
                     & (contact[:, 2:] & hind_stance).any(-1))
        self.trigger_streak = torch.where(
            qualified, self.trigger_streak + self.dt, 0.)
        all_off = (contact_forces < 1.).all(-1)
        self.off_streak = torch.where(all_off, self.off_streak + self.dt, 0.)
        self.landing_streak = torch.where(
            contact.any(-1), self.landing_streak + self.dt, 0.)

        trigger = ((self.state == self.ARMED)
                   & (self.trigger_streak >= self.trigger_hold))
        self.state[trigger] = self.PRELOAD
        self.elapsed[trigger] = 0.
        self.start_z[trigger] = base_z[trigger]
        self.launch_events += trigger.long()

        preload_z = base_z.new_full(base_z.shape,
                                    -self.robot_height + self.preload_depth)
        extension_z = base_z.new_full(base_z.shape,
                                      -self.robot_height - self.extension_depth)
        flight_z = base_z.new_full(base_z.shape,
                                   -self.robot_height + self.flight_clearance)
        age = self.elapsed[:, None]
        z = torch.where(
            (self.state == self.PRELOAD)[:, None],
            self.start_z + self._smooth(age / self.preload_time)
            * (preload_z - self.start_z), base_z)
        z = torch.where(
            (self.state == self.PUSH)[:, None],
            preload_z + self._smooth(age / self.push_time)
            * (extension_z - preload_z), z)
        z = torch.where(
            (self.state == self.FLIGHT)[:, None],
            self.flight_start_z + self._smooth(age / self.tuck_time)
            * (flight_z - self.flight_start_z), z)
        z = torch.where(
            (self.state == self.RECOVER)[:, None],
            self.recover_start_z + self._smooth(age / self.recover_time)
            * (base_z - self.recover_start_z), z)

        self.elapsed += self.dt
        preload_done = ((self.state == self.PRELOAD)
                        & (self.elapsed >= self.preload_time))
        self.state[preload_done] = self.PUSH
        self.elapsed[preload_done] = 0.

        took_off = ((self.state == self.PUSH)
                    & (self.elapsed >= self.min_push_time)
                    & (self.off_streak >= self.contact_hold))
        self.flight_start_z[took_off] = z[took_off]
        self.state[took_off] = self.FLIGHT
        self.elapsed[took_off] = 0.
        self.flight_events += took_off.long()

        push_timeout = ((self.state == self.PUSH)
                        & (self.elapsed >= self.max_push_time))
        self.recover_start_z[push_timeout] = z[push_timeout]
        self.state[push_timeout] = self.RECOVER
        self.elapsed[push_timeout] = 0.
        self.failed_launches += push_timeout.long()

        landed = ((self.state == self.FLIGHT)
                  & (self.elapsed >= self.min_flight_time)
                  & (self.landing_streak >= self.contact_hold))
        flight_timeout = ((self.state == self.FLIGHT)
                          & (self.elapsed >= self.max_flight_time))
        recovering = landed | flight_timeout
        self.recover_start_z[recovering] = z[recovering]
        self.state[recovering] = self.RECOVER
        self.elapsed[recovering] = 0.
        self.landing_events += landed.long()

        recovered = ((self.state == self.RECOVER)
                     & (self.elapsed >= self.recover_time))
        self.state[recovered] = self.IDLE
        self.elapsed[recovered] = 0.
        self.completed |= recovered

        armed_timeout = ((self.state == self.ARMED)
                         & (self.elapsed >= self.armed_timeout))
        self.state[armed_timeout] = self.IDLE
        self.elapsed[armed_timeout] = 0.
        self.completed |= armed_timeout
        return z

"""Contact jump with action-latched thrust and landing parameters.

The contact event initiates the maneuver. Six summaries of the existing
continuous action vector choose its shape; they are latched at launch to keep
the foot trajectory continuous when the policy output changes mid-flight.
"""
from .contact_jump_reflex_v2 import ContactJumpReflexV2


class ContactJumpReflexV3(ContactJumpReflexV2):
    def __init__(self, num_envs, device, dt, **kwargs):
        kwargs.setdefault('preload_time', .01)
        kwargs.setdefault('push_time', .06)
        kwargs.setdefault('landing_deploy_delay', .20)
        super().__init__(num_envs, device, dt, **kwargs)

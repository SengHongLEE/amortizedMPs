"""Transfer a two-policy MP_full v1 checkpoint into the v2 action layout."""

import torch


def _expand_observation_weights(old, new, prefix):
    """Preserve v1 features while inserting six actions and two clock states."""
    old_sizes = (prefix, 17, 3, 44, 60)
    new_sizes = (prefix, 23, 3, 46, 60)
    if old.shape[1] != sum(old_sizes) or new.shape[1] != sum(new_sizes):
        raise ValueError('unexpected MP_full observation layout')
    result = torch.zeros_like(new)
    old_start = new_start = 0
    for old_size, new_size in zip(old_sizes, new_sizes):
        result[:, new_start:new_start + old_size] = old[:, old_start:old_start + old_size]
        old_start += old_size
        new_start += new_size
    return result


def transfer_v1_state(source, target, *, continuous):
    """Copy learned v1 weights; initialize new v2 inputs and outputs to neutral."""
    if source.keys() != target.keys():
        raise ValueError('checkpoint and policy state keys differ')
    result = {}
    for name, new in target.items():
        old = source[name]
        if old.shape == new.shape:
            result[name] = old
        elif name in ('actor.reservoir.w_in', 'actor.linear_layers.0.weight'):
            result[name] = _expand_observation_weights(old, new, prefix=34)
        elif name == 'critic.0.weight':
            result[name] = _expand_observation_weights(old, new, prefix=41)
        elif continuous and name in ('actor.output_layer.weight', 'actor.output_layer.bias', 'std'):
            if old.shape[0] != 16 or new.shape[0] != 22 or old.shape[1:] != new.shape[1:]:
                raise ValueError(f'unexpected shape for {name}: {old.shape} -> {new.shape}')
            result[name] = torch.zeros_like(new)
            result[name][:16] = old
        else:
            raise ValueError(f'cannot transfer {name}: {old.shape} -> {new.shape}')
    return result


def load_v1_checkpoint(runner, checkpoint, initial_std):
    """Load two learned actors and critics without the legacy third actor."""
    loaded = torch.load(str(checkpoint), map_location=runner.device, weights_only=False)
    policies = (
        ('primitive_selection', runner.primitive_selection_actor_critic, False),
        ('modulation_param', runner.modulation_param_actor_critic, True),
    )
    for name, policy, continuous in policies:
        source = loaded[f'{name}_model_state_dict']
        policy.load_state_dict(transfer_v1_state(source, policy.state_dict(), continuous=continuous))
    with torch.no_grad():
        runner.modulation_param_actor_critic.std.fill_(initial_std)
    runner.current_learning_iteration = 0

"""Train MP_full_a1 with contact-triggered jump replacing pronk.

Example:
  python train_mp_full_jump.py --task MP_full_jump_a1 --headless \
      --num_envs 4096 --max_iterations 310
"""
import hashlib
import json
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'legged_gym'), str(ROOT / 'rsl_rl')]
os.environ.setdefault('TORCH_EXTENSIONS_DIR',
                      str(ROOT / 'legged_gym/legged_gym/test/torch_extensions'))

from isaacgym import gymapi  # noqa: F401; must precede torch imports.

from legged_gym.envs.a1.mp_full_jump import register_jump_task
from legged_gym.utils import get_args, task_registry


def main():
    register_jump_task()
    args = get_args()
    if args.task != 'MP_full_jump_a1':
        raise SystemExit('Use --task MP_full_jump_a1 for this experiment')
    if args.resume:
        raise SystemExit('This experiment starts a fresh jump policy; --resume is unsupported')

    env, env_cfg = task_registry.make_env(args.task, args=args)
    runner, train_cfg = task_registry.make_alg_runner(
        env, name=args.task, args=args, env_cfg=env_cfg)
    files = (
        'legged_gym/legged_gym/envs/a1/mp_full.py',
        'legged_gym/legged_gym/envs/a1/mp_full_jump.py',
        'legged_gym/legged_gym/utils/dynamics/a1/jump_dynamics.py',
        'legged_gym/legged_gym/utils/dynamics/a1/contact_jump_reflex_probe.py',
        'legged_gym/legged_gym/utils/dynamics/a1/equilibrium_dynamics.py',
        'legged_gym/legged_gym/utils/dynamics/a1/rhythmic_dynamics.py',
        'legged_gym/legged_gym/utils/terrains/blind_terrain.py',
        'legged_gym/legged_gym/utils/terrains/terrain_curriculum.py',
        'rsl_rl/rsl_rl/modules/actor_critic.py',
        'rsl_rl/rsl_rl/runners/multi_interoceptive_policy_runner.py',
    )
    manifest = {
        'task': args.task,
        'primitive_names': list(env.ID.primitive_names),
        'jump_variant': env_cfg.env.jump_variant,
        'continuous_actions': env_cfg.env.num_modulation_params,
        'source_sha256': {
            name: hashlib.sha256((ROOT / name).read_bytes()).hexdigest()
            for name in files},
    }
    (Path(runner.log_dir) / 'run_manifest.json').write_text(
        json.dumps(manifest, indent=2) + '\n')
    runner.learn(train_cfg.runner.max_iterations,
                 init_at_random_ep_len=False)


if __name__ == '__main__':
    main()

"""Run the V2 jump controller with a V1 checkpoint as continuous-policy control.

The checkpoint is not a trained V2 policy. Its actor still provides ordinary
locomotion actions; oracle selection isolates the V2 controller's physics.
"""
import argparse
import json
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'legged_gym'), str(ROOT / 'rsl_rl')]
os.environ.setdefault('TORCH_EXTENSIONS_DIR',
                      str(ROOT / 'legged_gym/legged_gym/test/torch_extensions'))

from isaacgym import gymapi  # noqa: F401; before torch.
import torch

from legged_gym.scripts import probe_mp_full_jump_oracle as oracle
from legged_gym.utils.dynamics.a1.jump_dynamics_v2 import (
    JumpAdaptiveEquilibriumDynamicsV2)


class V2OracleEvaluationEnv(oracle.OracleJumpEvaluationEnv):
    latest = None
    controller_class = JumpAdaptiveEquilibriumDynamicsV2
    controller_name = 'contact_reflex_v2'
    push_scale = 1.
    extension_depth = None
    tuck_time = None
    preload_time = None
    push_time = None
    fresh_support_trigger = False
    landing_deploy_delay = None
    jump_continuous = 'policy'
    jump_modulation = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        reflex = self.ID.jump_reflex
        reflex.push_stroke.mul_(self.push_scale)
        if self.extension_depth is not None:
            reflex.extension_depth = self.extension_depth
        if self.tuck_time is not None:
            reflex.tuck_time = self.tuck_time
        if self.preload_time is not None:
            reflex.preload_time = self.preload_time
        if self.push_time is not None:
            reflex.push_time = self.push_time
        reflex.fresh_support_trigger = self.fresh_support_trigger
        if self.landing_deploy_delay is not None:
            reflex.landing_deploy_delay = self.landing_deploy_delay
        self.ik_error_sum = torch.zeros(self.num_envs, device=self.device)
        self.ik_error_max = torch.zeros_like(self.ik_error_sum)
        self.ik_steps = torch.zeros_like(self.ik_error_sum)
        self.latched_snapshot = {
            name: torch.full((self.num_envs,), float('nan'),
                             device=self.device)
            for name in ('push_stroke_m', 'extension_depth_m',
                         'deploy_delay_s', 'landing_x_m',
                         'tuck_clearance_m', 'push_time_s')}

    def _validate_action_config(self):
        super()._validate_action_config()
        self._controller_class = self.controller_class

    def step(self, actions):
        if ((self.jump_continuous != 'policy' or self.jump_modulation is not None)
                and self.oracle_jump and hasattr(self, 'jump_edge_x')):
            distance = self.jump_edge_x - self.root_states[:, 0]
            active = (self.metrics.active if getattr(self, 'metrics', None) is not None
                      else torch.ones_like(distance, dtype=torch.bool))
            newly_selected = ((distance > 0.) & (distance <= self.arm_distance)
                              & ~self.jump_issued & active)
            selected = newly_selected | ((self.jump_steps_left > 0) & active)
            if selected.any():
                actions = actions.clone()
                if self.jump_modulation is None:
                    replacement = {'zero': 0., 'high': 1., 'low': -1.}[
                        self.jump_continuous]
                    actions[selected, 1:] = replacement
                else:
                    m = self.jump_modulation
                    for start, end, value in ((1, 5, m[0]), (5, 9, m[1]),
                                               (9, 13, m[2]), (13, 17, m[3]),
                                               (17, 18, m[4]), (18, 19, m[5])):
                        actions[selected, start:end] = value
        return super().step(actions)

    def check_termination(self, env_ids=None):
        if hasattr(self, 'latched_snapshot'):
            reflex = self.ID.jump_reflex
            launched = reflex.launch_events > 0
            sources = {
                'push_stroke_m': reflex.latched_push_stroke.mean(-1),
                'extension_depth_m': reflex.latched_extension_depth[:, 0],
                'deploy_delay_s': reflex.latched_deploy_delay[:, 0],
                'landing_x_m': reflex.latched_landing_x[:, 0],
                'tuck_clearance_m': reflex.latched_tuck_clearance[:, 0],
                'push_time_s': reflex.latched_push_time[:, 0],
            }
            for name, value in sources.items():
                target = self.latched_snapshot[name]
                capture = launched & torch.isnan(target)
                target[capture] = value[capture]
        result = super().check_termination(env_ids)
        if hasattr(self, 'ik_steps') and getattr(self, 'metrics', None) is not None:
            active = self.jump_issued & self.metrics.active
            error = torch.linalg.vector_norm(
                self.foot_targets_requested - self.foot_targets_reachable,
                dim=-1).mean(-1)
            self.ik_error_sum[active] += error[active]
            self.ik_steps[active] += 1
            self.ik_error_max[active] = torch.maximum(
                self.ik_error_max[active], error[active])
            if getattr(self, 'trace_env_ids', None) is not None:
                ids = self.trace_env_ids
                for name, value in (
                        ('foot_target_requested', self.foot_targets_requested),
                        ('foot_target_reachable', self.foot_targets_reachable),
                        ('jump_support_mask', self.ID.jump_reflex.support_mask)):
                    self.trace_samples.setdefault(name, []).append(
                        value[ids].detach().cpu().numpy().copy())
        return result


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--push-scale', type=float, default=1.)
    parser.add_argument('--extension-depth', type=float)
    parser.add_argument('--tuck-time', type=float)
    parser.add_argument('--preload-time', type=float)
    parser.add_argument('--push-time', type=float)
    parser.add_argument('--fresh-support-trigger', action='store_true')
    parser.add_argument('--landing-deploy-delay', type=float)
    parser.add_argument('--jump-continuous',
                        choices=('policy', 'zero', 'high', 'low'),
                        default='policy')
    parser.add_argument('--jump-modulation', nargs=6, type=float,
                        metavar=('SWEEP', 'EXTEND', 'DEPLOY', 'LAND_X',
                                 'TUCK', 'PUSH_TIME'))
    args, remaining = parser.parse_known_args()
    if (args.jump_modulation is not None
            and (args.jump_continuous != 'policy'
                 or any(not -1 <= value <= 1 for value in args.jump_modulation))):
        parser.error('--jump-modulation requires six values in [-1,1]')
    if (not 0 <= args.push_scale <= 2
            or (args.extension_depth is not None
                and not .02 <= args.extension_depth <= .10)
            or (args.tuck_time is not None
                and not .02 <= args.tuck_time <= .10)
            or (args.preload_time is not None
                and not .005 <= args.preload_time <= .10)
            or (args.push_time is not None
                and not .02 <= args.push_time <= .20)
            or (args.landing_deploy_delay is not None
                and not .04 <= args.landing_deploy_delay <= 1.)):
        parser.error('V2 override parameters are outside the probe range')
    V2OracleEvaluationEnv.push_scale = args.push_scale
    V2OracleEvaluationEnv.extension_depth = args.extension_depth
    V2OracleEvaluationEnv.tuck_time = args.tuck_time
    V2OracleEvaluationEnv.preload_time = args.preload_time
    V2OracleEvaluationEnv.push_time = args.push_time
    V2OracleEvaluationEnv.fresh_support_trigger = args.fresh_support_trigger
    V2OracleEvaluationEnv.landing_deploy_delay = args.landing_deploy_delay
    V2OracleEvaluationEnv.jump_continuous = args.jump_continuous
    V2OracleEvaluationEnv.jump_modulation = args.jump_modulation
    oracle.OracleJumpEvaluationEnv = V2OracleEvaluationEnv
    sys.argv = [sys.argv[0], '--output', str(args.output), *remaining]
    oracle.main()
    report_path = args.output / 'report.json'
    report = json.loads(report_path.read_text())
    env = V2OracleEvaluationEnv.latest
    mean_error = (env.ik_error_sum / env.ik_steps.clamp_min(1)).cpu().tolist()
    max_error = env.ik_error_max.cpu().tolist()
    latched = {
        'jump_latched_' + name: values.cpu().tolist()
        for name, values in env.latched_snapshot.items()
    }
    for group in report['groups']:
        for episode in group['episodes']:
            index = episode['env']
            episode['ik_mean_error_m'] = mean_error[index]
            episode['ik_max_error_m'] = max_error[index]
            episode.update({name: values[index] for name, values in latched.items()})
    report['jump_oracle_probe']['controller_override'] = (
        V2OracleEvaluationEnv.controller_name)
    report['jump_oracle_probe']['checkpoint_trained_for_controller'] = False
    report['jump_oracle_probe']['push_scale'] = args.push_scale
    report['jump_oracle_probe']['extension_depth'] = (
        env.ID.jump_reflex.extension_depth)
    report['jump_oracle_probe']['tuck_time'] = env.ID.jump_reflex.tuck_time
    report['jump_oracle_probe']['preload_time'] = env.ID.jump_reflex.preload_time
    report['jump_oracle_probe']['push_time'] = env.ID.jump_reflex.push_time
    report['jump_oracle_probe']['fresh_support_trigger'] = (
        env.ID.jump_reflex.fresh_support_trigger)
    report['jump_oracle_probe']['landing_deploy_delay'] = (
        env.ID.jump_reflex.landing_deploy_delay)
    report['jump_oracle_probe']['jump_continuous'] = args.jump_continuous
    report['jump_oracle_probe']['jump_modulation'] = args.jump_modulation
    report['jump_experiment']['jump_variant'] = (
        V2OracleEvaluationEnv.controller_name + '_probe')
    report['jump_experiment']['trained_checkpoint'] = False
    report_path.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()

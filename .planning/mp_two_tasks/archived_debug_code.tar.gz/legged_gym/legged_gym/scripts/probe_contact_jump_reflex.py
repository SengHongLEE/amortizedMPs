"""Paired MP_full_a1 jump-reflex probe using an existing five-primitive checkpoint.

The checkpoint still selects among its trained gaits. In reflex mode this
experiment arms a one-shot jump at a known obstacle distance; only measured
contact and the controller's leg phase start and advance the maneuver. Oracle
arming is an upper-bound probe, not a learned sixth primitive.
"""
import argparse
import json
from pathlib import Path
import sys

from isaacgym import gymapi  # Isaac Gym must precede torch.
import torch

from legged_gym.scripts import evaluate_mp_full_terrain as evaluation
from legged_gym.utils.dynamics.a1.contact_jump_reflex_probe import ContactJumpReflex
from legged_gym.utils.terrains.blind_terrain import obstacle_bands


class ReflexEvaluationEnv(evaluation.EvaluationEnv):
    arm_distance = .35
    latest = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        type(self).latest = self
        self.jump_reflex = ContactJumpReflex(
            self.num_envs, self.device, self.sim_params.dt,
            robot_height=self.ID._robot_height)
        self.first_arm_x = torch.full((self.num_envs,), float('nan'), device=self.device)
        self.first_launch_x = torch.full_like(self.first_arm_x, float('nan'))
        self.first_flight_x = torch.full_like(self.first_arm_x, float('nan'))
        self.first_landing_x = torch.full_like(self.first_arm_x, float('nan'))
        original_dynamics = self.ID.intrinsic_dynamics

        def reflex_dynamics(actions, command, foot_contact=None, contact_forces=None):
            x, y, z = original_dynamics(
                actions, command, foot_contact=foot_contact,
                contact_forces=contact_forces)
            if contact_forces is None:
                force = foot_contact.to(z.dtype) * 20. if foot_contact is not None else torch.zeros_like(z)
            else:
                force = contact_forces
            previous = self.jump_reflex.state.clone()
            z = self.jump_reflex.step(z, force, self.ID._vertical_phase())
            root_x = self.root_states[:, 0]
            for target, condition in (
                (self.first_launch_x, (previous == ContactJumpReflex.ARMED)
                 & (self.jump_reflex.state == ContactJumpReflex.PRELOAD)),
                (self.first_flight_x, (previous == ContactJumpReflex.PUSH)
                 & (self.jump_reflex.state == ContactJumpReflex.FLIGHT)),
                (self.first_landing_x, (previous == ContactJumpReflex.FLIGHT)
                 & (self.jump_reflex.state == ContactJumpReflex.RECOVER)),
            ):
                first = condition & torch.isnan(target)
                target[first] = root_x[first]
            self.ID.z = z
            return x, y, z

        self.ID.intrinsic_dynamics = reflex_dynamics

    def reset_idx(self, env_ids, completed_episode=False):
        super().reset_idx(env_ids, completed_episode=completed_episode)
        if hasattr(self, 'jump_reflex'):
            self.jump_reflex.reset(env_ids)

    def reset(self):
        result = super().reset()
        length = self.terrain.length_per_env_pixels
        scale = self.terrain.horizontal_scale
        edges = []
        for row, column, origin in zip(self.terrain_levels.cpu().tolist(),
                                        self.terrain_types.cpu().tolist(),
                                        self.env_origins[:, 0].cpu().tolist()):
            name = self.terrain.terrain_names[row, column]
            kind = self.terrain._kind(name)
            if kind not in ('gap', 'hurdle'):
                edges.append(float('inf'))
                continue
            params = self.terrain.tile_parameters[row, column]
            candidates = [start for start, _ in obstacle_bands(length, scale, params, kind)
                          if start >= length // 2]
            if not candidates:
                raise RuntimeError(f'{name} has no forward obstacle edge')
            edges.append(origin + (candidates[0] - length / 2) * scale)
        self.jump_edge_x = torch.tensor(edges, device=self.device)
        return result

    def _compute_torques(self, actions):
        if hasattr(self, 'jump_edge_x') and hasattr(self, 'jump_reflex'):
            distance = self.jump_edge_x - self.root_states[:, 0]
            active = self.metrics.active if getattr(self, 'metrics', None) is not None \
                else torch.ones_like(distance, dtype=torch.bool)
            mask = (distance > 0.) & (distance <= self.arm_distance) & active
            newly_armed = mask & (self.jump_reflex.state == ContactJumpReflex.IDLE) \
                & ~self.jump_reflex.completed & torch.isnan(self.first_arm_x)
            self.first_arm_x[newly_armed] = self.root_states[newly_armed, 0]
            self.jump_reflex.arm(mask)
        return super()._compute_torques(actions)

    def check_termination(self, env_ids=None):
        super().check_termination(env_ids)
        if (getattr(self, 'trace_env_ids', None) is not None
                and hasattr(self, 'jump_reflex')):
            self.trace_samples.setdefault('jump_state', []).append(
                self.jump_reflex.state[self.trace_env_ids].detach().cpu().numpy().copy())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--jump-mode', choices=('baseline', 'reflex'), required=True)
    parser.add_argument('--arm-distance', type=float, default=.35)
    parser.add_argument('--output', type=Path, required=True)
    args, remaining = parser.parse_known_args()
    if not 0.05 <= args.arm_distance <= 1.0:
        parser.error('--arm-distance must lie in [0.05, 1.0] metres')
    sys.argv = [sys.argv[0], '--output', str(args.output), *remaining]
    if args.jump_mode == 'reflex':
        ReflexEvaluationEnv.arm_distance = args.arm_distance
        evaluation.EvaluationEnv = ReflexEvaluationEnv
    evaluation.main()

    report_path = args.output / 'report.json'
    report = json.loads(report_path.read_text())
    probe = dict(mode=args.jump_mode, arm_distance=args.arm_distance,
                 oracle_arming=args.jump_mode == 'reflex',
                 trigger='at least two feet contacting, including one hind leg in stance phase',
                 checkpoint_retrained_for_jump=False)
    if args.jump_mode == 'reflex':
        env = ReflexEvaluationEnv.latest
        values = {name: getattr(env, name).cpu().tolist() for name in
                  ('first_arm_x', 'first_launch_x', 'first_flight_x', 'first_landing_x')}
        for group in report['groups']:
            for episode in group['episodes']:
                index = episode['env']
                episode.update({name: value[index] for name, value in values.items()})
        probe.update(
            armed=sum(value == value for value in values['first_arm_x']),
            launched=sum(value == value for value in values['first_launch_x']),
            airborne=sum(value == value for value in values['first_flight_x']),
            landed=sum(value == value for value in values['first_landing_x']),
        )
    report['jump_probe'] = probe
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    print('jump probe:', json.dumps(probe), flush=True)


if __name__ == '__main__':
    main()

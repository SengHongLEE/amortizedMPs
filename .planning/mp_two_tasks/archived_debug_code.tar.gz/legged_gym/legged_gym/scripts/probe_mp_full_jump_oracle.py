"""Probe the trained jump controller with oracle-timed selection.

The selection changes only the discrete primitive when the base nears the
first obstacle. It lasts for a configurable number of environment steps;
the contact reflex then runs on its own. This is a physical upper-bound test,
not a deployable policy evaluation.
"""
import argparse
import json
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'legged_gym'), str(ROOT / 'rsl_rl')]
os.environ.setdefault('TORCH_EXTENSIONS_DIR',
                      str(ROOT / 'legged_gym/legged_gym/test/torch_extensions'))

from isaacgym import gymapi  # noqa: F401; must precede torch.
import torch

from legged_gym.scripts import evaluate_mp_full_jump as jump_evaluation
from legged_gym.utils.terrains.blind_terrain import obstacle_bands


class OracleJumpEvaluationEnv(jump_evaluation.JumpEvaluationEnv):
    oracle_jump = False
    arm_distance = .35
    hold_steps = 1
    latest = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        type(self).latest = self
        self.jump_issued = torch.zeros(self.num_envs, dtype=torch.bool,
                                       device=self.device)
        self.jump_steps_left = torch.zeros(self.num_envs, dtype=torch.long,
                                           device=self.device)
        for name in ('first_arm_x', 'first_launch_x', 'first_flight_x',
                     'first_landing_x', 'first_arm_vx', 'first_flight_vx',
                     'first_landing_vx', 'first_arm_z', 'first_flight_z',
                     'first_landing_z'):
            setattr(self, name, torch.full((self.num_envs,), float('nan'),
                                           device=self.device))
        self.max_vz_after_arm = torch.full((self.num_envs,), float('nan'),
                                           device=self.device)
        self.min_vx_before_landing = torch.full_like(self.max_vz_after_arm,
                                                      float('nan'))
        original = self.ID.intrinsic_dynamics

        def traced_dynamics(*args, **kwargs):
            reflex = self.ID.jump_reflex
            launch = reflex.launch_events.clone()
            flight = reflex.flight_events.clone()
            landing = reflex.landing_events.clone()
            result = original(*args, **kwargs)
            x = self.root_states[:, 0]
            for name, changed in (
                    ('first_launch_x', reflex.launch_events > launch),
                    ('first_flight_x', reflex.flight_events > flight),
                    ('first_landing_x', reflex.landing_events > landing)):
                target = getattr(self, name)
                first = changed & torch.isnan(target)
                target[first] = x[first]
                if name != 'first_launch_x':
                    stem = name[:-2]
                    getattr(self, stem + '_vx')[first] = self.root_states[first, 7]
                    getattr(self, stem + '_z')[first] = self.root_states[first, 2]
            return result

        self.ID.intrinsic_dynamics = traced_dynamics

    def reset(self):
        result = super().reset()
        length = self.terrain.length_per_env_pixels
        scale = self.terrain.horizontal_scale
        edges = []
        for row, column, origin in zip(
                self.terrain_levels.cpu().tolist(),
                self.terrain_types.cpu().tolist(),
                self.env_origins[:, 0].cpu().tolist()):
            name = self.terrain.terrain_names[row, column]
            kind = self.terrain._kind(name)
            if kind not in ('gap', 'hurdle'):
                edges.append(float('inf'))
                continue
            params = self.terrain.tile_parameters[row, column]
            candidates = [start for start, _ in obstacle_bands(
                length, scale, params, kind) if start >= length // 2]
            if not candidates:
                raise RuntimeError(f'{name} has no forward obstacle edge')
            edges.append(origin + (candidates[0] - length / 2) * scale)
        self.jump_edge_x = torch.tensor(edges, device=self.device)
        return result

    def step(self, actions):
        if self.oracle_jump and hasattr(self, 'jump_edge_x'):
            distance = self.jump_edge_x - self.root_states[:, 0]
            active = (self.metrics.active if getattr(self, 'metrics', None) is not None
                      else torch.ones_like(distance, dtype=torch.bool))
            issue = ((distance > 0.) & (distance <= self.arm_distance)
                     & ~self.jump_issued & active)
            if issue.any():
                self.jump_issued[issue] = True
                self.jump_steps_left[issue] = self.hold_steps
                self.first_arm_x[issue] = self.root_states[issue, 0]
                self.first_arm_vx[issue] = self.root_states[issue, 7]
                self.first_arm_z[issue] = self.root_states[issue, 2]
            selected = (self.jump_steps_left > 0) & active
            if selected.any():
                actions = actions.clone()
                actions[selected, 0] = 4.
                self.jump_steps_left[selected] -= 1
        return super().step(actions)

    def check_termination(self, env_ids=None):
        if hasattr(self, 'jump_issued'):
            active = (self.metrics.active if getattr(self, 'metrics', None) is not None
                      else torch.ones_like(self.jump_issued))
            measured = self.jump_issued & active & torch.isnan(self.first_landing_x)
            self.max_vz_after_arm[measured] = torch.maximum(
                torch.nan_to_num(self.max_vz_after_arm[measured], nan=-float('inf')),
                self.root_states[measured, 9])
            self.min_vx_before_landing[measured] = torch.minimum(
                torch.nan_to_num(self.min_vx_before_landing[measured], nan=float('inf')),
                self.root_states[measured, 7])
        return super().check_termination(env_ids)


def main():
    parser = argparse.ArgumentParser(description=__doc__, add_help=False)
    parser.add_argument('--jump-mode', choices=('baseline', 'oracle'), required=True)
    parser.add_argument('--arm-distance', type=float, default=.35)
    parser.add_argument('--hold-steps', type=int, default=1)
    parser.add_argument('--output', type=Path, required=True)
    args, remaining = parser.parse_known_args()
    if not .05 <= args.arm_distance <= 1.0:
        parser.error('--arm-distance must lie in [.05, 1.0] metres')
    if not 1 <= args.hold_steps <= 30:
        parser.error('--hold-steps must lie in [1, 30]')
    OracleJumpEvaluationEnv.oracle_jump = args.jump_mode == 'oracle'
    OracleJumpEvaluationEnv.arm_distance = args.arm_distance
    OracleJumpEvaluationEnv.hold_steps = args.hold_steps
    jump_evaluation.JumpEvaluationEnv = OracleJumpEvaluationEnv
    sys.argv = [sys.argv[0], '--output', str(args.output), *remaining]
    jump_evaluation.main()

    env = OracleJumpEvaluationEnv.latest
    report_path = args.output / 'report.json'
    report = json.loads(report_path.read_text())
    names = ('first_arm_x', 'first_launch_x', 'first_flight_x',
             'first_landing_x', 'first_arm_vx', 'first_flight_vx',
             'first_landing_vx', 'first_arm_z', 'first_flight_z',
             'first_landing_z', 'max_vz_after_arm', 'min_vx_before_landing')
    data = {name: getattr(env, name).cpu().tolist() for name in names}
    data['jump_edge_x'] = env.jump_edge_x.cpu().tolist()
    for group in report['groups']:
        for episode in group['episodes']:
            index = episode['env']
            episode.update({name: values[index] for name, values in data.items()})
    report['jump_oracle_probe'] = {
        'mode': args.jump_mode,
        'arm_distance': args.arm_distance,
        'hold_steps': args.hold_steps,
        'oracle_uses_obstacle_world_position': args.jump_mode == 'oracle',
        'issued': int(env.jump_issued.sum().item()),
        'launched': int(torch.isfinite(env.first_launch_x).sum().item()),
        'airborne': int(torch.isfinite(env.first_flight_x).sum().item()),
        'landed': int(torch.isfinite(env.first_landing_x).sum().item()),
    }
    report['jump_experiment']['oracle_arming'] = args.jump_mode == 'oracle'
    report_path.write_text(json.dumps(report, indent=2) + '\n')
    print('jump oracle probe:', json.dumps(report['jump_oracle_probe']), flush=True)


if __name__ == '__main__':
    main()

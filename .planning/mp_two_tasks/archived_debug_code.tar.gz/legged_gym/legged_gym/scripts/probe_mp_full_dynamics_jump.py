"""Evaluate a dynamics-only jump reflex without modifying MP_full_a1.

No obstacle positions or height samples enter the reflex. The existing actors,
observations and action tensors are used unchanged. Pair this command with the
ordinary evaluate_mp_full_terrain.py command using identical arguments.
"""
import argparse
import json
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'legged_gym'), str(ROOT / 'rsl_rl')]
os.environ.setdefault('TORCH_EXTENSIONS_DIR',
                      str(ROOT / 'legged_gym/legged_gym/test/torch_extensions'))

from isaacgym import gymapi  # noqa: F401; before torch.
import torch

from legged_gym.envs.a1.mp_full import MotorPrimitives
from legged_gym.scripts import evaluate_mp_full_terrain as evaluation
from legged_gym.utils.dynamics.a1.dynamics_only_jump import (
    DynamicsOnlyJumpDynamics)
from rsl_rl.runners.multi_interoceptive_policy_runner import (
    MultiInteroceptivePolicyRunner)


def observation_gait_window(observations, max_distance, edge_height=.05):
    """Sensor-only gait-selection upper bound using the actor's height channels.

    This is an evaluation rule, not a jump trigger or a learned policy. It
    never reads terrain metadata, obstacle coordinates, or privileged state.
    """
    if observations.ndim != 3 or observations.shape[-1] != 162:
        raise ValueError('expected actor observation history [N, T, 162]')
    if not .25 <= max_distance <= 1.25:
        raise ValueError('max_distance must be in [.25, 1.25] metres')
    heights = observations[:, -1, -60:].reshape(-1, 12, 5)[:, :, 2]
    edges = (heights[:, 1:] - heights[:, :-1]).abs()
    # The existing observation scales height measurements by 5.0. Position
    # i+1 is the far sensor in each adjacent pair, starting at x=.25 m.
    positions = .25 + .1 * torch.arange(11, device=observations.device)
    return ((edges > edge_height * 5.)
            & (positions[None, :] <= max_distance + 1e-6)).any(-1)


def observation_gap_window(observations, near_distance, far_distance,
                           edge_height=.05):
    """Detect a gap edge in an actor-only distance window for policy ablations."""
    if observations.ndim not in (2, 3) or observations.shape[-1] != 162:
        raise ValueError('expected actor observations [N, 162] or [N, T, 162]')
    if not .25 <= near_distance <= far_distance <= 1.25:
        raise ValueError('gap window must lie within [.25, 1.25] metres')
    current = observations[:, -1] if observations.ndim == 3 else observations
    heights = current[:, -60:].reshape(-1, 12, 5)[:, :, 2]
    # The actor's height encoding reverses the ground-height sign: a gap
    # appears as a positive observation edge.
    edge = heights[:, 1:] - heights[:, :-1]
    positions = .25 + .1 * torch.arange(11, device=observations.device)
    return ((edge > edge_height * 5.)
            & (positions[None, :] >= near_distance - 1e-6)
            & (positions[None, :] <= far_distance + 1e-6)).any(-1)


class DynamicsJumpEvaluationEnv(evaluation.EvaluationEnv):
    latest = None
    jump_modulation_override = None
    disable_hurdle_preparation = False
    gap_runup_distance_override = None
    gap_landing_x_override = None
    gap_speed_landing_shift_override = None
    push_stroke_override = None
    landing_min_contacts_override = None
    disable_reflex = False

    def _validate_action_config(self):
        MotorPrimitives._validate_action_config(self)
        self._controller_class = DynamicsOnlyJumpDynamics

    def __init__(self, *args, **kwargs):
        cfg = args[0] if args else kwargs['cfg']
        # Selection-only shaping is irrelevant during evaluation and is not a
        # method on the generic terrain evaluator's environment class.
        cfg.rewards.primitive_selection_rewards = [
            name for name in cfg.rewards.primitive_selection_rewards
            if name != 'obstacle_gait_readiness']
        if hasattr(cfg.rewards.scales, 'reflex_trigger_alignment'):
            cfg.rewards.scales.reflex_trigger_alignment = 0.
        cfg.rewards.modulation_param_rewards = [
            name for name in cfg.rewards.modulation_param_rewards
            if name != 'reflex_trigger_alignment']
        super().__init__(*args, **kwargs)
        type(self).latest = self
        if self.disable_hurdle_preparation:
            self.ID.jump_detector.enable_hurdle_prepare = False
        if self.gap_runup_distance_override is not None:
            self.ID.gap_runup_distance = self.gap_runup_distance_override
        if self.gap_landing_x_override is not None:
            self.ID.gap_landing_x_modulation = self.gap_landing_x_override
        if self.gap_speed_landing_shift_override is not None:
            self.ID.gap_speed_landing_shift = self.gap_speed_landing_shift_override
        if self.push_stroke_override is not None:
            front, hind = self.push_stroke_override
            self.ID.jump_reflex.push_stroke.copy_(
                torch.tensor([front, front, hind, hind], device=self.device))
        if self.landing_min_contacts_override is not None:
            self.ID.jump_reflex.landing_min_contacts = self.landing_min_contacts_override
        if self.jump_modulation_override is not None:
            self.ID.jump_modulation.copy_(torch.tensor(
                self.jump_modulation_override, device=self.device))
        n = self.num_envs
        self.first_arm_x = torch.full((n,), float('nan'), device=self.device)
        self.first_launch_x = torch.full_like(self.first_arm_x, float('nan'))
        self.first_flight_x = torch.full_like(self.first_arm_x, float('nan'))
        self.first_landing_x = torch.full_like(self.first_arm_x, float('nan'))
        self.arm_kind = torch.zeros(n, dtype=torch.long, device=self.device)
        self.eval_launches = torch.zeros_like(self.arm_kind)
        self.eval_flights = torch.zeros_like(self.arm_kind)
        self.eval_landings = torch.zeros_like(self.arm_kind)

        original_detector_step = self.ID.jump_detector.step
        if self.disable_reflex:
            def original_detector_step(*detector_args):
                return torch.zeros(n, dtype=torch.long, device=self.device)

        def traced_detector(*detector_args):
            events = original_detector_step(*detector_args)
            first = (events > 0) & torch.isnan(self.first_arm_x)
            self.first_arm_x[first] = self.root_states[first, 0]
            self.arm_kind[first] = events[first]
            return events

        self.ID.jump_detector.step = traced_detector
        original_dynamics = self.ID.intrinsic_dynamics

        def with_vector_forces(actions, command, foot_contact=None,
                               contact_forces=None):
            return original_dynamics(
                actions, command,
                foot_forces_xyz=self.contact_forces[:, self.feet_indices, :],
                base_velocity_x=self.base_lin_vel[:, 0])

        self.ID.intrinsic_dynamics = with_vector_forces

    def check_termination(self, env_ids=None):
        active = (self.metrics.active.clone()
                  if getattr(self, 'metrics', None) is not None else None)
        if getattr(self, 'trace_env_ids', None) is not None:
            ids = self.trace_env_ids
            for name, values in (
                    ('jump_state', self.ID.jump_reflex.state),
                    ('equilibrium_target', self.ID.offset_target),
                    ('frequency_scale', self.ID.frequency_scale),
                    ('preparation_age', self.ID.jump_detector.elapsed),
                    ('policy_obs', self.obs_buf[:, -1])):
                self.trace_samples.setdefault(name, []).append(
                    values[ids].detach().cpu().numpy().copy())
        if active is not None:
            reflex = self.ID.jump_reflex
            x = self.root_states[:, 0]
            for target, events in (
                    (self.first_launch_x, reflex.launch_events),
                    (self.first_flight_x, reflex.flight_events),
                    (self.first_landing_x, reflex.landing_events)):
                first = active & (events > 0) & torch.isnan(target)
                target[first] = x[first]
            for target, source in (
                    (self.eval_launches, reflex.launch_events),
                    (self.eval_flights, reflex.flight_events),
                    (self.eval_landings, reflex.landing_events)):
                target.copy_(torch.maximum(target, torch.where(active, source, 0)))
        return super().check_termination(env_ids)


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--jump-modulation', nargs=6, type=float,
                        metavar=('SWEEP', 'EXTEND', 'DEPLOY', 'LAND_X',
                                 'TUCK', 'PUSH_TIME'))
    parser.add_argument('--disable-hurdle-preparation', action='store_true')
    parser.add_argument('--gap-runup-distance', type=float)
    parser.add_argument('--gap-landing-x', type=float,
                        help='Override the landing-x modulation only for '
                             'intrinsically detected gap jumps.')
    parser.add_argument('--gap-speed-landing-shift', type=float,
                        help='Maximum gap-foot retraction at high launch speed (metres).')
    parser.add_argument('--push-stroke', nargs=2, type=float,
                        metavar=('FRONT', 'HIND'))
    parser.add_argument('--landing-min-contacts', type=int, choices=(1, 2, 3, 4))
    parser.add_argument('--disable-reflex', action='store_true')
    parser.add_argument('--observation-gait-window', type=float,
                        help='Sensor-only canter near height edges, bound elsewhere; '
                             'upper-bound ablation, not a learned selector.')
    parser.add_argument('--observation-gap-duty-window', nargs=2, type=float,
                        metavar=('NEAR', 'FAR'),
                        help='Actor-scan gap window for a policy-side duty ablation.')
    parser.add_argument('--observation-gap-duty-action', type=float,
                        help='Normalized duty action inside the gap window.')
    args, remaining = parser.parse_known_args()
    if (args.jump_modulation is not None
            and any(not -1. <= value <= 1. for value in args.jump_modulation)):
        parser.error('--jump-modulation values must be in [-1, 1]')
    if (args.gap_runup_distance is not None
            and not 0. <= args.gap_runup_distance <= 1.):
        parser.error('--gap-runup-distance must be in [0, 1] metres')
    if (args.gap_landing_x is not None
            and not -1. <= args.gap_landing_x <= 1.):
        parser.error('--gap-landing-x must be in [-1, 1]')
    if (args.gap_speed_landing_shift is not None
            and not 0. <= args.gap_speed_landing_shift <= .12):
        parser.error('--gap-speed-landing-shift must be in [0, 0.12] metres')
    if (args.push_stroke is not None
            and any(not 0. < value <= .25 for value in args.push_stroke)):
        parser.error('--push-stroke values must be in (0, 0.25] metres')
    if (args.observation_gait_window is not None
            and not .25 <= args.observation_gait_window <= 1.25):
        parser.error('--observation-gait-window must be in [.25, 1.25] metres')
    if (args.observation_gap_duty_window is None
            and args.observation_gap_duty_action is not None):
        parser.error('--observation-gap-duty-action requires a gap window')
    if args.observation_gap_duty_window is not None:
        near, far = args.observation_gap_duty_window
        if (not .25 <= near <= far <= 1.25
                or args.observation_gap_duty_action is None
                or not -1. <= args.observation_gap_duty_action <= 1.):
            parser.error('gap duty ablation requires valid window and action')
    DynamicsJumpEvaluationEnv.jump_modulation_override = args.jump_modulation
    DynamicsJumpEvaluationEnv.disable_hurdle_preparation = args.disable_hurdle_preparation
    DynamicsJumpEvaluationEnv.gap_runup_distance_override = args.gap_runup_distance
    DynamicsJumpEvaluationEnv.gap_landing_x_override = args.gap_landing_x
    DynamicsJumpEvaluationEnv.gap_speed_landing_shift_override = args.gap_speed_landing_shift
    DynamicsJumpEvaluationEnv.push_stroke_override = args.push_stroke
    DynamicsJumpEvaluationEnv.landing_min_contacts_override = args.landing_min_contacts
    DynamicsJumpEvaluationEnv.disable_reflex = args.disable_reflex
    if (args.observation_gait_window is not None
            or args.observation_gap_duty_window is not None):
        original_get_inference_policy = MultiInteroceptivePolicyRunner.get_inference_policy

        def get_inference_policy_with_actor_scan_rules(runner, *method_args, **method_kwargs):
            primitive_actor, modulation_actor, *other_actors = original_get_inference_policy(
                runner, *method_args, **method_kwargs)

            if args.observation_gait_window is not None:
                original_primitive_actor = primitive_actor

                def sensor_selected_primitive(observations, *actor_args):
                    selected = original_primitive_actor(observations, *actor_args)
                    if isinstance(selected, tuple):
                        gait, *state = selected
                    else:
                        gait, state = selected, []
                    near_edge = observation_gait_window(
                        observations, args.observation_gait_window)
                    gait = torch.where(near_edge, torch.full_like(gait, 2),
                                       torch.full_like(gait, 3))
                    return (gait, *state) if state else gait

                primitive_actor = sensor_selected_primitive

            if args.observation_gap_duty_window is not None:
                original_modulation_actor = modulation_actor

                def sensor_selected_duty(observations, *actor_args):
                    selected = original_modulation_actor(observations, *actor_args)
                    if isinstance(selected, tuple):
                        actions, *state = selected
                    else:
                        actions, state = selected, []
                    near_gap = observation_gap_window(
                        observations, *args.observation_gap_duty_window)
                    actions = actions.clone()
                    actions[near_gap, 17] = args.observation_gap_duty_action
                    return (actions, *state) if state else actions

                modulation_actor = sensor_selected_duty

            return (primitive_actor, modulation_actor, *other_actors)

        MultiInteroceptivePolicyRunner.get_inference_policy = get_inference_policy_with_actor_scan_rules
    evaluation.EvaluationEnv = DynamicsJumpEvaluationEnv
    sys.argv = [sys.argv[0], '--output', str(args.output), *remaining]
    evaluation.main()

    env = DynamicsJumpEvaluationEnv.latest
    report_path = args.output / 'report.json'
    report = json.loads(report_path.read_text())
    arrays = {name: getattr(env, name).cpu().tolist() for name in (
        'first_arm_x', 'first_launch_x', 'first_flight_x',
        'first_landing_x', 'arm_kind', 'eval_launches',
        'eval_flights', 'eval_landings')}
    for group in report['groups']:
        for episode in group['episodes']:
            episode.update({name: values[episode['env']]
                            for name, values in arrays.items()})
    report['dynamics_jump_probe'] = {
        'controller': 'DynamicsOnlyJumpDynamics',
        'disable_reflex': args.disable_reflex,
        'oracle_arming': False,
        'actor_critic_observation_changed': False,
        'trigger_inputs': ['front and rear equilibrium targets',
                           'filtered gait frequency', 'front foot force xyz',
                           'body forward velocity for gap run-up'],
        'armed': sum(x == x for x in arrays['first_arm_x']),
        'launched': sum(x == x for x in arrays['first_launch_x']),
        'airborne': sum(x == x for x in arrays['first_flight_x']),
        'landed': sum(x == x for x in arrays['first_landing_x']),
        'jump_modulation': env.ID.jump_modulation.cpu().tolist(),
        'disable_hurdle_preparation': args.disable_hurdle_preparation,
        'gap_runup_distance': env.ID.gap_runup_distance,
        'gap_landing_x_modulation': env.ID.gap_landing_x_modulation,
        'gap_speed_landing_shift': env.ID.gap_speed_landing_shift,
        'push_stroke': env.ID.jump_reflex.push_stroke.cpu().tolist(),
        'landing_min_contacts': env.ID.jump_reflex.landing_min_contacts,
        'observation_gait_window': args.observation_gait_window,
        'observation_gap_duty_window': args.observation_gap_duty_window,
        'observation_gap_duty_action': args.observation_gap_duty_action,
    }
    report_path.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()

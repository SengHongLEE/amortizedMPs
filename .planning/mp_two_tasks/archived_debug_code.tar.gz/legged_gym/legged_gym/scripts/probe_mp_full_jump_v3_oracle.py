"""Probe an action-modulated V3 jump with a V1 continuous policy control.

The existing checkpoint was not trained for V3. Use --jump-continuous to
compare candidate action settings under the same oracle jump timing.
"""
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'legged_gym'), str(ROOT / 'rsl_rl')]
os.environ.setdefault('TORCH_EXTENSIONS_DIR',
                      str(ROOT / 'legged_gym/legged_gym/test/torch_extensions'))

from isaacgym import gymapi  # noqa: F401; before torch.

from legged_gym.scripts import probe_mp_full_jump_v2_oracle as probe
from legged_gym.utils.dynamics.a1.jump_dynamics_v3 import (
    JumpAdaptiveEquilibriumDynamicsV3)


def main():
    probe.V2OracleEvaluationEnv.controller_class = (
        JumpAdaptiveEquilibriumDynamicsV3)
    probe.V2OracleEvaluationEnv.controller_name = 'contact_reflex_v3_modulated'
    probe.main()


if __name__ == '__main__':
    main()

"""Train the two-policy MP_full_a1 task from scratch with 18 continuous actions.

Example:
  python train_mp_full_optimized.py --task MP_full_a1 --headless
"""
import argparse
import hashlib
import json
import math
from pathlib import Path
import sys

from isaacgym import gymapi  # Isaac Gym must load before torch.

from legged_gym.envs import *  # register MP_full_a1
from legged_gym.utils import get_args, task_registry


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--iterations', type=int)
    parser.add_argument('--num-envs', type=int)
    parser.add_argument('--rollout-steps-per-env', type=int)
    parser.add_argument('--initial-level', type=int)
    parser.add_argument('--learning-rate', type=float)
    parser.add_argument('--promote-distance', type=float)
    parser.add_argument('--episode-seconds', type=float)
    parser.add_argument('--gamma', type=float)
    parser.add_argument('--gae-lambda', type=float)
    parser.add_argument('--rear-forward-stroke-limit', type=float)
    parser.add_argument('--nominal-clearance', type=float)
    parser.add_argument('--primitive-update-cycle', type=int)
    parser.add_argument('--modulation-update-cycle', type=int)
    parser.add_argument('--feet-stumble-scale', type=float)
    parser.add_argument('--termination-scale', type=float)
    parser.add_argument('--heading-error-scale', type=float)
    parser.add_argument('--lane-heading-gain', type=float)
    parser.add_argument('--observe-lane-offset', action='store_true')
    parser.add_argument('--include-pronk', action='store_true',
                        help='Train a new five-primitive policy including four-leg-synchronous pronk.')
    parser.add_argument('--variable-stance-extension', action='store_true',
                        help='Let the four clearance actions extend the legs during pronk stance.')
    parser.add_argument('--stance-extension-limit', type=float, default=.02)
    known, remaining = parser.parse_known_args()
    sys.argv = [sys.argv[0], *remaining]
    args = get_args()
    if args.task not in ('MP_full_a1', 'MP_full_signed_dense_a1',
                         'MP_full_signed_dense_obstacle_aware_a1',
                         'MP_full_signed_dense_flat_tracking_a1'):
        parser.error('this launcher requires an MP_full_a1 terrain task')
    if known.iterations is not None and known.iterations < 1:
        parser.error('--iterations must be positive')
    if known.num_envs is not None and known.num_envs < 16:
        parser.error('--num-envs must be at least 16 for the configured terrain columns')
    if known.rollout_steps_per_env is not None and known.rollout_steps_per_env < 1:
        parser.error('--rollout-steps-per-env must be positive')
    if known.learning_rate is not None and (not math.isfinite(known.learning_rate)
                                             or known.learning_rate <= 0):
        parser.error('--learning-rate must be positive and finite')
    if known.promote_distance is not None and (
            not math.isfinite(known.promote_distance) or known.promote_distance <= 0):
        parser.error('--promote-distance must be positive and finite')
    if known.episode_seconds is not None and (
            not math.isfinite(known.episode_seconds) or known.episode_seconds <= 0):
        parser.error('--episode-seconds must be positive and finite')
    if known.gamma is not None and (
            not math.isfinite(known.gamma) or not 0 < known.gamma < 1):
        parser.error('--gamma must lie strictly between 0 and 1')
    if known.gae_lambda is not None and (
            not math.isfinite(known.gae_lambda) or not 0 <= known.gae_lambda <= 1):
        parser.error('--gae-lambda must lie between 0 and 1')
    if known.rear_forward_stroke_limit is not None and (
            not math.isfinite(known.rear_forward_stroke_limit)
            or not 0 < known.rear_forward_stroke_limit <= .2):
        parser.error('--rear-forward-stroke-limit must lie in (0, 0.2] metres')
    if known.nominal_clearance is not None and (
            not math.isfinite(known.nominal_clearance)
            or not .06 <= known.nominal_clearance <= .2):
        parser.error('--nominal-clearance must lie in [0.06, 0.2] metres')
    if known.primitive_update_cycle is not None and known.primitive_update_cycle < 1:
        parser.error('--primitive-update-cycle must be positive')
    if known.modulation_update_cycle is not None and known.modulation_update_cycle < 1:
        parser.error('--modulation-update-cycle must be positive')
    if known.feet_stumble_scale is not None and (
            not math.isfinite(known.feet_stumble_scale) or known.feet_stumble_scale > 0):
        parser.error('--feet-stumble-scale must be finite and nonpositive')
    if known.termination_scale is not None and (
            not math.isfinite(known.termination_scale) or known.termination_scale > 0):
        parser.error('--termination-scale must be finite and nonpositive')
    if known.heading_error_scale is not None and (
            not math.isfinite(known.heading_error_scale) or known.heading_error_scale > 0):
        parser.error('--heading-error-scale must be finite and nonpositive')
    if known.lane_heading_gain is not None and (
            not math.isfinite(known.lane_heading_gain) or known.lane_heading_gain < 0):
        parser.error('--lane-heading-gain must be finite and nonnegative')
    if not math.isfinite(known.stance_extension_limit) or not 0 <= known.stance_extension_limit <= .05:
        parser.error('--stance-extension-limit must be in [0, 0.05] metres')

    env_cfg, train_cfg = task_registry.get_cfgs(args.task)
    if known.include_pronk:
        if env_cfg.env.num_primitives == 4:
            env_cfg.env.num_primitives = 5
            env_cfg.asset.gait_step_length_scales = [
                *env_cfg.asset.gait_step_length_scales, 1.]
        elif env_cfg.env.num_primitives != 5:
            parser.error('--include-pronk requires a four- or five-primitive base config')
        train_cfg.runner.run_name += '-pronk5'
    if known.variable_stance_extension:
        if env_cfg.env.num_primitives != 5:
            parser.error('--variable-stance-extension requires five primitives')
        env_cfg.asset.stance_extension_gait_id = 4
        env_cfg.asset.max_stance_extension = known.stance_extension_limit
        train_cfg.runner.run_name += f'-stance{known.stance_extension_limit:g}'
    if known.initial_level is not None:
        if not 0 <= known.initial_level < env_cfg.terrain.num_rows:
            parser.error('--initial-level must be a valid terrain row')
        env_cfg.terrain.curriculum_initial_level = known.initial_level
    if known.num_envs is not None:
        env_cfg.env.num_envs = known.num_envs
    if known.rollout_steps_per_env is not None:
        train_cfg.runner.num_steps_per_env = known.rollout_steps_per_env
        train_cfg.runner.run_name += f'-roll{known.rollout_steps_per_env}'
    if known.learning_rate is not None:
        train_cfg.algorithm.learning_rate = known.learning_rate
    if known.promote_distance is not None:
        env_cfg.terrain.curriculum_promote_distance = known.promote_distance
    if known.episode_seconds is not None:
        env_cfg.env.episode_length_s = known.episode_seconds
    if known.gamma is not None:
        train_cfg.algorithm.gamma = known.gamma
    if known.gae_lambda is not None:
        train_cfg.algorithm.lam = known.gae_lambda
    if known.rear_forward_stroke_limit is not None:
        env_cfg.asset.rear_forward_stroke_limit = known.rear_forward_stroke_limit
    if known.nominal_clearance is not None:
        env_cfg.asset.ground_clearance = known.nominal_clearance
        train_cfg.runner.run_name += f'-clear{known.nominal_clearance:g}'
    if known.primitive_update_cycle is not None:
        env_cfg.control.primitive_selection_update_cycle = known.primitive_update_cycle
    if known.modulation_update_cycle is not None:
        env_cfg.control.modulation_param_update_cycle = known.modulation_update_cycle
        train_cfg.runner.run_name += f'-modC{known.modulation_update_cycle}'
    if known.primitive_update_cycle is not None:
        train_cfg.runner.run_name += f'-primC{known.primitive_update_cycle}'
    if known.feet_stumble_scale is not None:
        env_cfg.rewards.scales.feet_stumble = known.feet_stumble_scale
        train_cfg.runner.run_name += f'-stumble{abs(known.feet_stumble_scale):g}'
    if known.termination_scale is not None:
        env_cfg.rewards.scales.termination = known.termination_scale
        train_cfg.runner.run_name += f'-term{abs(known.termination_scale):g}'
    if known.heading_error_scale is not None:
        env_cfg.rewards.scales.orientation_yaw = known.heading_error_scale
        env_cfg.rewards.primitive_selection_scales.orientation_yaw = known.heading_error_scale
        train_cfg.runner.run_name += f'-yaw{abs(known.heading_error_scale):g}'
    if known.lane_heading_gain is not None:
        env_cfg.commands.lane_heading_gain = known.lane_heading_gain
        train_cfg.runner.run_name += f'-lane{known.lane_heading_gain:g}'
    if known.observe_lane_offset:
        env_cfg.env.observe_lane_offset = True
        train_cfg.runner.run_name += '-laneObs'
    train_cfg.runner.resume = False
    env, env_cfg = task_registry.make_env(args.task, args=args, env_cfg=env_cfg)
    runner, train_cfg = task_registry.make_alg_runner(
        env, name=args.task, args=args, train_cfg=train_cfg, env_cfg=env_cfg)
    root = Path(__file__).resolve().parents[3]
    source_files = (
        'legged_gym/legged_gym/envs/a1/mp_full.py',
        'legged_gym/legged_gym/envs/a1/mp_full_config.py',
        'legged_gym/legged_gym/utils/dynamics/a1/equilibrium_dynamics.py',
        'legged_gym/legged_gym/utils/dynamics/a1/rhythmic_dynamics.py',
        'legged_gym/legged_gym/utils/terrains/blind_terrain.py',
        'legged_gym/legged_gym/utils/terrains/terrain_curriculum.py',
        'legged_gym/legged_gym/utils/signed_scan.py',
        'rsl_rl/rsl_rl/modules/actor_critic.py',
        'rsl_rl/rsl_rl/modules/reservoir_actors.py',
        'rsl_rl/rsl_rl/modules/terrain_scan_encoder.py',
        'rsl_rl/rsl_rl/runners/multi_interoceptive_policy_runner.py',
    )
    if args.task in ('MP_full_signed_dense_obstacle_aware_a1',
                     'MP_full_signed_dense_flat_tracking_a1'):
        source_files += ('legged_gym/legged_gym/envs/a1/mp_full_obstacle_aware.py',)
    manifest = dict(action_space=env_cfg.env.action_space,
                    continuous_actions=env_cfg.env.num_modulation_params,
                    source_sha256={
        name: hashlib.sha256((root / name).read_bytes()).hexdigest() for name in source_files})
    (Path(runner.log_dir) / 'run_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    runner.learn(known.iterations or train_cfg.runner.max_iterations,
                 init_at_random_ep_len=False)


if __name__ == '__main__':
    main()

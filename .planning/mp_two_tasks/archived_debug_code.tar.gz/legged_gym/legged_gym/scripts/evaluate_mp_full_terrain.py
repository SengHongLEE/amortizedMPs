"""Evaluate obstacle traversal and locomotion on MP_full_a1 terrain.

Runs one episode per environment with a fixed forward command. For gap and
hurdle, the requested target is measured after the rear of the robot clears
the selected band; the two-tile mode crosses into the next terrain cell.
Results include falls, travel distance, and action saturation.
"""
import argparse
import contextlib
import hashlib
import json
import os
from pathlib import Path
import sys
import time

ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'legged_gym'), str(ROOT / 'rsl_rl')]
os.environ.setdefault('TORCH_EXTENSIONS_DIR', str(ROOT / 'legged_gym/legged_gym/test/torch_extensions'))

from isaacgym import gymapi, gymutil
import numpy as np
import torch

from legged_gym.envs.a1.mp_full import MotorPrimitives
from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg, MotorPrimitivesCfgPPO
from legged_gym.utils import load_run_config
from legged_gym.utils.helpers import class_to_dict, set_seed
from legged_gym.utils.terrain_evaluation import TraversalMetrics
from legged_gym.utils.terrains.blind_terrain import obstacle_bands
from rsl_rl.runners.full_policy_runner import FullPolicyRunner
from rsl_rl.runners.multi_interoceptive_policy_runner import MultiInteroceptivePolicyRunner


class EvaluationEnv(MotorPrimitives):
    def _get_env_origins(self):
        super()._get_env_origins()
        ids = torch.arange(self.num_envs, device=self.device)
        self.speed_ids = ids % len(self.test_speeds)
        tile = ids // (len(self.test_speeds) * self.repeats)
        self.terrain_types[:] = tile % self.cfg.terrain.num_cols
        self.terrain_levels[:] = self.course_row_stride * (tile // self.cfg.terrain.num_cols)
        self.env_origins[:] = self.terrain_origins[self.terrain_levels, self.terrain_types]
        self.eval_commands = torch.tensor(self.test_speeds, device=self.device)[self.speed_ids]

    def _resample_commands(self, env_ids):
        self.commands[env_ids] = 0.
        self.commands[env_ids, 0] = self.eval_commands[env_ids]

    def check_termination(self, env_ids=None):
        super().check_termination(env_ids)
        if self.eval_min_base_clearance is not None:
            ground = self._get_terrain_heights(self.root_states[:, :2])
            base_contact = torch.any(
                torch.norm(self.contact_forces[:, self.termination_contact_indices], dim=-1) > 1.,
                dim=1)
            self.terrain_low_clearance_buf = (
                self.root_states[:, 2] - ground < self.eval_min_base_clearance)
            self.terrain_failure_buf = (base_contact | self.terrain_low_clearance_buf
                                        | self.terrain_lane_exit_buf)
            self.time_out_buf &= ~self.terrain_failure_buf
            self.reset_buf = self.terrain_failure_buf | self.time_out_buf
        if getattr(self, 'metrics', None) is not None:
            active = self.metrics.active.clone()
            qx, qy, qz, qw = self.root_states[:, 3:7].unbind(-1)
            heading = torch.atan2(2 * (qw * qz + qx * qy),
                                  1 - 2 * (qy.square() + qz.square()))
            self.eval_final_heading = torch.where(active, heading, self.eval_final_heading)
            base_contact = torch.any(
                torch.norm(self.contact_forces[:, self.termination_contact_indices], dim=-1) > 1.,
                dim=1)
            self.eval_base_contact_falls |= active & self.terrain_failure_buf & base_contact
            self.eval_low_height_falls |= active & self.terrain_failure_buf & self.terrain_low_clearance_buf
            self.eval_lane_exit_falls |= active & self.terrain_failure_buf & self.terrain_lane_exit_buf
            leg_contact = torch.any(
                torch.norm(self.contact_forces[:, self.penalised_contact_indices], dim=-1) > .1,
                dim=1)
            rear_calf_contact = torch.any(
                torch.norm(self.contact_forces[:, self.eval_rear_calf_indices], dim=-1) > .1,
                dim=1)
            self.eval_leg_contact_steps += active * leg_contact
            self.eval_rear_calf_contact_steps += active * rear_calf_contact
            self.eval_active_steps += active
            if getattr(self, 'trace_env_ids', None) is not None:
                ids = self.trace_env_ids
                feet = self.rigid_body_state.view(
                    self.num_envs, self.num_bodies, 13)[:, self.feet_indices, :3]
                sample = dict(
                    active=active[ids], time=self.episode_length_buf[ids] * self.dt,
                    root=self.root_states[ids], feet=feet[ids],
                    foot_force=self.contact_forces[ids[:, None], self.feet_indices],
                    rear_calf_force=self.contact_forces[ids[:, None], self.eval_rear_calf_indices],
                    phase=self.ID.X[ids, 2], amplitude=self.ID.X[ids, :2],
                    cpg_x=self.ID.x[ids], cpg_z=self.ID.z[ids],
                    q_obstacle=self.ID.q_obstacle[ids], gait=self.ID._gait_ids[ids],
                    stance_extension=self.ID.stance_extension[ids],
                    actions=self.actions[ids], commands=self.commands[ids],
                    measured_heights=self.measured_heights[ids],
                    base_contact=base_contact[ids],
                    low_clearance=self.terrain_low_clearance_buf[ids],
                    lane_exit=self.terrain_lane_exit_buf[ids],
                    failed=self.terrain_failure_buf[ids], timeout=self.time_out_buf[ids],
                )
                for name, value in sample.items():
                    self.trace_samples.setdefault(name, []).append(
                        value.detach().cpu().numpy().copy())
            self.metrics.update(
                self.root_states[:, :2] - self.env_origins[:, :2],
                self.terrain_failure_buf, self.time_out_buf,
                (self.base_lin_vel[:, 0] - self.eval_commands).abs(), self.dt)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--terrains', nargs='+')
    parser.add_argument('--difficulties', type=float, nargs='+', default=[.5, .75, 1.])
    parser.add_argument('--speeds', type=float, nargs='+', default=[.5, .8, 1.2])
    parser.add_argument('--repeats', type=int, default=16)
    parser.add_argument('--seconds', type=float, default=10.)
    parser.add_argument('--seed', type=int, default=123)
    parser.add_argument('--terrain-seed', type=int, default=1)
    parser.add_argument('--corridor', type=float, default=1.5)
    parser.add_argument('--max-step-length', type=float)
    parser.add_argument('--nominal-clearance', type=float)
    parser.add_argument('--rear-forward-stroke-limit', type=float)
    parser.add_argument('--hazard-spacing', type=float)
    parser.add_argument('--canter-step-scale', type=float)
    parser.add_argument('--gait-frequency-scale', type=float, default=1.)
    parser.add_argument('--primitive-update-cycle', type=int)
    parser.add_argument('--modulation-update-cycle', type=int)
    parser.add_argument('--force-primitive', type=int)
    parser.add_argument('--force-pronk-phase', action='store_true',
                        help='With --force-primitive 3, use synchronous four-leg phases '
                             'at the existing bound duty and frequency for an ablation.')
    parser.add_argument('--stance-extension-limit', type=float,
                        help='Enable gait-specific variable stance extension up to this many metres.')
    parser.add_argument('--hazard-target', choices=('first_band', 'promotion', 'tile_exit',
                                                   'second_band', 'next_tile_second_band'),
                        default='first_band')
    parser.add_argument('--min-base-clearance', type=float)
    parser.add_argument('--align-stroke', action='store_true')
    parser.add_argument('--lane-offset-observation', action='store_true')
    parser.add_argument('--lane-heading-gain', type=float)
    parser.add_argument('--heading-kp', type=float)
    parser.add_argument('--trace-env-ids', type=int, nargs='+',
                        help='Save pre-reset foot, contact, phase and observation traces for these environments.')
    args = parser.parse_args()
    if args.force_pronk_phase and args.force_primitive != 3:
        parser.error('--force-pronk-phase requires --force-primitive 3')
    if args.stance_extension_limit is not None and args.force_primitive is None:
        parser.error('--stance-extension-limit requires --force-primitive')
    if (args.repeats < 1 or args.seconds <= 0 or args.corridor <= 0
            or not args.speeds or min(args.speeds) <= 0
            or not args.difficulties or min(args.difficulties) < 0
            or max(args.difficulties) > 1
            or (args.max_step_length is not None and args.max_step_length <= 0)
            or (args.nominal_clearance is not None
                and (not np.isfinite(args.nominal_clearance)
                     or not .06 <= args.nominal_clearance <= .20))
            or (args.rear_forward_stroke_limit is not None
                and (not np.isfinite(args.rear_forward_stroke_limit)
                     or args.rear_forward_stroke_limit <= 0))
            or (args.hazard_spacing is not None
                and (not np.isfinite(args.hazard_spacing) or args.hazard_spacing <= 0))
            or (args.canter_step_scale is not None and args.canter_step_scale <= 0)
            or args.gait_frequency_scale <= 0
            or (args.primitive_update_cycle is not None and args.primitive_update_cycle < 1)
            or (args.modulation_update_cycle is not None and args.modulation_update_cycle < 1)
            or (args.lane_heading_gain is not None
                and (not np.isfinite(args.lane_heading_gain) or args.lane_heading_gain < 0))
            or (args.heading_kp is not None
                and (not np.isfinite(args.heading_kp) or args.heading_kp <= 0))
            or (args.min_base_clearance is not None
                and not 0 < args.min_base_clearance < .3)
            or (args.stance_extension_limit is not None and
                (not np.isfinite(args.stance_extension_limit)
                 or not 0 <= args.stance_extension_limit <= .05))):
        parser.error('positive repeats, seconds and speeds, and difficulties in [0,1] are required')
    checkpoint = args.checkpoint.resolve()
    cfg, train = load_run_config(MotorPrimitivesCfg(), MotorPrimitivesCfgPPO(), checkpoint.parent)
    if args.primitive_update_cycle is not None:
        cfg.control.primitive_selection_update_cycle = args.primitive_update_cycle
    if args.modulation_update_cycle is not None:
        cfg.control.modulation_param_update_cycle = args.modulation_update_cycle
    # Use the exact saved policy/runner fields. The current config class may
    # omit legacy third-actor fields, and must not enable new squashing on an
    # old checkpoint that was trained with raw Gaussian actions.
    saved_config = json.loads((checkpoint.parent / 'config.json').read_text())
    if (saved_config.get('env', {}).get('num_modulation_params') != 18
            or saved_config.get('env', {}).get('action_space') != 'cpg_equilibrium_v3'):
        parser.error('this evaluator supports only new 18-action cpg_equilibrium_v3 checkpoints')
    cfg.env.observe_lane_offset = (saved_config.get('env', {}).get('observe_lane_offset', False)
                                   or args.lane_offset_observation)
    cfg.commands.lane_heading_gain = saved_config.get('commands', {}).get('lane_heading_gain', 0.)
    cfg.commands.heading_kp = saved_config.get('commands', {}).get('heading_kp', 0.5)
    if args.lane_heading_gain is not None:
        cfg.commands.lane_heading_gain = args.lane_heading_gain
    if args.heading_kp is not None:
        cfg.commands.heading_kp = args.heading_kp
    saved_terrain = saved_config.get('terrain', {})
    cfg.terrain.min_base_clearance = saved_terrain.get('min_base_clearance', .15)
    cfg.terrain.hurdle_min_base_clearance = saved_terrain.get('hurdle_min_base_clearance', .15)
    cfg.terrain.curriculum_gap_min_level = saved_terrain.get('curriculum_gap_min_level', 0)
    cfg.terrain.hazard_lane_half_width = saved_terrain.get(
        'hazard_lane_half_width',
        cfg.terrain.terrain_width / 2 - cfg.terrain.boundary_margin)
    cfg.asset.gait_step_length_scales = saved_config.get('asset', {}).get(
        'gait_step_length_scales', [1.] * cfg.env.num_primitives)
    if 'obstacle_clearance' not in saved_config.get('rewards', {}).get('scales', {}):
        cfg.rewards.scales.obstacle_clearance = 0.
    train_data = {key: saved_config[key] for key in
                  ('seed', 'runner_class_name', 'policy', 'algorithm', 'runner')}
    enabled = [name for name, weight in cfg.terrain.terrain_proportions.items() if weight > 0]
    selected = args.terrains or enabled
    if args.force_primitive is not None and not 0 <= args.force_primitive < cfg.env.num_primitives:
        parser.error('--force-primitive must be a valid gait index')
    if any(name not in enabled for name in selected) or len(set(selected)) != len(selected):
        parser.error('--terrains must contain distinct types enabled in the saved config')
    columns = [name for name in selected for _ in range(2)]
    cfg.env.num_envs = len(columns) * len(args.difficulties) * args.repeats * len(args.speeds)
    if args.trace_env_ids is not None and (
            len(set(args.trace_env_ids)) != len(args.trace_env_ids)
            or min(args.trace_env_ids) < 0
            or max(args.trace_env_ids) >= cfg.env.num_envs):
        parser.error('--trace-env-ids must be distinct indices in the evaluation environment')
    cfg.env.play = False
    cfg.env.episode_length_s = args.seconds
    cfg.noise.add_noise = False
    cfg.domain_rand.randomize_friction = False
    cfg.domain_rand.randomize_base_mass = False
    cfg.domain_rand.push_robots = False
    cfg.terrain.curriculum = False
    cfg.terrain.fixed_terrain_level = None
    cfg.terrain.max_init_terrain_level = None
    two_tile_course = args.hazard_target == 'next_tile_second_band'
    course_row_stride = 2 if two_tile_course else 1
    cfg.terrain.num_rows, cfg.terrain.num_cols = (
        course_row_stride * len(args.difficulties), len(columns))
    cfg.terrain.selected = cfg.terrain.selected_kwargs = None
    cfg.terrain.terrain_columns = columns
    cfg.terrain.row_difficulties = [difficulty for difficulty in args.difficulties
                                    for _ in range(course_row_stride)]
    cfg.terrain.seed = args.terrain_seed
    if args.hazard_spacing is not None:
        for name in ('gap', 'hurdle'):
            cfg.terrain.terrain_params[name]['spacing'] = args.hazard_spacing
    if args.max_step_length is not None:
        cfg.asset.max_step_length = args.max_step_length
    if args.nominal_clearance is not None:
        cfg.asset.ground_clearance = args.nominal_clearance
    if args.rear_forward_stroke_limit is not None:
        cfg.asset.rear_forward_stroke_limit = args.rear_forward_stroke_limit
    if args.canter_step_scale is not None:
        cfg.asset.gait_step_length_scales[2] = args.canter_step_scale

    params = gymapi.SimParams()
    gymutil.parse_sim_config(class_to_dict(cfg.sim), params)
    params.use_gpu_pipeline = params.physx.use_gpu = True
    EvaluationEnv.repeats, EvaluationEnv.test_speeds = args.repeats, args.speeds
    EvaluationEnv.course_row_stride = course_row_stride
    EvaluationEnv.eval_min_base_clearance = args.min_base_clearance
    set_seed(args.seed)
    env = EvaluationEnv(cfg, params, gymapi.SIM_PHYSX, 'cuda:0', True)
    try:
        if args.force_pronk_phase:
            # Isolate leg synchrony without changing the checkpoint action space.
            # This probes an untrained gait; it does not measure a retrained policy.
            env.ID._primitive_phases[3].zero_()
        if args.stance_extension_limit is not None:
            env.ID.stance_extension_gait_id = args.force_primitive
            env.ID.max_stance_extension = args.stance_extension_limit
        env.ID._primitive_frequencies.mul_(args.gait_frequency_scale)
        if args.align_stroke:
            env.ID.align_stroke = True
        classes = {'FullPolicyRunner': FullPolicyRunner,
                   'MultiInteroceptivePolicyRunner': MultiInteroceptivePolicyRunner}
        runner_class = classes[train.runner_class_name]
        runner = runner_class(env, train_data, log_dir=None, device=env.device)
        runner.load(str(checkpoint), load_optimizer=False)
        actors = runner.get_inference_policy(device=env.device)
        if args.force_primitive is not None:
            primitive_actor = actors[0]

            def fixed_primitive_actor(*actor_args):
                result = primitive_actor(*actor_args)
                if isinstance(result, tuple):
                    gait, state = result
                    return torch.full_like(gait, args.force_primitive), state
                return torch.full_like(result, args.force_primitive)

            actors = (fixed_primitive_actor, *actors[1:])
        set_seed(args.seed)
        obs, _ = env.reset()
        root_start = env.root_states.detach().cpu().numpy().copy()
        joint_start = env.dof_pos.detach().cpu().numpy().copy()
        targets = []
        for row in range(len(args.difficulties)):
            first_row = course_row_stride * row
            for col, name in enumerate(columns):
                kind = env.terrain._kind(name)
                if kind in ('gap', 'hurdle'):
                    params = env.terrain.tile_parameters[
                        first_row + (1 if two_tile_course else 0), col]
                    length = env.terrain.length_per_env_pixels
                    forward = [end for start, end in obstacle_bands(
                        length, env.terrain.horizontal_scale, params, kind)
                        if start >= length // 2]
                    if not forward:
                        parser.error(f'{name} has no forward obstacle band')
                    first_band = ((length if two_tile_course else 0.)
                                  + forward[0] - length / 2) * env.terrain.horizontal_scale + .35
                    if args.hazard_target == 'promotion':
                        distance = max(first_band, cfg.terrain.curriculum_promote_distance)
                    elif args.hazard_target == 'tile_exit':
                        distance = cfg.terrain.terrain_length / 2 - cfg.terrain.boundary_margin
                    elif args.hazard_target == 'second_band':
                        distance = ((forward[min(1, len(forward) - 1)] - length / 2)
                                    * env.terrain.horizontal_scale + .35)
                    elif two_tile_course:
                        distance = ((length + forward[min(1, len(forward) - 1)] - length / 2)
                                    * env.terrain.horizontal_scale + .35)
                    else:
                        distance = first_band
                else:
                    distance = ((cfg.terrain.terrain_length if two_tile_course else 0.)
                                + cfg.terrain.terrain_length / 2
                                - cfg.terrain.boundary_margin)
                targets.extend([distance] * args.repeats * len(args.speeds))
        env.metrics = TraversalMetrics(env.num_envs, env.device,
                                       torch.tensor(targets, device=env.device), args.corridor)
        env.eval_base_contact_falls = torch.zeros(env.num_envs, device=env.device, dtype=torch.bool)
        env.eval_low_height_falls = torch.zeros_like(env.eval_base_contact_falls)
        env.eval_lane_exit_falls = torch.zeros_like(env.eval_base_contact_falls)
        env.eval_final_heading = torch.zeros(env.num_envs, device=env.device)
        env.eval_leg_contact_steps = torch.zeros(env.num_envs, device=env.device)
        env.eval_rear_calf_indices = torch.tensor([
            env.gym.find_actor_rigid_body_handle(env.envs[0], env.actor_handles[0], name)
            for name in ('RL_calf', 'RR_calf')], device=env.device, dtype=torch.long)
        if (env.eval_rear_calf_indices < 0).any():
            raise RuntimeError('A1 rear calf rigid bodies were not found')
        env.eval_rear_calf_contact_steps = torch.zeros_like(env.eval_leg_contact_steps)
        env.eval_active_steps = torch.zeros_like(env.eval_leg_contact_steps)
        env.trace_env_ids = (torch.tensor(args.trace_env_ids, device=env.device, dtype=torch.long)
                             if args.trace_env_ids is not None else None)
        env.trace_samples = {}
        near_limit = torch.zeros(env.num_envs, device=env.device)
        raw_outside = torch.zeros_like(near_limit)
        raw_abs_sum = torch.zeros_like(near_limit)
        action_samples = torch.zeros_like(near_limit)
        gait_samples = torch.zeros(env.num_envs, cfg.env.num_primitives, device=env.device)
        timing_sum = torch.zeros(env.num_envs, 2, device=env.device)
        modulation_sum = torch.zeros(env.num_envs, cfg.env.num_modulation_params, device=env.device)
        start = time.time()
        with open(os.devnull, 'w') as quiet, torch.inference_mode():
            for step in range(round(args.seconds / env.dt)):
                active = env.metrics.active.clone()
                with contextlib.redirect_stdout(quiet):
                    obs, _, _, _, _ = runner.inference_rollout(obs, *actors)
                applied = env.actions[:, 1:1 + cfg.env.num_modulation_params]
                raw = runner.modulation_params
                near_limit += active * (applied.abs() >= .95).float().mean(-1)
                raw_outside += active * (raw.abs() >= 1.).float().mean(-1)
                raw_abs_sum += active * raw.abs().mean(-1)
                action_samples += active
                modulation_sum += active[:, None] * raw
                gait_samples += active[:, None] * torch.nn.functional.one_hot(
                    runner.primitive_selections.long(), cfg.env.num_primitives)
                timing_sum += active[:, None] * raw[:, 16:18]
                if step % 100 == 0:
                    print(f'{step * env.dt:.1f}s simulated; {time.time()-start:.1f}s wall; '
                          f'{env.metrics.active.sum().item()} active', flush=True)
                if not env.metrics.active.any():
                    break
        records = env.metrics.records()
        base_contact_falls = env.eval_base_contact_falls.cpu().tolist()
        low_height_falls = env.eval_low_height_falls.cpu().tolist()
        lane_exit_falls = env.eval_lane_exit_falls.cpu().tolist()
        final_headings = env.eval_final_heading.cpu().tolist()
        leg_contact_fraction = (
            env.eval_leg_contact_steps / env.eval_active_steps.clamp_min(1)).cpu().tolist()
        rear_calf_contact_fraction = (
            env.eval_rear_calf_contact_steps / env.eval_active_steps.clamp_min(1)).cpu().tolist()
        saturation = (near_limit / action_samples.clamp_min(1)).cpu().tolist()
        raw_outside_fraction = (raw_outside / action_samples.clamp_min(1)).cpu().tolist()
        raw_abs_mean = (raw_abs_sum / action_samples.clamp_min(1)).cpu().tolist()
        gait_fractions = (gait_samples / action_samples.clamp_min(1)[:, None]).cpu().tolist()
        timing_means = (timing_sum / action_samples.clamp_min(1)[:, None]).cpu().tolist()
        modulation_means = (modulation_sum / action_samples.clamp_min(1)[:, None]).cpu().tolist()
        for (record, fraction, outside, magnitude, gaits, timing, modulation,
             base_contact, low_height, lane_exit, final_heading, leg_contact,
             rear_calf_contact) in zip(
                records, saturation, raw_outside_fraction, raw_abs_mean,
                gait_fractions, timing_means, modulation_means,
                base_contact_falls, low_height_falls, lane_exit_falls,
                final_headings, leg_contact_fraction, rear_calf_contact_fraction):
            record['action_near_limit_fraction'] = fraction
            record['raw_action_outside_fraction'] = outside
            record['raw_action_abs_mean'] = magnitude
            record['primitive_fractions'] = gaits
            record['modulation_action_mean'] = modulation
            record['base_contact_fall'] = base_contact
            record['low_height_fall'] = low_height
            record['lane_exit_failure'] = lane_exit
            record['final_heading'] = final_heading
            record['leg_contact_step_fraction'] = leg_contact
            record['rear_calf_contact_step_fraction'] = rear_calf_contact
            record['timing_action_mean'] = timing
        groups = []
        for row, difficulty in enumerate(args.difficulties):
            for col, name in enumerate(columns):
                for speed_id, speed in enumerate(args.speeds):
                    first = (row * len(columns) + col) * args.repeats * len(args.speeds) + speed_id
                    episodes = [dict(env=i, **records[i]) for i in
                                range(first, first + args.repeats * len(args.speeds), len(args.speeds))]
                    groups.append(dict(terrain=name, difficulty=difficulty, speed=speed,
                                       target_distance=targets[first],
                                       parameters=env.terrain.tile_parameters[
                                           course_row_stride * row, col],
                                       next_tile_parameters=(
                                           env.terrain.tile_parameters[course_row_stride * row + 1, col]
                                           if two_tile_course else None),
                                       success_rate=float(np.mean([e['success'] for e in episodes])),
                                       episodes=episodes))
        report = dict(checkpoint=str(checkpoint), checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
                      source_runner=train.runner_class_name, seed=args.seed, terrain_seed=args.terrain_seed,
                      gait_frequency_scale=args.gait_frequency_scale,
                      primitive_update_cycle=cfg.control.primitive_selection_update_cycle,
                      modulation_update_cycle=cfg.control.modulation_param_update_cycle,
                      canter_step_scale=args.canter_step_scale,
                      nominal_clearance=args.nominal_clearance,
                      rear_forward_stroke_limit=args.rear_forward_stroke_limit,
                      hazard_spacing=args.hazard_spacing,
                      force_primitive=args.force_primitive,
                      force_pronk_phase=args.force_pronk_phase,
                      stance_extension_limit=args.stance_extension_limit,
                      min_base_clearance=args.min_base_clearance,
                      align_stroke=args.align_stroke,
                      lane_offset_observation=cfg.env.observe_lane_offset,
                      lane_heading_gain=cfg.commands.lane_heading_gain,
                      heading_kp=cfg.commands.heading_kp,
                      hazard_target=args.hazard_target,
                      trace_env_ids=args.trace_env_ids,
                      initial_state_sha256=hashlib.sha256(root_start.tobytes() + joint_start.tobytes()).hexdigest(),
                      effective_config=class_to_dict(cfg), groups=groups,
                      notes='First episode; fixed commands; deterministic actors; no pushes or randomization. '
                            'Hazard success uses the requested target; other terrains use the corresponding tile exit. '
                            'The pronk-phase ablation reuses bound duty/frequency and an untrained actor.')
        args.output.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(args.output / 'initial_state.npz', root=root_start, dof_pos=joint_start)
        if env.trace_env_ids is not None:
            np.savez_compressed(
                args.output / 'trace.npz',
                **{name: np.stack(values) for name, values in env.trace_samples.items()},
                env_ids=np.asarray(args.trace_env_ids),
                origins=env.env_origins[env.trace_env_ids].cpu().numpy(),
                dt=env.dt)
        (args.output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
        for name in selected:
            episodes = [ep for group in groups if group['terrain'] == name for ep in group['episodes']]
            print(name, f"{sum(ep['success'] for ep in episodes)}/{len(episodes)}",
                  'falls', sum(ep['failed'] for ep in episodes), flush=True)
    finally:
        env.gym.destroy_sim(env.sim)


if __name__ == '__main__':
    main()

"""Train the isolated four-gait dynamics reflex without changing MP_full_a1.

Example:
  python train_mp_full_dynamics_jump.py --task MP_full_dynamics_jump_a1 \
      --headless --iterations 100 --num-envs 1024 \
      --warmstart-checkpoint /path/to/model_31_320.pt
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'legged_gym'), str(ROOT / 'rsl_rl')]
os.environ.setdefault('TORCH_EXTENSIONS_DIR',
                      str(ROOT / 'legged_gym/legged_gym/test/torch_extensions'))

from isaacgym import gymapi  # noqa: F401; before torch.
import torch

from legged_gym.envs.a1.mp_full_dynamics_jump import register_dynamics_jump_task
from legged_gym.utils import get_args, task_registry


def transfer_gait_policy(source, target):
    """Copy equal-shaped weights and trim only the fifth gait's actor outputs."""
    if source.keys() != target.keys():
        raise ValueError('warmstart policy state keys differ')
    result = {}
    for name, new in target.items():
        old = source[name]
        if old.shape == new.shape:
            result[name] = old.clone()
        elif (name in ('actor.readout.linear_layers.0.weight',
                       'actor.readout.soft_attn.attn.0.weight')
              and old.ndim == new.ndim == 2
              and old.shape[0] == new.shape[0]
              and new.shape[1] == old.shape[1] + 162):
            expanded = torch.zeros_like(new)
            expanded[:, -old.shape[1]:] = old
            result[name] = expanded
        elif (name in ('actor.readout.soft_attn.attn.2.weight',
                       'actor.readout.soft_attn.attn.2.bias')
              and old.ndim == new.ndim
              and new.shape[0] == old.shape[0] + 162
              and new.shape[1:] == old.shape[1:]):
            expanded = torch.zeros_like(new)
            expanded[-old.shape[0]:] = old
            result[name] = expanded
        elif (name in ('actor.readout.output_head.weight',
                       'actor.readout.output_head.bias')
              and old.shape[0] == new.shape[0] + 1
              and old.shape[1:] == new.shape[1:]):
            result[name] = old[:new.shape[0]].clone()
        elif (name == 'std' and old.shape[0] == 10
              and new.shape[0] == 8):
            result[name] = old[:8].clone()
        else:
            raise ValueError(f'cannot warmstart {name}: {old.shape} -> {new.shape}')
    return result


def prefer_starting_gait(state, gait, margin=1.):
    """Give a retained gait a modest initial logit advantage for warmstart."""
    key = 'actor.readout.output_head.bias'
    if key not in state or state[key].shape != (4,):
        raise ValueError('four-gait actor head bias is required')
    if not isinstance(gait, int) or not 0 <= gait < 4:
        raise ValueError('preferred gait must be an index in [0, 3]')
    if not math.isfinite(margin) or margin < 0.:
        raise ValueError('gait logit margin must be finite and nonnegative')
    result = dict(state)
    bias = state[key].clone()
    bias[gait] = bias.max() + margin
    result[key] = bias
    return result


def warmstart_runner(runner, checkpoint, preferred_gait=None, margin=1.):
    saved = torch.load(str(checkpoint), map_location=runner.device,
                       weights_only=True)
    selection = runner.primitive_selection_actor_critic
    modulation = runner.modulation_param_actor_critic
    selection_state = transfer_gait_policy(
        saved['primitive_selection_model_state_dict'],
        selection.state_dict())
    if preferred_gait is not None:
        selection_state = prefer_starting_gait(
            selection_state, preferred_gait, margin)
    selection.load_state_dict(selection_state, strict=True)
    modulation.load_state_dict(transfer_gait_policy(
        saved['modulation_param_model_state_dict'],
        modulation.state_dict()), strict=True)
    runner.current_learning_iteration = 0


def freeze_modulation_learning(algorithm):
    """Keep the obstacle-capable modulation actor fixed while gait selection learns."""
    algorithm.learning_rate = 0.
    algorithm.schedule = 'fixed'
    for group in algorithm.optimizer.param_groups:
        group['lr'] = 0.


def main():
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--iterations', type=int)
    parser.add_argument('--num-envs', type=int)
    parser.add_argument('--warmstart-checkpoint', type=Path)
    parser.add_argument('--warmstart-preferred-gait', type=int)
    parser.add_argument('--warmstart-bias-margin', type=float, default=1.)
    parser.add_argument('--jump-push-stroke', nargs=2, type=float,
                        metavar=('FRONT', 'HIND'))
    parser.add_argument('--jump-gap-runup-distance', type=float)
    parser.add_argument('--jump-gap-landing-x', type=float)
    parser.add_argument('--reflex-alignment-scale', type=float)
    parser.add_argument('--height-edge-head', action='store_true')
    parser.add_argument('--freeze-modulation', action='store_true')
    known, remaining = parser.parse_known_args()
    sys.argv = [sys.argv[0], *remaining]
    args = get_args()
    if args.task != 'MP_full_dynamics_jump_a1':
        parser.error('use --task MP_full_dynamics_jump_a1')
    if known.iterations is not None and known.iterations < 1:
        parser.error('--iterations must be positive')
    if known.num_envs is not None and known.num_envs < 16:
        parser.error('--num-envs must be at least 16')
    if (known.warmstart_checkpoint is not None
            and not known.warmstart_checkpoint.is_file()):
        parser.error('--warmstart-checkpoint must point to a checkpoint')
    if (known.warmstart_preferred_gait is not None
            and (known.warmstart_checkpoint is None
                 or not 0 <= known.warmstart_preferred_gait < 4)):
        parser.error('--warmstart-preferred-gait requires a checkpoint and an index in [0, 3]')
    if (not math.isfinite(known.warmstart_bias_margin)
            or known.warmstart_bias_margin < 0.):
        parser.error('--warmstart-bias-margin must be finite and nonnegative')
    if (known.jump_push_stroke is not None
            and any(not math.isfinite(value) or not 0. < value <= .25
                    for value in known.jump_push_stroke)):
        parser.error('--jump-push-stroke values must be in (0, 0.25] metres')
    if (known.jump_gap_runup_distance is not None
            and (not math.isfinite(known.jump_gap_runup_distance)
                 or not 0. <= known.jump_gap_runup_distance <= 1.)):
        parser.error('--jump-gap-runup-distance must be in [0, 1] metres')
    if (known.jump_gap_landing_x is not None
            and (not math.isfinite(known.jump_gap_landing_x)
                 or not -1. <= known.jump_gap_landing_x <= 1.)):
        parser.error('--jump-gap-landing-x must be in [-1, 1]')
    if (known.reflex_alignment_scale is not None
            and (not math.isfinite(known.reflex_alignment_scale)
                 or known.reflex_alignment_scale < 0.)):
        parser.error('--reflex-alignment-scale must be finite and nonnegative')
    register_dynamics_jump_task()
    env_cfg, train_cfg = task_registry.get_cfgs(args.task)
    if args.seed is not None:
        train_cfg.seed = args.seed
        env_cfg.seed = args.seed
    if known.reflex_alignment_scale is not None:
        env_cfg.rewards.scales.reflex_trigger_alignment = known.reflex_alignment_scale
    if known.height_edge_head:
        train_cfg.policy.height_edge_head = True
    if known.num_envs is not None:
        env_cfg.env.num_envs = known.num_envs
    train_cfg.runner.resume = False
    env, env_cfg = task_registry.make_env(args.task, args=args, env_cfg=env_cfg)
    if known.jump_push_stroke is not None:
        front, hind = known.jump_push_stroke
        env.ID.jump_reflex.push_stroke.copy_(torch.tensor(
            [front, front, hind, hind], device=env.device))
    if known.jump_gap_runup_distance is not None:
        env.ID.gap_runup_distance = known.jump_gap_runup_distance
    if known.jump_gap_landing_x is not None:
        env.ID.gap_landing_x_modulation = known.jump_gap_landing_x
    runner, train_cfg = task_registry.make_alg_runner(
        env, name=args.task, args=args, train_cfg=train_cfg, env_cfg=env_cfg)
    if known.warmstart_checkpoint is not None:
        warmstart_runner(runner, known.warmstart_checkpoint,
                         known.warmstart_preferred_gait,
                         known.warmstart_bias_margin)
    if known.freeze_modulation:
        freeze_modulation_learning(runner.modulation_param_alg)
    files = (
        'legged_gym/legged_gym/envs/a1/mp_full.py',
        'legged_gym/legged_gym/envs/a1/mp_full_config.py',
        'legged_gym/legged_gym/envs/a1/mp_full_dynamics_jump.py',
        'legged_gym/legged_gym/utils/dynamics/a1/dynamics_only_jump.py',
        'legged_gym/legged_gym/utils/dynamics/a1/contact_jump_reflex_v2.py',
        'legged_gym/legged_gym/utils/dynamics/a1/contact_jump_reflex_v3.py',
        'legged_gym/legged_gym/scripts/train_mp_full_dynamics_jump.py',
    )
    manifest = {
        'task': args.task,
        'primitive_names': list(env.ID.primitive_names),
        'jump_variant': env_cfg.env.jump_variant,
        'num_observations': env_cfg.env.num_observations,
        'num_privileged_obs': env_cfg.env.num_privileged_obs,
        'num_actions': env_cfg.env.num_actions,
        'seed': env_cfg.seed,
        'warmstart_checkpoint': (str(known.warmstart_checkpoint)
                                 if known.warmstart_checkpoint else None),
        'warmstart_preferred_gait': known.warmstart_preferred_gait,
        'warmstart_bias_margin': known.warmstart_bias_margin,
        'jump_push_stroke': env.ID.jump_reflex.push_stroke.cpu().tolist(),
        'jump_gap_runup_distance': env.ID.gap_runup_distance,
        'jump_gap_landing_x': env.ID.gap_landing_x_modulation,
        'reflex_alignment_scale': env_cfg.rewards.scales.reflex_trigger_alignment,
        'height_edge_head': known.height_edge_head,
        'freeze_modulation': known.freeze_modulation,
        'source_sha256': {name: hashlib.sha256(
            (ROOT / name).read_bytes()).hexdigest() for name in files},
    }
    (Path(runner.log_dir) / 'run_manifest.json').write_text(
        json.dumps(manifest, indent=2) + '\n')
    runner.learn(known.iterations or train_cfg.runner.max_iterations,
                 init_at_random_ep_len=False)


if __name__ == '__main__':
    main()

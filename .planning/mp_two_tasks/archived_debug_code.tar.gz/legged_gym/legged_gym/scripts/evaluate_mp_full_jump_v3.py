"""Evaluate a checkpoint trained with the isolated V3 jump task."""
import argparse
import json
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'legged_gym'), str(ROOT / 'rsl_rl')]
os.environ.setdefault('TORCH_EXTENSIONS_DIR',
                      str(ROOT / 'legged_gym/legged_gym/test/torch_extensions'))

from isaacgym import gymapi  # noqa: F401; before torch.
import torch

from legged_gym.envs.a1.mp_full import MotorPrimitives
from legged_gym.envs.a1.mp_full_jump_v3 import (
    JumpMotorPrimitivesV3Cfg, JumpMotorPrimitivesV3CfgPPO)
from legged_gym.scripts import evaluate_mp_full_terrain as evaluation
from legged_gym.utils.dynamics.a1.jump_dynamics_v3 import (
    JumpAdaptiveEquilibriumDynamicsV3)


class JumpV3EvaluationEnv(evaluation.EvaluationEnv):
    latest = None

    def _validate_action_config(self):
        MotorPrimitives._validate_action_config(self)
        if self.cfg.env.jump_variant != 'contact_reflex_v3_modulated':
            raise ValueError('V3 evaluation requires a V3 jump config')
        self._controller_class = JumpAdaptiveEquilibriumDynamicsV3

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        type(self).latest = self
        self.eval_jump_launches = torch.zeros(
            self.num_envs, dtype=torch.long, device=self.device)
        self.eval_jump_flights = torch.zeros_like(self.eval_jump_launches)
        self.eval_jump_landings = torch.zeros_like(self.eval_jump_launches)

    def check_termination(self, env_ids=None):
        metrics = getattr(self, 'metrics', None)
        active = metrics.active.clone() if metrics is not None else None
        super().check_termination(env_ids)
        if active is None:
            return
        reflex = self.ID.jump_reflex
        for target, source in (
                (self.eval_jump_launches, reflex.launch_events),
                (self.eval_jump_flights, reflex.flight_events),
                (self.eval_jump_landings, reflex.landing_events)):
            target.copy_(torch.maximum(target, torch.where(active, source, 0)))
        if getattr(self, 'trace_env_ids', None) is not None:
            self.trace_samples.setdefault('jump_state', []).append(
                reflex.state[self.trace_env_ids].detach().cpu().numpy().copy())


def main():
    if '--help' in sys.argv or '-h' in sys.argv:
        evaluation.main()
        return
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args, _ = parser.parse_known_args()
    saved = json.loads((args.checkpoint.parent / 'config.json').read_text())
    if saved.get('env', {}).get('jump_variant') != 'contact_reflex_v3_modulated':
        parser.error('checkpoint must have jump_variant=contact_reflex_v3_modulated')
    manifest = json.loads((args.checkpoint.parent / 'run_manifest.json').read_text())
    expected = ['walk', 'trot', 'canter', 'bound', 'jump']
    if manifest.get('primitive_names') != expected:
        parser.error('checkpoint manifest lacks the V3 jump primitive library')

    evaluation.EvaluationEnv = JumpV3EvaluationEnv
    evaluation.MotorPrimitivesCfg = JumpMotorPrimitivesV3Cfg
    evaluation.MotorPrimitivesCfgPPO = JumpMotorPrimitivesV3CfgPPO
    evaluation.main()

    env = JumpV3EvaluationEnv.latest
    report_path = args.output / 'report.json'
    report = json.loads(report_path.read_text())
    counts = {
        'jump_launches': env.eval_jump_launches.cpu().tolist(),
        'jump_flights': env.eval_jump_flights.cpu().tolist(),
        'jump_landings': env.eval_jump_landings.cpu().tolist(),
    }
    for group in report['groups']:
        for episode in group['episodes']:
            episode.update({name: values[episode['env']]
                            for name, values in counts.items()})
    report['jump_experiment'] = {
        'primitive_names': expected,
        'jump_variant': 'contact_reflex_v3_modulated',
        'trained_checkpoint': True,
        'oracle_arming': False,
        'launches': sum(counts['jump_launches']),
        'flights': sum(counts['jump_flights']),
        'landings': sum(counts['jump_landings']),
    }
    report_path.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()

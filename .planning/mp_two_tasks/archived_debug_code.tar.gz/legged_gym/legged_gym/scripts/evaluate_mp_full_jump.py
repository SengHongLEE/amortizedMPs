"""Evaluate a trained contact-jump policy on the same MP_full terrain metrics.

Accepts the options of evaluate_mp_full_terrain.py. This entry point installs
the jump task only within this process and rejects ordinary pronk checkpoints.
"""
import argparse
import json
import os
from pathlib import Path
import sys


ROOT = Path(__file__).resolve().parents[3]
sys.path[:0] = [str(ROOT / 'legged_gym'), str(ROOT / 'rsl_rl')]
os.environ.setdefault('TORCH_EXTENSIONS_DIR',
                      str(ROOT / 'legged_gym/legged_gym/test/torch_extensions'))

from isaacgym import gymapi  # noqa: F401; must precede torch.
import torch

from legged_gym.envs.a1.mp_full_jump import (
    JumpControllerTaskMixin, JumpMotorPrimitivesCfg, JumpMotorPrimitivesCfgPPO)
from legged_gym.scripts import evaluate_mp_full_terrain as evaluation


class JumpEvaluationEnv(JumpControllerTaskMixin, evaluation.EvaluationEnv):
    latest = None

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        type(self).latest = self
        self.eval_jump_launches = torch.zeros(self.num_envs, dtype=torch.long,
                                              device=self.device)
        self.eval_jump_flights = torch.zeros_like(self.eval_jump_launches)
        self.eval_jump_landings = torch.zeros_like(self.eval_jump_launches)

    def check_termination(self, env_ids=None):
        metrics = getattr(self, 'metrics', None)
        active = metrics.active.clone() if metrics is not None else None
        super().check_termination(env_ids)
        if active is None:
            return
        reflex = self.ID.jump_reflex
        for target, source in (
                (self.eval_jump_launches, reflex.launch_events),
                (self.eval_jump_flights, reflex.flight_events),
                (self.eval_jump_landings, reflex.landing_events)):
            target.copy_(torch.maximum(target, torch.where(active, source, 0)))
        if getattr(self, 'trace_env_ids', None) is not None:
            self.trace_samples.setdefault('jump_state', []).append(
                reflex.state[self.trace_env_ids].detach().cpu().numpy().copy())


def main():
    if '--help' in sys.argv or '-h' in sys.argv:
        evaluation.main()
        return
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args, _ = parser.parse_known_args()
    config_path = args.checkpoint.parent / 'config.json'
    saved = json.loads(config_path.read_text())
    if saved.get('env', {}).get('jump_variant') != 'contact_reflex_v1':
        parser.error('checkpoint must have jump_variant=contact_reflex_v1')
    manifest_path = args.checkpoint.parent / 'run_manifest.json'
    manifest = json.loads(manifest_path.read_text())
    expected = ['walk', 'trot', 'canter', 'bound', 'jump']
    if manifest.get('primitive_names') != expected:
        parser.error('checkpoint manifest does not declare the jump primitive library')

    evaluation.EvaluationEnv = JumpEvaluationEnv
    evaluation.MotorPrimitivesCfg = JumpMotorPrimitivesCfg
    evaluation.MotorPrimitivesCfgPPO = JumpMotorPrimitivesCfgPPO
    evaluation.main()

    env = JumpEvaluationEnv.latest
    report_path = args.output / 'report.json'
    report = json.loads(report_path.read_text())
    reports = {
        'jump_launches': env.eval_jump_launches.cpu().tolist(),
        'jump_flights': env.eval_jump_flights.cpu().tolist(),
        'jump_landings': env.eval_jump_landings.cpu().tolist(),
    }
    for group in report['groups']:
        for episode in group['episodes']:
            for name, values in reports.items():
                episode[name] = values[episode['env']]
    report['jump_experiment'] = {
        'primitive_names': expected,
        'jump_variant': 'contact_reflex_v1',
        'trained_checkpoint': True,
        'oracle_arming': False,
        'launches': sum(reports['jump_launches']),
        'flights': sum(reports['jump_flights']),
        'landings': sum(reports['jump_landings']),
    }
    report_path.write_text(json.dumps(report, indent=2) + '\n')


if __name__ == '__main__':
    main()

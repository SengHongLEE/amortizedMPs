"""Distil a sensor-only gait switching upper bound into the opt-in selector.

The teacher reads saved actor observations. The checkpoint keeps the actor and
critic observation tensors, continuous modulation actor, and intrinsic jump
controller unchanged. This is a calibration experiment, not default training.
"""
import argparse
import hashlib
import json
from pathlib import Path
import shutil

from isaacgym import gymapi  # noqa: F401; before torch.
import numpy as np
import torch
import torch.nn.functional as F

from legged_gym.scripts.probe_mp_full_dynamics_jump import observation_gait_window
from rsl_rl.modules.actor_critic import ActorCriticDiscrete


def build_training_examples(observations, active, max_distance=1.25,
                            decision_stride=15):
    """Use real five-frame actor history at scheduled gait decision ticks."""
    if (observations.ndim != 3 or observations.shape[-1] != 162
            or active.shape != observations.shape[:2]):
        raise ValueError('expected observations [T, N, 162] and active [T, N]')
    if decision_stride < 1:
        raise ValueError('decision_stride must be positive')
    histories, targets, env_ids = [], [], []
    for tick in range(decision_stride - 1, len(observations), decision_stride):
        if tick < 4:
            continue
        valid = active[tick - 4:tick + 1].all(axis=0)
        ids = np.flatnonzero(valid)
        if len(ids) == 0:
            continue
        frames = observations[tick - 4:tick + 1, ids].transpose(1, 0, 2).copy()
        label = observation_gait_window(
            torch.from_numpy(frames), max_distance).numpy()
        histories.append(frames)
        targets.append(np.where(label, 2, 3).astype(np.int64))
        env_ids.append(ids)
    if not histories:
        raise ValueError('no active gait decisions found in trace')
    return (np.concatenate(histories), np.concatenate(targets),
            np.concatenate(env_ids))


def flatten_observed_height_edges(histories):
    """Make a paired flat sensor view without altering proprioception."""
    result = histories.clone() if torch.is_tensor(histories) else histories.copy()
    heights = result[..., -60:].reshape(*result.shape[:-1], 12, 5)
    reference = heights[..., :1, :].clone() if torch.is_tensor(heights) else heights[..., :1, :].copy()
    heights[...] = reference
    return result


def expand_reservoir_projection(source_state, target_state, extra_dim):
    """Append encoder channels without changing the old reservoir response."""
    key = 'actor.reservoir.w_in'
    if not isinstance(extra_dim, int) or extra_dim < 1:
        raise ValueError('extra_dim must be positive')
    old, new = source_state[key], target_state[key]
    if (old.ndim != 2 or new.ndim != 2 or old.shape[0] != new.shape[0]
            or new.shape[1] != old.shape[1] + extra_dim):
        raise ValueError('reservoir input projection shapes are incompatible')
    expanded = new.clone()
    expanded[:, :old.shape[1]] = old
    result = {name: value.clone() for name, value in source_state.items()}
    result[key] = expanded
    return result


def _file_hash(path):
    digest = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--checkpoint', type=Path, required=True)
    parser.add_argument('--trace', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    parser.add_argument('--max-distance', type=float, default=1.25)
    parser.add_argument('--sample-stride', type=int, default=15,
                        help='Trace steps between supervised samples; policy still acts every 15 steps.')
    parser.add_argument('--balance-terrain-classes', action='store_true',
                        help='Balance hurdle-like, gap-like and no-edge samples.')
    parser.add_argument('--counterfactual-heights', action='store_true',
                        help='Supervise paired no-edge views of hurdle approaches as bound.')
    parser.add_argument('--height-edge-head', action='store_true',
                        help='Train an opt-in sensor-edge logit head and retain old readout weights.')
    parser.add_argument('--terrain-encoder-dim', type=int, default=0,
                        help='Append a learned scan encoder before the frozen LIF reservoir.')
    parser.add_argument('--train-readout-with-encoder', action='store_true',
                        help='Jointly fit readout with the pre-reservoir scan encoder.')
    parser.add_argument('--epochs', type=int, default=20)
    parser.add_argument('--batch-size', type=int, default=128)
    parser.add_argument('--learning-rate', type=float, default=1e-3)
    parser.add_argument('--seed', type=int, default=31415)
    args = parser.parse_args()
    if not args.checkpoint.is_file() or not args.trace.is_file():
        parser.error('checkpoint and trace files must exist')
    if (args.epochs < 1 or args.batch_size < 1
            or args.learning_rate <= 0 or args.sample_stride < 1):
        parser.error('epochs, batch size and learning rate must be positive')
    if not .25 <= args.max_distance <= 1.25:
        parser.error('max distance must be in [.25, 1.25] metres')
    if args.terrain_encoder_dim < 0 or (args.terrain_encoder_dim and args.height_edge_head):
        parser.error('choose either a pre-reservoir terrain encoder or an edge logit head')
    if args.train_readout_with_encoder and not args.terrain_encoder_dim:
        parser.error('--train-readout-with-encoder requires --terrain-encoder-dim')
    config_path = args.checkpoint.parent / 'config.json'
    config = json.loads(config_path.read_text())
    if (config['env']['num_observations'] != 162
            or config['env']['num_privileged_obs'] != 169
            or config['env']['num_primitives'] != 4
            or not config['policy']['include_input_in_readout']):
        parser.error('requires the opt-in four-gait direct-readout checkpoint')
    trace = np.load(args.trace)
    observations, targets, env_ids = build_training_examples(
        trace['policy_obs'], trace['active'], args.max_distance,
        args.sample_stride)
    if not np.isfinite(observations).all():
        parser.error('trace contains nonfinite actor observations')
    rng = np.random.default_rng(args.seed)
    distinct = rng.permutation(np.unique(env_ids))
    held_out = distinct[:max(1, len(distinct) // 5)]
    validation = np.isin(env_ids, held_out)
    if validation.all() or (~validation).sum() < 2:
        parser.error('trace needs multiple active environments')
    device = 'cuda:0' if torch.cuda.is_available() else 'cpu'
    torch.manual_seed(args.seed)
    if args.height_edge_head:
        config['policy']['height_edge_head'] = True
    if args.terrain_encoder_dim:
        config['policy']['terrain_encoder_dim'] = args.terrain_encoder_dim
    actor_critic = ActorCriticDiscrete(162, 169, 4, 4,
                                       **config['policy']).to(device)
    checkpoint = torch.load(args.checkpoint, map_location=device,
                            weights_only=True)
    selection_state = checkpoint['primitive_selection_model_state_dict']
    if args.terrain_encoder_dim:
        selection_state = expand_reservoir_projection(
            selection_state, actor_critic.state_dict(),
            args.terrain_encoder_dim)
    load_result = actor_critic.load_state_dict(
        selection_state,
        strict=not (args.height_edge_head or args.terrain_encoder_dim))
    if args.height_edge_head:
        expected = {f'actor.height_edge_head.{part}' for part in
                    ('0.weight', '0.bias', '2.weight', '2.bias')}
        if set(load_result.missing_keys) != expected or load_result.unexpected_keys:
            raise ValueError('checkpoint differs from the expected edge-head warmstart')
    if args.terrain_encoder_dim:
        expected = {name for name in actor_critic.state_dict()
                    if name.startswith('actor.terrain_encoder.')}
        if set(load_result.missing_keys) != expected or load_result.unexpected_keys:
            raise ValueError('checkpoint differs from the expected terrain-encoder warmstart')
    for name, parameter in actor_critic.actor.named_parameters():
        if args.terrain_encoder_dim:
            trainable = (name.startswith('terrain_encoder.')
                         or (args.train_readout_with_encoder
                             and name.startswith('readout.')))
        else:
            trainable = name.startswith(
                'height_edge_head.' if args.height_edge_head else 'readout.')
        parameter.requires_grad_(trainable)
    optimizer = torch.optim.AdamW(
        [p for p in actor_critic.actor.parameters() if p.requires_grad],
        lr=args.learning_rate, weight_decay=1e-5)
    x = torch.from_numpy(observations).to(device)
    y = torch.from_numpy(targets).to(device)
    training_ids = np.flatnonzero(~validation)
    validation_ids = np.flatnonzero(validation)
    # Each class receives similar supervision even if obstacle approaches
    # occupy a smaller fraction of the recorded episode than flat running.
    height_edges = np.abs(np.diff(
        observations[:, -1, -60:].reshape(-1, 12, 5)[:, :, 2], axis=1)).max(1)
    hurdle_like = (targets == 2) & (height_edges < 1.)
    if args.balance_terrain_classes:
        class_ids = [training_ids[hurdle_like[training_ids]],
                     training_ids[(targets[training_ids] == 2)
                                  & ~hurdle_like[training_ids]],
                     training_ids[targets[training_ids] == 3]]
    else:
        class_ids = [training_ids[targets[training_ids] == label]
                     for label in (2, 3)]
    if any(len(ids) == 0 for ids in class_ids):
        parser.error('trace must contain all requested teacher classes')
    sample_count = len(class_ids) * max(len(ids) for ids in class_ids)
    history = []
    for epoch in range(args.epochs):
        actor_critic.actor.train()
        if args.terrain_encoder_dim:
            actor_critic.actor.train_encoder_through_reservoir = True
        sampled = np.concatenate([
            rng.choice(ids, sample_count // len(class_ids), replace=True)
            for ids in class_ids])
        rng.shuffle(sampled)
        losses = []
        for start in range(0, len(sampled), args.batch_size):
            batch = torch.as_tensor(sampled[start:start + args.batch_size],
                                    device=device)
            initial_state = x.new_zeros(
                len(batch), actor_critic.actor.reservoir_state_dim)
            logits, _ = actor_critic.actor(x[batch], initial_state)
            loss = F.cross_entropy(logits, y[batch])
            if args.counterfactual_heights:
                hurdle_batch = batch[torch.as_tensor(
                    hurdle_like[sampled[start:start + args.batch_size]],
                    device=device)]
                if len(hurdle_batch):
                    no_edge = flatten_observed_height_edges(x[hurdle_batch])
                    state = no_edge.new_zeros(
                        len(hurdle_batch), actor_critic.actor.reservoir_state_dim)
                    no_edge_logits, _ = actor_critic.actor(no_edge, state)
                    loss = loss + .5 * F.cross_entropy(
                        no_edge_logits,
                        torch.full((len(hurdle_batch),), 3,
                                   dtype=torch.long, device=device))
            optimizer.zero_grad(set_to_none=True)
            loss.backward()
            torch.nn.utils.clip_grad_norm_(actor_critic.actor.parameters(), 1.)
            optimizer.step()
            losses.append(float(loss.detach()))
        actor_critic.actor.eval()
        actor_critic.actor.train_encoder_through_reservoir = False
        with torch.no_grad():
            correct, seen = 0, 0
            for start in range(0, len(validation_ids), args.batch_size):
                batch = torch.as_tensor(
                    validation_ids[start:start + args.batch_size], device=device)
                initial_state = x.new_zeros(
                    len(batch), actor_critic.actor.reservoir_state_dim)
                logits, _ = actor_critic.actor(x[batch], initial_state)
                correct += int((logits.argmax(-1) == y[batch]).sum())
                seen += len(batch)
        record = {'epoch': epoch + 1,
                  'train_loss': sum(losses) / len(losses),
                  'validation_accuracy': correct / seen}
        history.append(record)
        print(record, flush=True)
    args.output.mkdir(parents=True, exist_ok=True)
    checkpoint['primitive_selection_model_state_dict'] = actor_critic.state_dict()
    output_checkpoint = args.output / 'model_selector_distilled.pt'
    torch.save(checkpoint, output_checkpoint)
    if args.height_edge_head or args.terrain_encoder_dim:
        (args.output / 'config.json').write_text(json.dumps(config, indent=2) + '\n')
    else:
        shutil.copy2(config_path, args.output / 'config.json')
    manifest = {
        'source_checkpoint': str(args.checkpoint),
        'source_checkpoint_sha256': _file_hash(args.checkpoint),
        'source_trace': str(args.trace),
        'source_trace_sha256': _file_hash(args.trace),
        'code_sha256': {str(path.relative_to(Path(__file__).resolve().parents[3])):
                        _file_hash(path) for path in (
            Path(__file__),
            Path(__file__).resolve().parents[3] /
                'rsl_rl/rsl_rl/modules/actor_critic.py',
            Path(__file__).resolve().parents[3] /
                'rsl_rl/rsl_rl/modules/reservoir_actors.py',
            Path(__file__).resolve().parents[3] /
                'rsl_rl/rsl_rl/modules/reservoirs.py',
        )},
        'actor_obs': 162, 'critic_obs': 169,
        'teacher_max_distance': args.max_distance,
        'sample_stride': args.sample_stride,
        'balance_terrain_classes': args.balance_terrain_classes,
        'counterfactual_heights': args.counterfactual_heights,
        'height_edge_head': args.height_edge_head,
        'terrain_encoder_dim': args.terrain_encoder_dim,
        'train_readout_with_encoder': args.train_readout_with_encoder,
        'training_count': int(len(training_ids)),
        'validation_count': int(len(validation_ids)),
        'teacher_label_counts': {str(label): int((targets == label).sum())
                                 for label in (2, 3)},
        'held_out_env_ids': held_out.tolist(),
        'training_history': history,
        'note': 'Supervised sensor-rule distillation; physical success unverified.',
    }
    (args.output / 'selector_manifest.json').write_text(
        json.dumps(manifest, indent=2) + '\n')


if __name__ == '__main__':
    main()

"""Opt-in MP_full_a1 experiment: replace pronk with a contact-triggered jump."""
from legged_gym.envs.a1.mp_full import MotorPrimitives
from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg, MotorPrimitivesCfgPPO
from legged_gym.utils.dynamics.a1.jump_dynamics import JumpAdaptiveEquilibriumDynamics
from legged_gym.utils.task_registry import task_registry


class JumpMotorPrimitivesCfg(MotorPrimitivesCfg):
    class env(MotorPrimitivesCfg.env):
        jump_variant = 'contact_reflex_v1'

    class asset(MotorPrimitivesCfg.asset):
        # The jump's support gait is bound; contact reflex supplies the push.
        gait_step_length_scales = [1., 1., 1.5, 1., 1.]
        stance_extension_gait_id = None


class JumpMotorPrimitivesCfgPPO(MotorPrimitivesCfgPPO):
    class runner(MotorPrimitivesCfgPPO.runner):
        run_name = MotorPrimitivesCfgPPO.runner.run_name + '-jump5-noPronk'
        resume = False


class JumpControllerTaskMixin:
    def _validate_action_config(self):
        super()._validate_action_config()
        if self.cfg.env.num_primitives != 5:
            raise ValueError('jump experiment requires five primitives')
        if getattr(self.cfg.env, 'jump_variant', None) != 'contact_reflex_v1':
            raise ValueError('jump experiment requires contact_reflex_v1 config')
        self._controller_class = JumpAdaptiveEquilibriumDynamics


class JumpMotorPrimitives(JumpControllerTaskMixin, MotorPrimitives):
    """Use the jump dynamics while leaving the default task untouched."""


def register_jump_task():
    name = 'MP_full_jump_a1'
    existing = task_registry.task_classes.get(name)
    if existing is not None and existing is not JumpMotorPrimitives:
        raise RuntimeError(f'{name} is already registered to another environment')
    if existing is None:
        task_registry.register(
            name, JumpMotorPrimitives,
            JumpMotorPrimitivesCfg(), JumpMotorPrimitivesCfgPPO())

"""Opt-in MP_full jump task with action-modulated contact reflex."""
from legged_gym.envs.a1.mp_full import MotorPrimitives
from legged_gym.envs.a1.mp_full_jump import (
    JumpMotorPrimitivesCfg, JumpMotorPrimitivesCfgPPO)
from legged_gym.utils.dynamics.a1.jump_dynamics_v3 import (
    JumpAdaptiveEquilibriumDynamicsV3)
from legged_gym.utils.task_registry import task_registry


class JumpMotorPrimitivesV3Cfg(JumpMotorPrimitivesCfg):
    class env(JumpMotorPrimitivesCfg.env):
        jump_variant = 'contact_reflex_v3_modulated'


class JumpMotorPrimitivesV3CfgPPO(JumpMotorPrimitivesCfgPPO):
    class runner(JumpMotorPrimitivesCfgPPO.runner):
        run_name = (JumpMotorPrimitivesCfgPPO.runner.run_name
                    + '-v3-modulated-preserveGait')
        resume = False


class JumpMotorPrimitivesV3(MotorPrimitives):
    def _validate_action_config(self):
        super()._validate_action_config()
        if self.cfg.env.num_primitives != 5:
            raise ValueError('V3 jump experiment requires five primitives')
        if self.cfg.env.jump_variant != 'contact_reflex_v3_modulated':
            raise ValueError('V3 jump experiment requires its own config marker')
        self._controller_class = JumpAdaptiveEquilibriumDynamicsV3


def register_jump_v3_task():
    name = 'MP_full_jump_v3_a1'
    existing = task_registry.task_classes.get(name)
    if existing is not None and existing is not JumpMotorPrimitivesV3:
        raise RuntimeError(f'{name} is already registered to another environment')
    if existing is None:
        task_registry.register(
            name, JumpMotorPrimitivesV3,
            JumpMotorPrimitivesV3Cfg(), JumpMotorPrimitivesV3CfgPPO())

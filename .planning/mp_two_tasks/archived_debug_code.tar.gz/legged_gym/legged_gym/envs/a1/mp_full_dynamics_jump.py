"""Opt-in four-gait MP_full task with a dynamics-state-only jump reflex."""
import torch

from legged_gym.envs.a1.mp_full import MotorPrimitives
from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg, MotorPrimitivesCfgPPO
from legged_gym.utils.dynamics.a1.dynamics_only_jump import DynamicsOnlyJumpDynamics
from legged_gym.utils.task_registry import task_registry


def forward_discontinuity_mask(heights, threshold=.06):
    """Find a sharp height change in the actor's existing centerline samples."""
    if heights.ndim != 2 or heights.shape[1] != 60:
        raise ValueError('heights must have shape [num_envs, 60]')
    centerline = heights.reshape(-1, 12, 5)[:, :, 2]
    return (centerline[:, 1:] - centerline[:, :-1]).abs().amax(-1) >= threshold


def reflex_trigger_alignment(raw, launched, heights, terrain_is_gap,
                             terrain_is_hurdle, threshold=.06):
    """Score false candidates and physical launches during training."""
    if (heights.ndim != 2 or heights.shape[1] != 60
            or raw.shape != (heights.shape[0], 2)
            or launched.shape != raw.shape
            or terrain_is_gap.shape != (heights.shape[0],)
            or terrain_is_hurdle.shape != (heights.shape[0],)):
        raise ValueError('invalid reflex-alignment batch shapes')
    center = heights.reshape(-1, 12, 5)[:, :, 2]
    edges = center[:, 1:] - center[:, :-1]
    edge_mask = edges.abs() >= threshold
    first_index = edge_mask.float().argmax(-1)
    first_edge = edges.gather(1, first_index[:, None]).squeeze(1)
    edge_distance = .25 + .1 * first_index.to(heights.dtype)
    has_edge = edge_mask.any(-1)
    valid_gap = (has_edge & terrain_is_gap & (first_edge < -threshold)
                 & (edge_distance >= .35) & (edge_distance <= .85))
    valid_hurdle = (has_edge & terrain_is_hurdle & (first_edge > threshold)
                    & (edge_distance >= .35) & (edge_distance <= 1.25))
    valid = (launched[:, 0].to(heights.dtype) * valid_gap
             + launched[:, 1].to(heights.dtype) * valid_hurdle)
    invalid = (raw[:, 0].to(heights.dtype) * ~valid_gap
               + raw[:, 1].to(heights.dtype) * ~valid_hurdle)
    return valid - 2. * invalid


class DynamicsJumpMotorPrimitivesCfg(MotorPrimitivesCfg):
    class env(MotorPrimitivesCfg.env):
        jump_variant = 'dynamics_only_reflex_v2_gait_gate'

    class rewards(MotorPrimitivesCfg.rewards):
        primitive_selection_rewards = (
            MotorPrimitivesCfg.rewards.primitive_selection_rewards
            + ['obstacle_gait_readiness'])
        modulation_param_rewards = (
            MotorPrimitivesCfg.rewards.modulation_param_rewards
            + ['reflex_trigger_alignment'])

        class scales(MotorPrimitivesCfg.rewards.scales):
            # Opt in through --reflex-alignment-scale while the physical
            # traversal gate remains unmet.
            reflex_trigger_alignment = 0.

        class primitive_selection_scales(
                MotorPrimitivesCfg.rewards.primitive_selection_scales):
            obstacle_gait_readiness = 4.


class DynamicsJumpMotorPrimitivesCfgPPO(MotorPrimitivesCfgPPO):
    class policy(MotorPrimitivesCfgPPO.policy):
        include_input_in_readout = True

    class runner(MotorPrimitivesCfgPPO.runner):
        run_name = MotorPrimitivesCfgPPO.runner.run_name + '-dynamics-reflex4-directreadout'
        resume = False


class DynamicsJumpMotorPrimitives(MotorPrimitives):
    """Feed physical robot state to the reflex without changing policy tensors."""

    def _validate_action_config(self):
        super()._validate_action_config()
        if self.cfg.env.num_primitives != 4:
            raise ValueError('dynamics reflex task requires the original four gaits')
        if self.cfg.env.jump_variant != 'dynamics_only_reflex_v2_gait_gate':
            raise ValueError('dynamics reflex task requires its own config marker')
        self._controller_class = DynamicsOnlyJumpDynamics

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        original_dynamics = self.ID.intrinsic_dynamics

        def with_physical_inputs(actions, command, foot_contact=None,
                                 contact_forces=None):
            return original_dynamics(
                actions, command,
                foot_forces_xyz=self.contact_forces[:, self.feet_indices, :],
                base_velocity_x=self.base_lin_vel[:, 0])

        self.ID.intrinsic_dynamics = with_physical_inputs

    def _reward_obstacle_gait_readiness(self):
        ahead = forward_discontinuity_mask(self.measured_heights)
        canter = self.actions[:, 0].long() == 2
        return torch.where(ahead, canter.float() * 2. - 1., 0.)

    def _reward_reflex_trigger_alignment(self):
        raw, _ = self.ID.jump_detector.consume_trigger_counts()
        launched = self.ID.consume_launch_counts()
        return reflex_trigger_alignment(
            raw, launched, self.measured_heights,
            self._gap_columns[self.terrain_types],
            self._hurdle_columns[self.terrain_types])


def register_dynamics_jump_task():
    name = 'MP_full_dynamics_jump_a1'
    existing = task_registry.task_classes.get(name)
    if existing is not None and existing is not DynamicsJumpMotorPrimitives:
        raise RuntimeError(f'{name} is already registered to another environment')
    if existing is None:
        task_registry.register(
            name, DynamicsJumpMotorPrimitives,
            DynamicsJumpMotorPrimitivesCfg(), DynamicsJumpMotorPrimitivesCfgPPO())

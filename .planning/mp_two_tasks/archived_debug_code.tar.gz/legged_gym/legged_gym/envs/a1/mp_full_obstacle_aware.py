"""Opt-in signed-dense task with obstacle-local speed tolerance."""
import torch

from legged_gym.envs.a1.mp_full import MotorPrimitives


def obstacle_approach_gate(world_x, clearance_targets, approach_distance,
                           full_distance, recovery_distance):
    """Smooth [0, 1] gate around any band-clearance target in each environment."""
    distance = clearance_targets - world_x.unsqueeze(1)
    approach = torch.where(
        distance >= 0,
        (approach_distance - distance) / (approach_distance - full_distance),
        0.).clamp(0., 1.)
    recovery = torch.where(
        distance < 0,
        (recovery_distance + distance) / recovery_distance,
        0.).clamp(0., 1.)
    gate = torch.maximum(approach, recovery)
    gate = gate.square() * (3. - 2. * gate)
    return gate.amax(dim=1)


def terrain_relief_gate(lower_heights, upper_heights, start_relief, full_relief):
    """Activate progress pressure with the visible forward terrain height span."""
    relief = upper_heights.amax(dim=1) - lower_heights.amin(dim=1)
    fraction = ((relief - start_relief) / (full_relief - start_relief)).clamp(0., 1.)
    return fraction.square() * (3. - 2. * fraction)


class ObstacleAwareMotorPrimitives(MotorPrimitives):
    """Retain exact command tracking on open ground; permit local speed changes."""

    def _obstacle_reward_gate(self):
        rewards = self.cfg.rewards
        targets = self._obstacle_clear_targets[self.terrain_types]
        return obstacle_approach_gate(
            self.root_states[:, 0], targets,
            rewards.obstacle_gate_approach_distance,
            rewards.obstacle_gate_full_distance,
            rewards.obstacle_gate_recovery_distance)

    def _reward_tracking_lin_vel(self):
        gate = self._obstacle_reward_gate()
        target_x = self.commands[:, 0]
        actual_x = self.base_lin_vel[:, 0]
        upper = target_x + gate * self.cfg.rewards.obstacle_overspeed_slack
        lower = target_x - gate * self.cfg.rewards.obstacle_underspeed_slack
        forward_error = (actual_x - upper).clamp_min(0.) + (lower - actual_x).clamp_min(0.)
        lateral_error = self.commands[:, 1] - self.base_lin_vel[:, 1]
        return torch.exp(-(forward_error.square() + lateral_error.square())
                         / self.cfg.rewards.tracking_sigma)

    def _reward_locomotion_distance(self):
        rewards = self.cfg.rewards
        relief_gate = terrain_relief_gate(
            self._dense_lower_heights, self._dense_upper_heights,
            rewards.progress_relief_start, rewards.progress_relief_full)
        progress_gate = torch.maximum(relief_gate, self._obstacle_reward_gate())
        return progress_gate * super()._reward_locomotion_distance()


class FlatTrackingMotorPrimitives(ObstacleAwareMotorPrimitives):
    """Give large speed errors a useful reward gradient on flat tiles only."""

    def _init_buffers(self):
        super()._init_buffers()
        self._flat_columns = torch.as_tensor(
            [self.terrain._kind(name) == 'flat' for name in self.terrain.terrain_names[0]],
            device=self.device, dtype=torch.bool)

    def _reward_tracking_lin_vel(self):
        original = super()._reward_tracking_lin_vel()
        transition = self.cfg.rewards.tracking_tail_transition
        error = torch.linalg.vector_norm(
            self.commands[:, :2] - self.base_lin_vel[:, :2], dim=1)
        cost = torch.where(error <= transition, error.square(),
                           2. * transition * error - transition ** 2)
        flat_reward = torch.exp(-cost / self.cfg.rewards.tracking_sigma)
        return torch.where(self._flat_columns[self.terrain_types], flat_reward, original)


"""The jump experiment must not change the default MP_full_a1 task."""
import unittest

from isaacgym import gymapi  # noqa: F401; load Isaac Gym before torch.

from legged_gym.envs.a1.mp_full import MotorPrimitives
from legged_gym.envs.a1.mp_full_jump import (
    JumpMotorPrimitives, JumpMotorPrimitivesCfg, register_jump_task)
from legged_gym.utils.dynamics.a1.jump_dynamics import JumpAdaptiveEquilibriumDynamics
from legged_gym.utils.task_registry import task_registry


class JumpTaskTests(unittest.TestCase):
    def test_only_the_new_task_uses_jump_controller(self):
        old = task_registry.get_task_class('MP_full_a1')
        self.assertIs(old, MotorPrimitives)
        register_jump_task()
        self.assertIs(task_registry.get_task_class('MP_full_a1'), old)
        self.assertIs(task_registry.get_task_class('MP_full_jump_a1'), JumpMotorPrimitives)
        cfg = JumpMotorPrimitivesCfg()
        self.assertEqual(cfg.env.num_primitives, 5)
        self.assertEqual(cfg.env.num_modulation_params, 18)
        self.assertEqual(cfg.env.num_actions, 19)
        self.assertEqual(cfg.asset.gait_step_length_scales[4], 1.)
        task = JumpMotorPrimitives.__new__(JumpMotorPrimitives)
        task.cfg = cfg
        task._validate_action_config()
        self.assertIs(task._controller_class, JumpAdaptiveEquilibriumDynamics)

    def test_rejects_an_incompatible_primitive_count(self):
        task = JumpMotorPrimitives.__new__(JumpMotorPrimitives)
        task.cfg = JumpMotorPrimitivesCfg()
        task.cfg.env.num_primitives = 4
        with self.assertRaisesRegex(ValueError, 'five primitives'):
            task._validate_action_config()


if __name__ == '__main__':
    unittest.main()

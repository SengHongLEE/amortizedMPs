"""Behavioral checks for an isolated, dynamics-state-only jump trigger."""
import unittest

from isaacgym import gymapi  # noqa: F401; Isaac Gym must precede torch.
import torch

from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg  # noqa: F401
from legged_gym.utils.dynamics.a1.dynamics_only_jump import (
    IntrinsicJumpDetector, DynamicsOnlyJumpDynamics)


class IntrinsicJumpDetectorTests(unittest.TestCase):
    def setUp(self):
        self.detector = IntrinsicJumpDetector(2, 'cpu', 0.001)
        self.eq = torch.zeros(2, 4)
        self.forces = torch.zeros(2, 4, 3)
        self.ready = torch.ones(2, dtype=torch.bool)

    def test_gap_arming_needs_a_new_front_equilibrium_drop(self):
        self.eq[:, :2] = .032
        self.assertEqual(self.detector.step(self.eq, self.forces, self.ready).tolist(), [0, 0])
        self.eq[0, :2] = .006
        self.assertEqual(self.detector.step(self.eq, self.forces, self.ready).tolist(), [1, 0])
        self.assertEqual(self.detector.step(self.eq, self.forces, self.ready).tolist(), [0, 0])

    def test_trigger_candidate_counts_survive_until_policy_reward(self):
        self.eq[0, 0] = .032
        self.detector.step(self.eq, self.forces, self.ready)
        self.eq[0, 0] = .006
        self.detector.step(self.eq, self.forces, self.ready)
        self.detector.step(self.eq, self.forces, self.ready)
        raw, accepted = self.detector.consume_trigger_counts()
        self.assertEqual(raw.tolist(), [[1, 0], [0, 0]])
        self.assertEqual(accepted.tolist(), [[1, 0], [0, 0]])
        raw, accepted = self.detector.consume_trigger_counts()
        self.assertEqual(raw.tolist(), [[0, 0], [0, 0]])
        self.assertEqual(accepted.tolist(), [[0, 0], [0, 0]])

    def test_two_step_gap_drop_does_not_miss_intermediate_equilibrium(self):
        self.eq[0, 0] = .035
        self.detector.step(self.eq, self.forces, self.ready)
        self.eq[0, 0] = .018
        self.assertEqual(self.detector.step(
            self.eq, self.forces, self.ready).tolist(), [0, 0])
        self.eq[0, 0] = .001
        self.assertEqual(self.detector.step(
            self.eq, self.forces, self.ready).tolist(), [1, 0])

    def test_one_front_leg_can_signal_a_gap_while_the_other_balances(self):
        self.eq[:, :2] = .032
        self.detector.step(self.eq, self.forces, self.ready)
        self.eq[0, 0] = .006
        self.assertEqual(self.detector.step(self.eq, self.forces, self.ready).tolist(), [1, 0])

    def test_hurdle_collision_arms_without_oracle_or_height_input(self):
        self.forces[1, 1, 0] = -180.
        self.assertEqual(self.detector.step(self.eq, self.forces, self.ready).tolist(), [0, 2])

    def test_equilibrium_pattern_prepares_hurdle_before_contact(self):
        eq_x = torch.zeros(2, 4)
        freq = torch.ones(2, 1)
        self.eq[0, 0] = .020
        self.eq[0, 2:] = .030
        for _ in range(501):
            self.detector.step(self.eq, self.forces, self.ready, eq_x, freq)
        self.eq[0, 0] = .024
        self.eq[0, 2:] = .0305
        eq_x[0, :2] = .041
        eq_x[0, 3] = -.041
        freq[0] = 1.09
        self.assertEqual(self.detector.step(
            self.eq, self.forces, self.ready, eq_x, freq).tolist(), [3, 0])
        self.assertEqual(self.detector.step(
            self.eq, self.forces, self.ready, eq_x, freq).tolist(), [0, 0])

    def test_hurdle_pattern_scales_with_checkpoint_equilibrium_ranges(self):
        detector = IntrinsicJumpDetector(
            2, 'cpu', .001, front_x_limit=.05,
            rear_x_range=(-.05, -.02))
        eq_x = torch.zeros(2, 4)
        freq = torch.ones(2, 1)
        self.eq[0, 0] = .020
        self.eq[0, 2:] = .0295
        for _ in range(501):
            detector.step(self.eq, self.forces, self.ready, eq_x, freq)
        self.eq[0, 0] = .024
        self.eq[0, 2:] = .030
        eq_x[0, :2] = .029
        eq_x[0, 3] = -.032
        freq[0] = 1.09
        self.assertEqual(detector.step(
            self.eq, self.forces, self.ready, eq_x, freq).tolist(), [3, 0])

    def test_gap_like_rear_rise_does_not_prepare_hurdle(self):
        eq_x = torch.zeros(2, 4)
        freq = torch.ones(2, 1)
        self.eq[0, 0] = .022
        self.eq[0, 2:] = .028
        for _ in range(401):
            self.detector.step(self.eq, self.forces, self.ready, eq_x, freq)
        self.eq[0, 0] = .021
        self.eq[0, 2:] = .031
        eq_x[0, :2] = .041
        eq_x[0, 3] = -.041
        freq[0] = 1.09
        self.assertEqual(self.detector.step(
            self.eq, self.forces, self.ready, eq_x, freq).tolist(), [0, 0])

    def test_disabled_hurdle_events_do_not_consume_gap_cooldown(self):
        self.detector.enable_hurdle_prepare = False
        self.detector.enable_hurdle_contact = False
        eq_x = torch.zeros(2, 4)
        freq = torch.ones(2, 1)
        self.eq[0, 0] = .032
        for _ in range(401):
            self.detector.step(self.eq, self.forces, self.ready, eq_x, freq)
        self.eq[0, 2:] = .031
        eq_x[0, :2] = .041
        eq_x[0, 3] = -.041
        freq[0] = 1.09
        self.forces[0, 0, 0] = -180.
        self.assertEqual(self.detector.step(
            self.eq, self.forces, self.ready, eq_x, freq).tolist(), [0, 0])
        self.eq[0, 0] = .006
        self.assertEqual(self.detector.step(
            self.eq, self.forces, self.ready, eq_x, freq).tolist(), [1, 0])

    def test_flat_gait_changes_and_vertical_contact_do_not_arm(self):
        self.eq[:, :2] = .024
        self.detector.step(self.eq, self.forces, self.ready)
        self.eq[:, :2] = .018
        self.forces[:, :, 2] = 250.
        self.assertEqual(self.detector.step(self.eq, self.forces, self.ready).tolist(), [0, 0])

    def test_event_requires_idle_state_and_rearms_after_cooldown(self):
        self.forces[0, 0, 0] = -180.
        self.ready[0] = False
        self.assertEqual(self.detector.step(self.eq, self.forces, self.ready).tolist(), [0, 0])
        self.ready[0] = True
        self.assertEqual(self.detector.step(self.eq, self.forces, self.ready).tolist(), [2, 0])
        self.assertEqual(self.detector.step(self.eq, self.forces, self.ready).tolist(), [0, 0])
        self.forces.zero_()
        for _ in range(400):
            self.detector.step(self.eq, self.forces, self.ready)
        self.forces[0, 0, 0] = -180.
        self.assertEqual(self.detector.step(self.eq, self.forces, self.ready).tolist(), [2, 0])


class DynamicsOnlyJumpControllerTests(unittest.TestCase):
    def test_fast_gap_launch_retracts_landing_targets_once(self):
        cfg = MotorPrimitivesCfg()
        dynamics = DynamicsOnlyJumpDynamics(
            equilibrium_cfg=cfg.control.equilibrium,
            timing_cfg=cfg.control.timing,
            num_envs=2, device='cpu', time_step=.001,
            nominal_clearance=.15, max_clearance=.20,
            gap_landing_x_modulation=-1.,
            gap_speed_landing_shift=.08)
        dynamics.pending_jump_kind[:] = IntrinsicJumpDetector.GAP
        dynamics.jump_reflex.arm(torch.ones(2, dtype=torch.bool))
        actions = torch.zeros(2, 19)
        actions[:, 0] = 2
        command = torch.tensor([[1.2, 0., 0.]]).expand(2, -1)
        forces = torch.zeros(2, 4, 3)
        forces[:, :, 2] = 30.
        for _ in range(7):
            dynamics.intrinsic_dynamics(
                actions, command, foot_forces_xyz=forces,
                base_velocity_x=torch.tensor([2., 1.]))
        self.assertEqual(dynamics.jump_reflex.launch_events.tolist(), [1, 1])
        self.assertTrue(torch.allclose(
            dynamics.jump_reflex.latched_landing_x,
            torch.tensor([[-.01, -.01, -.03, -.03],
                          [.07, .07, .05, .05]]), atol=1e-6))

    def test_gap_only_landing_x_override_is_latched_at_launch(self):
        cfg = MotorPrimitivesCfg()
        dynamics = DynamicsOnlyJumpDynamics(
            equilibrium_cfg=cfg.control.equilibrium,
            timing_cfg=cfg.control.timing,
            num_envs=2, device='cpu', time_step=.001,
            nominal_clearance=.15, max_clearance=.20,
            gap_landing_x_modulation=-1.)
        dynamics.pending_jump_kind[:] = torch.tensor([
            IntrinsicJumpDetector.GAP,
            IntrinsicJumpDetector.HURDLE_PREPARE])
        dynamics.jump_reflex.arm(torch.ones(2, dtype=torch.bool))
        actions = torch.zeros(2, 19)
        actions[:, 0] = 2
        command = torch.tensor([[1.2, 0., 0.]]).expand(2, -1)
        forces = torch.zeros(2, 4, 3)
        forces[:, :, 2] = 30.
        for _ in range(6):
            dynamics.intrinsic_dynamics(
                actions, command, foot_forces_xyz=forces)
        self.assertEqual(dynamics.jump_reflex.launch_events.tolist(), [1, 1])
        self.assertTrue(torch.allclose(
            dynamics.jump_reflex.latched_landing_x,
            torch.tensor([[.07, .07, .05, .05],
                          [.17, .17, .15, .15]])))
        launched = dynamics.consume_launch_counts()
        self.assertEqual(launched.tolist(), [[1, 0], [0, 1]])
        self.assertEqual(dynamics.consume_launch_counts().tolist(),
                         [[0, 0], [0, 0]])

    def test_gap_preparation_waits_for_forward_runup(self):
        cfg = MotorPrimitivesCfg()
        dynamics = DynamicsOnlyJumpDynamics(
            equilibrium_cfg=cfg.control.equilibrium,
            timing_cfg=cfg.control.timing,
            num_envs=1, device='cpu', time_step=.001,
            nominal_clearance=.15, max_clearance=.20,
            gap_runup_distance=.22)
        self.assertAlmostEqual(dynamics.gap_runup_distance, .22)
        self.assertEqual(dynamics.jump_modulation.tolist(),
                         [1., 0., -.5, 1., 1., -1.])
        actions = torch.zeros(1, 19)
        actions[:, 0] = 2
        actions[:, 13] = .5
        command = torch.tensor([[1.2, 0., 0.]])
        forces = torch.zeros(1, 4, 3)
        forces[:, :, 2] = 30.
        dynamics.intrinsic_dynamics(
            actions, command, foot_forces_xyz=forces,
            base_velocity_x=torch.tensor([2.0]))
        actions[:, 13] = -1.
        dynamics.intrinsic_dynamics(
            actions, command, foot_forces_xyz=forces,
            base_velocity_x=torch.tensor([2.0]))
        self.assertEqual(dynamics.jump_reflex.launch_events.item(), 0)
        self.assertTrue(dynamics.pending_gap.item())
        for _ in range(70):
            dynamics.intrinsic_dynamics(
                actions, command, foot_forces_xyz=forces,
                base_velocity_x=torch.tensor([2.0]))
        self.assertEqual(dynamics.jump_reflex.launch_events.item(), 0)
        for _ in range(50):
            dynamics.intrinsic_dynamics(
                actions, command, foot_forces_xyz=forces,
                base_velocity_x=torch.tensor([2.0]))
        self.assertEqual(dynamics.jump_reflex.launch_events.item(), 1)

    def test_capable_gaits_jump_while_all_four_phases_keep_running(self):
        from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg
        cfg = MotorPrimitivesCfg()
        dynamics = DynamicsOnlyJumpDynamics(
            equilibrium_cfg=cfg.control.equilibrium,
            timing_cfg=cfg.control.timing,
            num_envs=4, device='cpu', time_step=.001,
            nominal_clearance=.15, max_clearance=.20)
        self.assertAlmostEqual(dynamics.gap_runup_distance, .10)
        actions = torch.zeros(4, 19)
        actions[:, 0] = torch.arange(4)
        actions[:, 13:15] = .5
        command = torch.tensor([[1.2, 0., 0.]]).expand(4, -1)
        forces = torch.zeros(4, 4, 3)
        forces[:, :, 2] = 30.
        dynamics.intrinsic_dynamics(actions, command, foot_forces_xyz=forces)
        actions[:, 13:15] = -1.
        for _ in range(12):
            dynamics.intrinsic_dynamics(actions, command, foot_forces_xyz=forces)
        self.assertEqual(dynamics.jump_reflex.launch_events.tolist(), [0, 1, 1, 0])
        self.assertEqual(dynamics._gait_ids.tolist(), [0, 1, 2, 3])
        phase_after_launch = dynamics.X[:, 2].clone()
        for _ in range(25):
            dynamics.intrinsic_dynamics(actions, command, foot_forces_xyz=forces)
        self.assertFalse(torch.equal(phase_after_launch, dynamics.X[:, 2]))
        forces.zero_()
        for _ in range(130):
            dynamics.intrinsic_dynamics(actions, command, foot_forces_xyz=forces)
        self.assertEqual((dynamics.jump_reflex.flight_events > 0).tolist(),
                         [False, True, True, False])
        forces[:, :, 2] = 30.
        for _ in range(250):
            result = dynamics.intrinsic_dynamics(
                actions, command, foot_forces_xyz=forces)
        self.assertEqual((dynamics.jump_reflex.landing_events > 0).tolist(),
                         [False, True, True, False])
        self.assertTrue((dynamics.jump_reflex.state == dynamics.jump_reflex.IDLE).all())
        self.assertEqual(dynamics.controller_observations().shape, (4, 46))
        self.assertTrue(torch.isfinite(torch.stack(result, -1)).all())


if __name__ == '__main__':
    unittest.main()

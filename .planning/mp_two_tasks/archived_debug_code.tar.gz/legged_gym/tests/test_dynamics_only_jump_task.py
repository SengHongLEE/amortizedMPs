"""Contract checks for the opt-in four-gait reflex training pipeline."""
import unittest

from isaacgym import gymapi  # noqa: F401; before torch.
import torch

from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg
from legged_gym.envs.a1.mp_full_dynamics_jump import (
    DynamicsJumpMotorPrimitives, DynamicsJumpMotorPrimitivesCfg,
    forward_discontinuity_mask,
    reflex_trigger_alignment)
from legged_gym.scripts.train_mp_full_dynamics_jump import (
    transfer_gait_policy, prefer_starting_gait, freeze_modulation_learning)


class DynamicsJumpTaskTests(unittest.TestCase):
    def test_reflex_alignment_is_routed_to_continuous_policy_reward(self):
        cfg = DynamicsJumpMotorPrimitivesCfg()
        self.assertIn('reflex_trigger_alignment',
                      cfg.rewards.modulation_param_rewards)
        self.assertEqual(cfg.rewards.scales.reflex_trigger_alignment, 0.)
        self.assertNotIn('reflex_trigger_alignment',
                         cfg.rewards.primitive_selection_rewards)

    def test_reflex_alignment_reward_consumes_detector_pulses(self):
        class Detector:
            def __init__(self):
                self.calls = 0

            def consume_trigger_counts(self):
                self.calls += 1
                return torch.tensor([[1, 0], [1, 0]]), torch.tensor([[1, 0], [1, 0]])

        detector = Detector()
        fake_env = type('RewardEnv', (), {})()
        fake_env.ID = type('Controller', (), {'jump_detector': detector})()
        fake_env.ID.consume_launch_counts = lambda: torch.tensor([[0, 0], [1, 0]])
        fake_env.terrain_types = torch.tensor([0, 1])
        fake_env._gap_columns = torch.tensor([False, True])
        fake_env._hurdle_columns = torch.tensor([False, False])
        fake_env.measured_heights = torch.zeros(2, 12, 5)
        fake_env.measured_heights[1, 6:8] = -.6
        fake_env.measured_heights = fake_env.measured_heights.reshape(2, 60)
        reward = DynamicsJumpMotorPrimitives._reward_reflex_trigger_alignment(
            fake_env)
        self.assertEqual(reward.tolist(), [-2., 1.])
        self.assertEqual(detector.calls, 1)

    def test_accepted_prep_without_launch_is_not_rewarded(self):
        class Detector:
            def consume_trigger_counts(self):
                pulse = torch.tensor([[0, 1]])
                return pulse, pulse

        fake_env = type('RewardEnv', (), {})()
        fake_env.ID = type('Controller', (), {'jump_detector': Detector()})()
        fake_env.ID.consume_launch_counts = lambda: torch.zeros(1, 2, dtype=torch.long)
        fake_env.terrain_types = torch.tensor([0])
        fake_env._gap_columns = torch.tensor([False])
        fake_env._hurdle_columns = torch.tensor([True])
        fake_env.measured_heights = torch.zeros(1, 12, 5)
        fake_env.measured_heights[0, 11] = .12
        fake_env.measured_heights = fake_env.measured_heights.reshape(1, 60)
        reward = DynamicsJumpMotorPrimitives._reward_reflex_trigger_alignment(
            fake_env)
        self.assertEqual(reward.tolist(), [0.])

    def test_actor_critic_and_action_contract_match_mp_full(self):
        base = MotorPrimitivesCfg()
        jump = DynamicsJumpMotorPrimitivesCfg()
        for name in ('num_observations', 'num_privileged_obs',
                     'num_actions', 'num_modulation_params',
                     'num_controller_observations', 'num_primitives'):
            self.assertEqual(getattr(jump.env, name), getattr(base.env, name))
        self.assertEqual(jump.env.num_primitives, 4)

    def test_five_gait_warmstart_keeps_first_four_outputs(self):
        source = {
            'actor.readout.output_head.weight': torch.arange(15.).reshape(5, 3),
            'actor.readout.output_head.bias': torch.arange(5.),
            'std': torch.arange(10.),
            'critic.0.bias': torch.ones(2),
        }
        target = {
            'actor.readout.output_head.weight': torch.zeros(4, 3),
            'actor.readout.output_head.bias': torch.zeros(4),
            'std': torch.zeros(8),
            'critic.0.bias': torch.zeros(2),
        }
        copied = transfer_gait_policy(source, target)
        self.assertTrue(torch.equal(copied['actor.readout.output_head.weight'],
                                    source['actor.readout.output_head.weight'][:4]))
        self.assertTrue(torch.equal(copied['actor.readout.output_head.bias'],
                                    source['actor.readout.output_head.bias'][:4]))
        self.assertTrue(torch.equal(copied['std'], source['std'][:8]))
        self.assertTrue(torch.equal(copied['critic.0.bias'], source['critic.0.bias']))

    def test_warmstart_expands_reservoir_readout_with_zero_direct_input(self):
        old = torch.arange(64.).reshape(2, 32)
        source = {
            'actor.readout.linear_layers.0.weight': old,
            'actor.readout.soft_attn.attn.0.weight': old.clone(),
            'actor.readout.soft_attn.attn.2.weight': old.T.clone(),
            'actor.readout.soft_attn.attn.2.bias': torch.arange(32.),
        }
        target = {
            'actor.readout.linear_layers.0.weight': torch.zeros(2, 194),
            'actor.readout.soft_attn.attn.0.weight': torch.zeros(2, 194),
            'actor.readout.soft_attn.attn.2.weight': torch.zeros(194, 2),
            'actor.readout.soft_attn.attn.2.bias': torch.zeros(194),
        }
        copied = transfer_gait_policy(source, target)
        for name in ('actor.readout.linear_layers.0.weight',
                     'actor.readout.soft_attn.attn.0.weight'):
            self.assertTrue(torch.equal(copied[name][:, -32:], old))
            self.assertTrue(torch.equal(copied[name][:, :-32],
                                        torch.zeros(2, 162)))
        self.assertTrue(torch.equal(
            copied['actor.readout.soft_attn.attn.2.weight'][-32:], old.T))
        self.assertTrue(torch.equal(
            copied['actor.readout.soft_attn.attn.2.bias'][-32:],
            torch.arange(32.)))

    def test_preferred_gait_initialization_only_changes_one_logit_bias(self):
        state = {
            'actor.readout.output_head.weight': torch.ones(4, 3),
            'actor.readout.output_head.bias': torch.tensor([-.1, -.2, -.1, .1]),
        }
        seeded = prefer_starting_gait(state, 2, margin=1.)
        self.assertTrue(torch.allclose(
            seeded['actor.readout.output_head.bias'],
            torch.tensor([-.1, -.2, 1.1, .1])))
        self.assertTrue(torch.equal(seeded['actor.readout.output_head.weight'],
                                    state['actor.readout.output_head.weight']))
        self.assertAlmostEqual(state['actor.readout.output_head.bias'][2].item(), -.1)

    def test_freeze_modulation_learning_preserves_weights_on_optimizer_step(self):
        parameter = torch.nn.Parameter(torch.tensor(1.))
        optimizer = torch.optim.Adam([parameter], lr=.01)
        algorithm = type('Algorithm', (), {})()
        algorithm.optimizer = optimizer
        algorithm.learning_rate = .01
        algorithm.schedule = 'adaptive'
        freeze_modulation_learning(algorithm)
        (parameter * 2).backward()
        optimizer.step()
        self.assertEqual(parameter.item(), 1.)
        self.assertEqual(algorithm.schedule, 'fixed')

    def test_forward_discontinuity_detects_gap_and_hurdle_but_not_slope(self):
        samples = torch.zeros(4, 12, 5)
        samples[1, 6:8] = -.6
        samples[2, 8:10] = .10
        samples[3] = torch.linspace(0., .11, 12)[:, None]
        self.assertEqual(forward_discontinuity_mask(
            samples.reshape(4, 60)).tolist(), [False, True, True, False])

    def test_alignment_rewards_correct_event_and_penalizes_flat_trigger(self):
        heights = torch.zeros(3, 12, 5)
        heights[1, 6:8] = -.6
        heights[2, 6:8] = .12
        raw = torch.tensor([[1, 0], [1, 0], [0, 1]])
        accepted = raw.clone()
        reward = reflex_trigger_alignment(
            raw, accepted, heights.reshape(3, 60),
            terrain_is_gap=torch.tensor([False, True, False]),
            terrain_is_hurdle=torch.tensor([False, False, True]))
        self.assertEqual(reward.tolist(), [-2., 1., 1.])

    def test_alignment_penalizes_wrong_hazard_and_late_event(self):
        heights = torch.zeros(2, 12, 5)
        heights[0, 6:8] = -.6
        heights[1, 1:3] = -.6
        raw = torch.tensor([[0, 1], [1, 0]])
        accepted = raw.clone()
        reward = reflex_trigger_alignment(
            raw, accepted, heights.reshape(2, 60),
            terrain_is_gap=torch.ones(2, dtype=torch.bool),
            terrain_is_hurdle=torch.zeros(2, dtype=torch.bool))
        self.assertEqual(reward.tolist(), [-2., -2.])

    def test_alignment_accepts_early_hurdle_prep_but_not_early_gap(self):
        heights = torch.zeros(2, 12, 5)
        heights[0, 11] = .12
        heights[1, 11] = -.6
        raw = torch.tensor([[0, 1], [1, 0]])
        reward = reflex_trigger_alignment(
            raw, raw, heights.reshape(2, 60),
            terrain_is_gap=torch.tensor([False, True]),
            terrain_is_hurdle=torch.tensor([True, False]))
        self.assertEqual(reward.tolist(), [1., -2.])


if __name__ == '__main__':
    unittest.main()

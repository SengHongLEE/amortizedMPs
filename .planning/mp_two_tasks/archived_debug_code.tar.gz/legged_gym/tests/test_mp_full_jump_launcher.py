"""The isolated jump trainer exposes a runnable command-line entry point."""
from pathlib import Path
import subprocess
import sys
import unittest


SCRIPT = (Path(__file__).resolve().parents[1]
          / 'legged_gym/scripts/train_mp_full_jump.py')


class JumpLauncherTests(unittest.TestCase):
    def test_help_exits_without_constructing_a_simulator(self):
        result = subprocess.run(
            [sys.executable, str(SCRIPT), '--help'],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        self.assertEqual(result.returncode, 0, result.stdout[-1500:])
        self.assertIn('--max_iterations', result.stdout)
        self.assertIn('--num_envs', result.stdout)


if __name__ == '__main__':
    unittest.main()

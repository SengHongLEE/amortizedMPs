"""Contracts for the isolated contact-triggered jump experiment."""
import importlib.util
from pathlib import Path
import unittest

import torch


PATH = (Path(__file__).resolve().parents[1]
        / 'legged_gym/utils/dynamics/a1/contact_jump_reflex_probe.py')
spec = importlib.util.spec_from_file_location('contact_jump_reflex_probe', PATH)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
ContactJumpReflex = module.ContactJumpReflex


class ContactJumpReflexTests(unittest.TestCase):
    def test_contact_and_hind_stance_trigger_one_jump_then_landing(self):
        jump = ContactJumpReflex(num_envs=2, device='cpu', dt=.001)
        base = torch.full((2, 4), -.30)
        support = torch.tensor([[20., 0., 20., 0.], [20., 0., 20., 0.]])
        no_contact = torch.zeros_like(support)
        stance_phase = torch.full((2, 4), 1.2 * torch.pi)
        swing_phase = torch.full((2, 4), .2 * torch.pi)
        jump.arm(torch.tensor([True, False]))

        for _ in range(8):
            jump.step(base, support, swing_phase)
        self.assertEqual(jump.state.tolist(), [jump.ARMED, jump.IDLE])
        for _ in range(8):
            jump.step(base, support, stance_phase)
        self.assertEqual(jump.state.tolist(), [jump.PRELOAD, jump.IDLE])

        for _ in range(60):
            z = jump.step(base, support, stance_phase)
        self.assertEqual(jump.state[0].item(), jump.PUSH)
        self.assertGreater(z[0].mean().item(), -.30)
        for _ in range(105):
            z = jump.step(base, support, stance_phase)
        self.assertLess(z[0].mean().item(), -.30)
        self.assertEqual(jump.flight_events[0].item(), 0)

        for _ in range(5):
            jump.step(base, no_contact, swing_phase)
        self.assertEqual(jump.state[0].item(), jump.FLIGHT)
        self.assertEqual(jump.flight_events[0].item(), 1)
        for _ in range(90):
            z = jump.step(base, no_contact, swing_phase)
        self.assertGreater(z[0].mean().item(), -.30)
        for _ in range(5):
            jump.step(base, support, stance_phase)
        self.assertEqual(jump.state[0].item(), jump.RECOVER)
        for _ in range(130):
            jump.step(base, support, stance_phase)
        self.assertEqual(jump.state.tolist(), [jump.IDLE, jump.IDLE])
        self.assertEqual(jump.completed.tolist(), [True, False])
        self.assertEqual(jump.landing_events[0].item(), 1)
        jump.arm(torch.tensor([True, False]))
        self.assertEqual(jump.state[0].item(), jump.IDLE)

    def test_no_support_does_not_launch_and_partial_reset_rearms(self):
        jump = ContactJumpReflex(num_envs=2, device='cpu', dt=.001)
        base = torch.full((2, 4), -.30)
        phase = torch.full((2, 4), 1.2 * torch.pi)
        jump.arm(torch.tensor([True, True]))
        for _ in range(12):
            actual = jump.step(base, torch.zeros(2, 4), phase)
        torch.testing.assert_close(actual, base)
        self.assertEqual(jump.state.tolist(), [jump.ARMED, jump.ARMED])
        jump.completed[0] = True
        jump.reset(torch.tensor([0]))
        self.assertFalse(jump.completed[0].item())
        self.assertEqual(jump.state.tolist(), [jump.IDLE, jump.ARMED])


if __name__ == '__main__':
    unittest.main()

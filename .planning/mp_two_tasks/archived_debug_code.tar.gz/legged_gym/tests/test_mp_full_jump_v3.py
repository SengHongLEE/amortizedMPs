"""The isolated V3 dynamics exposes the existing continuous action head."""
import unittest

from isaacgym import gymapi  # noqa: F401; before torch.
import torch

from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg
from legged_gym.utils.dynamics.a1.jump_dynamics_v3 import (
    JumpAdaptiveEquilibriumDynamicsV3)


class JumpDynamicsV3Tests(unittest.TestCase):
    def test_six_grouped_controls_use_existing_eighteen_actions(self):
        actions = torch.zeros(2, 19)
        actions[:, 1:5] = torch.tensor([[1.], [-1.]])
        actions[:, 5:9] = torch.tensor([[.5], [-.5]])
        actions[:, 9:13] = torch.tensor([[.25], [-.25]])
        actions[:, 13:17] = torch.tensor([[.75], [-.75]])
        actions[:, 17] = torch.tensor([.4, -.4])
        actions[:, 18] = torch.tensor([.6, -.6])
        expected = torch.tensor([[1., .5, .25, .75, .4, .6],
                                 [-1., -.5, -.25, -.75, -.4, -.6]])
        torch.testing.assert_close(
            JumpAdaptiveEquilibriumDynamicsV3.jump_modulation(actions),
            expected)

    def test_jump_keeps_the_current_support_gait(self):
        actions = torch.zeros(3, 19)
        actions[:, 0] = torch.tensor([4., 4., 2.])
        previous = torch.tensor([2, 3, 1])
        support = JumpAdaptiveEquilibriumDynamicsV3.support_actions(
            actions, previous)
        self.assertEqual(support[:, 0].tolist(), [2., 3., 2.])
        self.assertEqual(actions[:, 0].tolist(), [4., 4., 2.])


if __name__ == '__main__':
    unittest.main()

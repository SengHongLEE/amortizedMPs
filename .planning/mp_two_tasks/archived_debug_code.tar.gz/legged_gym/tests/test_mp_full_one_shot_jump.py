"""The default MP_full jump is a latched event over the four existing gaits."""
import unittest

from isaacgym import gymapi  # noqa: F401; Isaac Gym must load before torch.
import torch

from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg
from legged_gym.utils.dynamics.a1.equilibrium_dynamics import AdaptiveEquilibriumDynamics
from legged_gym.utils.dynamics.a1.one_shot_jump_dynamics import OneShotJumpDynamics


class OneShotJumpDynamicsTests(unittest.TestCase):
    def make(self, cls=OneShotJumpDynamics):
        cfg = MotorPrimitivesCfg()
        return cls(timing_cfg=cfg.control.timing,
                   equilibrium_cfg=cfg.control.equilibrium,
                   num_envs=2, device='cpu', time_step=.001,
                   nominal_clearance=.15, max_clearance=.20)

    def test_four_gaits_keep_the_original_foot_targets(self):
        jump, ordinary = self.make(), self.make(AdaptiveEquilibriumDynamics)
        actions = torch.zeros(2, 19)
        actions[:, 0] = torch.tensor([1., 2.])
        command = torch.tensor([[1.2, 0., 0.]]).repeat(2, 1)
        for _ in range(12):
            expected = ordinary.intrinsic_dynamics(actions, command)
            actual = jump.intrinsic_dynamics(actions, command)
            for got, want in zip(actual, expected):
                torch.testing.assert_close(got, want)

    def test_jump_request_latches_and_survives_policy_switch(self):
        controller = self.make()
        actions = torch.zeros(2, 19)
        actions[:, 0] = 2.
        command = torch.zeros(2, 3)
        contact = torch.full((2, 4), 20.)
        controller.intrinsic_dynamics(actions, command, contact_forces=contact)
        actions[0, 0] = 4.
        controller.intrinsic_dynamics(actions, command, contact_forces=contact)
        self.assertEqual(controller.jump_reflex.state[0].item(), controller.jump_reflex.ARMED)
        self.assertEqual(controller._gait_ids[0].item(), 2)
        actions[0, 0] = 1.
        for _ in range(8):
            controller.intrinsic_dynamics(actions, command, contact_forces=contact)
        self.assertIn(controller.jump_reflex.state[0].item(),
                      (controller.jump_reflex.PRELOAD, controller.jump_reflex.PUSH))
        self.assertEqual(controller.jump_reflex.state[1].item(), controller.jump_reflex.IDLE)
        self.assertEqual(controller.consume_jump_events()['request'].tolist(), [1, 0])
        self.assertEqual(controller.consume_jump_events()['request'].tolist(), [0, 0])

    def test_repeated_jump_selection_needs_release_and_reset_clears_state(self):
        controller = self.make()
        actions = torch.zeros(2, 19)
        actions[0, 0] = 4.
        command = torch.zeros(2, 3)
        contact = torch.full((2, 4), 20.)
        for _ in range(10):
            controller.intrinsic_dynamics(actions, command, contact_forces=contact)
        self.assertEqual(controller.consume_jump_events()['request'].tolist(), [1, 0])
        controller.reset(torch.tensor([0]))
        self.assertEqual(controller.jump_reflex.state[0].item(), controller.jump_reflex.IDLE)
        self.assertEqual(controller.controller_observations().shape, (2, 52))
        controller.intrinsic_dynamics(actions, command, contact_forces=contact)
        self.assertEqual(controller.consume_jump_events()['request'].tolist(), [1, 0])


if __name__ == '__main__':
    unittest.main()

"""Contracts for replacing pronk with a contact-triggered jump primitive."""
import unittest

from isaacgym import gymapi  # noqa: F401; Isaac Gym loads before torch.
import torch

from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg
from legged_gym.utils.dynamics.a1.equilibrium_dynamics import AdaptiveEquilibriumDynamics
from legged_gym.utils.dynamics.a1.jump_dynamics import JumpAdaptiveEquilibriumDynamics


class JumpDynamicsTests(unittest.TestCase):
    def make(self, num_envs=2):
        cfg = MotorPrimitivesCfg()
        return JumpAdaptiveEquilibriumDynamics(
            timing_cfg=cfg.control.timing,
            equilibrium_cfg=cfg.control.equilibrium,
            num_envs=num_envs, device='cpu',
            nominal_clearance=cfg.asset.ground_clearance,
            max_clearance=cfg.asset.max_ground_clearance)

    def test_fifth_primitive_is_jump_and_other_gaits_keep_their_library_values(self):
        jump = self.make()
        old = AdaptiveEquilibriumDynamics(
            timing_cfg=MotorPrimitivesCfg.control.timing,
            equilibrium_cfg=MotorPrimitivesCfg.control.equilibrium,
            num_envs=2, device='cpu')
        self.assertEqual(jump.primitive_names, ('walk', 'trot', 'canter', 'bound', 'jump'))
        torch.testing.assert_close(jump._primitive_phases[:4], old._primitive_phases[:4])
        torch.testing.assert_close(jump._primitive_duty_factors[:4], old._primitive_duty_factors[:4])
        torch.testing.assert_close(jump._primitive_frequencies[:4], old._primitive_frequencies[:4])
        jump._gait_ids[:] = 4
        jump.X[:, 2] = 1.25 * torch.pi
        jump.X[:, 1] = jump.mu_up
        old._gait_ids[:] = 4
        old.X[:, 2] = 1.25 * torch.pi
        old.X[:, 1] = old.mu_up
        command = torch.zeros(2, 3)
        ordinary = jump._foot_trajectory(command, jump._vertical_phase())[2]
        pronk = old._foot_trajectory(command, old._vertical_phase())[2]
        self.assertFalse(torch.allclose(ordinary, pronk))

    def test_jump_selection_arms_contact_reflex_and_requires_reselection(self):
        jump = self.make()
        jump.oscillator = lambda: None
        jump.X[:, 2] = 1.3 * torch.pi
        actions = torch.zeros(2, 19)
        actions[0, 0] = 4
        command = torch.zeros(2, 3)
        no_contact = torch.zeros(2, 4)
        support = torch.tensor([[15., 0., 15., 0.], [15., 0., 15., 0.]])

        for _ in range(10):
            jump.intrinsic_dynamics(actions, command, contact_forces=no_contact)
        self.assertEqual(jump.jump_reflex.state.tolist(), [jump.jump_reflex.ARMED,
                                                            jump.jump_reflex.IDLE])
        for _ in range(10):
            jump.intrinsic_dynamics(actions, command, contact_forces=support)
        self.assertEqual(jump.jump_reflex.launch_events.tolist(), [1, 0])
        for _ in range(600):
            jump.intrinsic_dynamics(actions, command, contact_forces=support)
        self.assertTrue(jump.jump_reflex.completed[0].item())
        self.assertEqual(jump.jump_reflex.launch_events[0].item(), 1)

        actions[0, 0] = 1
        jump.intrinsic_dynamics(actions, command, contact_forces=support)
        actions[0, 0] = 4
        for _ in range(10):
            jump.intrinsic_dynamics(actions, command, contact_forces=support)
        self.assertEqual(jump.jump_reflex.launch_events[0].item(), 2)

    def test_reset_clears_only_selected_environment_jump_state(self):
        jump = self.make()
        jump.jump_reflex.arm(torch.tensor([True, True]))
        jump.reset(torch.tensor([0]))
        self.assertEqual(jump.jump_reflex.state.tolist(), [jump.jump_reflex.IDLE,
                                                            jump.jump_reflex.ARMED])


if __name__ == '__main__':
    unittest.main()

"""Offline selector distillation consumes only the actor's saved observations."""
import unittest

from isaacgym import gymapi  # noqa: F401; before torch.
import numpy as np
import torch

from legged_gym.scripts.train_observation_gait_selector import (
    build_training_examples, flatten_observed_height_edges,
    expand_reservoir_projection,
)


class SelectorExampleTests(unittest.TestCase):
    def test_samples_decision_history_and_sensor_targets_only_while_active(self):
        observations = np.zeros((10, 2, 162), dtype=np.float32)
        observations[4, 1, -60:].reshape(12, 5)[8:, :] = 3.
        active = np.ones((10, 2), dtype=bool)
        active[9, 1] = False
        histories, targets, env_ids = build_training_examples(
            observations, active, max_distance=1.25, decision_stride=5)
        self.assertEqual(histories.shape, (3, 5, 162))
        self.assertEqual(targets.tolist(), [3, 2, 3])
        self.assertEqual(env_ids.tolist(), [0, 1, 0])
        self.assertTrue(np.array_equal(histories[1, -1], observations[4, 1]))

    def test_counterfactual_removes_only_height_edges(self):
        observations = np.zeros((2, 5, 162), dtype=np.float32)
        observations[:, :, 20] = 7.
        heights = observations[:, :, -60:].reshape(2, 5, 12, 5)
        heights[:, :, 4:, :] = -.6
        flattened = flatten_observed_height_edges(observations)
        self.assertTrue(np.all(flattened[:, :, 20] == 7.))
        self.assertTrue(np.all(flattened[:, :, -60:] == 0.))
        self.assertTrue(np.any(observations[:, :, -60:] != 0.))

    def test_encoder_warmstart_preserves_existing_reservoir_inputs(self):
        source = {'actor.reservoir.w_in': torch.arange(6.).reshape(2, 3),
                  'actor.readout.bias': torch.tensor([1.])}
        target = {'actor.reservoir.w_in': torch.ones(2, 5),
                  'actor.readout.bias': torch.zeros(1)}
        expanded = expand_reservoir_projection(source, target, extra_dim=2)
        self.assertTrue(torch.equal(expanded['actor.reservoir.w_in'][:, :3],
                                    source['actor.reservoir.w_in']))
        self.assertTrue(torch.equal(expanded['actor.reservoir.w_in'][:, 3:],
                                    torch.ones(2, 2)))
        self.assertTrue(torch.equal(expanded['actor.readout.bias'],
                                    source['actor.readout.bias']))


if __name__ == '__main__':
    unittest.main()

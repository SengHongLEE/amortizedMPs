"""Reward and registration contracts for the independent signed-dense experiment."""
import math
import unittest

from isaacgym import gymapi  # noqa: F401; load Isaac Gym before torch.
import torch

import legged_gym.envs  # noqa: F401; register tasks.
from legged_gym.envs.a1.mp_full import MotorPrimitives as OriginalMotorPrimitives
from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg
from legged_gym.envs.a1.mp_full_obstacle_aware import (
    ObstacleAwareMotorPrimitives, obstacle_approach_gate)
from legged_gym.utils.task_registry import task_registry


class ObstacleAwareRewardTests(unittest.TestCase):
    def make_env(self, targets=(float('inf'),), x=4., velocity=1.4, command=1.):
        env = ObstacleAwareMotorPrimitives.__new__(ObstacleAwareMotorPrimitives)
        env.cfg, _ = task_registry.get_cfgs('MP_full_signed_dense_obstacle_aware_a1')
        env.num_envs, env.device, env.dt = 1, 'cpu', .02
        env.terrain_types = torch.zeros(1, dtype=torch.long)
        env._obstacle_clear_targets = torch.tensor([targets])
        env.root_states = torch.zeros(1, 13)
        env.root_states[:, 0] = x
        env.base_lin_vel = torch.tensor([[velocity, 0., 0.]])
        env.commands = torch.tensor([[command, 0., 0.]])
        env.last_base_pos = torch.tensor([x - velocity * env.dt])
        env._dense_lower_heights = torch.zeros(1, 4)
        env._dense_upper_heights = torch.zeros(1, 4)
        return env

    def test_gate_approaches_and_recovers_smoothly(self):
        x = torch.tensor([3.35, 4.8, 5.25, 5.8, 6.05, 4.8])
        targets = torch.tensor([[5.55], [5.55], [5.55], [5.55],
                                [5.55], [float('inf')]])
        gate = obstacle_approach_gate(x, targets, 2.2, .75, .5)
        torch.testing.assert_close(gate, torch.tensor([0., 1., 1., .5, 0., 0.]))
        self.assertTrue(torch.isfinite(gate).all())

    def test_flat_tracking_matches_original_and_progress_is_off(self):
        env = self.make_env()
        expected = math.exp(-(.4 ** 2) / env.cfg.rewards.tracking_sigma)
        self.assertAlmostEqual(env._reward_tracking_lin_vel().item(), expected, places=6)
        torch.testing.assert_close(
            env._reward_tracking_lin_vel(),
            OriginalMotorPrimitives._reward_tracking_lin_vel(env))
        torch.testing.assert_close(env._reward_locomotion_distance(), torch.zeros(1))

    def test_slope_or_ramp_geometry_activates_capped_progress_without_speed_slack(self):
        env = self.make_env(velocity=.7, command=1.)
        self.assertAlmostEqual(env._obstacle_reward_gate().item(), 0.)
        env._dense_upper_heights[:] = torch.tensor([[0., .05, .1, .15]])
        self.assertAlmostEqual(env._reward_locomotion_distance().item(), .7, places=5)
        torch.testing.assert_close(
            env._reward_tracking_lin_vel(),
            OriginalMotorPrimitives._reward_tracking_lin_vel(env))

    def test_mild_terrain_uses_partial_progress_gate(self):
        env = self.make_env(velocity=.7, command=1.)
        env._dense_upper_heights[:, -1] = .06
        reward = env._reward_locomotion_distance().item()
        self.assertAlmostEqual(reward, .7 * 135 / 343, places=5)

    def test_near_obstacle_allows_short_overspeed_and_rewards_progress(self):
        env = self.make_env(targets=(5.55,), x=5.25)
        torch.testing.assert_close(env._reward_tracking_lin_vel(), torch.ones(1))
        torch.testing.assert_close(env._reward_locomotion_distance(), torch.ones(1))
        env.base_lin_vel[:, 0] = .6
        expected = math.exp(-(.15 ** 2) / env.cfg.rewards.tracking_sigma)
        self.assertAlmostEqual(env._reward_tracking_lin_vel().item(), expected, places=6)

    def test_new_task_keeps_signed_dense_observations_and_old_registration(self):
        old_cfg, old_train = task_registry.get_cfgs('MP_full_signed_dense_a1')
        new_cfg, new_train = task_registry.get_cfgs('MP_full_signed_dense_obstacle_aware_a1')
        self.assertIs(task_registry.get_task_class('MP_full_signed_dense_a1'),
                      OriginalMotorPrimitives)
        self.assertIs(task_registry.get_task_class('MP_full_signed_dense_obstacle_aware_a1'),
                      ObstacleAwareMotorPrimitives)
        self.assertEqual(new_cfg.env.num_observations, old_cfg.env.num_observations)
        self.assertEqual(new_cfg.terrain.scan_mode, 'signed_dense')
        self.assertEqual(new_train.policy.terrain_scan_shape, [2, 16, 5])
        self.assertEqual(new_train.policy.terrain_encoder_dim, 32)
        self.assertNotEqual(new_train.runner.experiment_name, old_train.runner.experiment_name)
        self.assertNotEqual(new_train.runner.run_name, old_train.runner.run_name)
        self.assertEqual(old_cfg.rewards.scales.locomotion_distance,
                         MotorPrimitivesCfg.rewards.scales.locomotion_distance)


if __name__ == '__main__':
    unittest.main()

"""Success on a band obstacle requires the rear feet to clear it."""

import importlib.util
from pathlib import Path
import unittest

path = Path(__file__).resolve().parents[1] / 'legged_gym/utils/terrain_evaluation.py'
spec = importlib.util.spec_from_file_location('terrain_evaluation_test', path)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
first_band_clear_distance = module.first_band_clear_distance
second_band_clear_distance = module.second_band_clear_distance
next_tile_second_band_clear_distance = module.next_tile_second_band_clear_distance
resolved_band_width = module.resolved_band_width


class MPFullEvaluationTargetTests(unittest.TestCase):
    def test_first_full_width_gap_requires_body_to_pass_far_edge(self):
        self.assertAlmostEqual(first_band_clear_distance(3.0, 0.4, rear_margin=0.35), 2.25)

    def test_hurdle_uses_its_own_width(self):
        self.assertAlmostEqual(first_band_clear_distance(3.0, 0.2, rear_margin=0.35), 2.05)

    def test_second_band_requires_rear_to_clear_repeated_obstacle(self):
        self.assertAlmostEqual(second_band_clear_distance(3.0, 0.4, 2.0, rear_margin=0.35), 4.25)

    def test_next_tile_target_includes_full_tile_spacing(self):
        self.assertAlmostEqual(next_tile_second_band_clear_distance(
            8.0, 3.0, 0.4, 2.0, rear_margin=0.35), 12.25)

    def test_gap_width_uses_actual_heightfield_cells(self):
        self.assertAlmostEqual(resolved_band_width(0.25, 0.1), 0.2)
        self.assertAlmostEqual(resolved_band_width(0.325, 0.1), 0.3)


if __name__ == '__main__':
    unittest.main()

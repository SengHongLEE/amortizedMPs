"""Jump modulation must change the launched trajectory and remain latched."""
import unittest

from isaacgym import gymapi  # noqa: F401; before torch.
import torch

from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg  # noqa: F401
from legged_gym.utils.dynamics.a1.contact_jump_reflex_v3 import ContactJumpReflexV3


class ContactJumpReflexV3Tests(unittest.TestCase):
    def test_continuous_action_sets_distinct_latched_jump_parameters(self):
        reflex = ContactJumpReflexV3(2, 'cpu', .02)
        reflex.arm(torch.tensor([True, True]))
        x = torch.zeros(2, 4)
        z = torch.full_like(x, -.30)
        contact = torch.tensor([[20., 0., 20., 0.],
                                [20., 0., 20., 0.]])
        low = torch.full((1, 6), -1.)
        high = torch.full((1, 6), 1.)
        modulation = torch.cat((low, high))
        for _ in range(5):
            reflex.step(x, z, contact, modulation)
        self.assertLess(reflex.latched_extension_depth[0].item(),
                        reflex.latched_extension_depth[1].item())
        self.assertLess(reflex.latched_push_stroke[0, 2].item(),
                        reflex.latched_push_stroke[1, 2].item())
        self.assertLess(reflex.latched_landing_x[0, 0].item(),
                        reflex.latched_landing_x[1, 0].item())
        self.assertLess(reflex.latched_deploy_delay[0].item(),
                        reflex.latched_deploy_delay[1].item())
        saved = reflex.latched_extension_depth.clone()
        reflex.step(x, z, contact, -modulation)
        torch.testing.assert_close(reflex.latched_extension_depth, saved)

    def test_unmodulated_jump_is_middle_of_action_range(self):
        reflex = ContactJumpReflexV3(1, 'cpu', .02)
        reflex.arm(torch.tensor([True]))
        x = torch.zeros(1, 4)
        z = torch.full_like(x, -.30)
        reflex.step(x, z, torch.tensor([[20., 0., 20., 0.]]),
                    torch.zeros(1, 6))
        self.assertAlmostEqual(reflex.latched_extension_depth[0].item(), .08)
        self.assertAlmostEqual(reflex.latched_deploy_delay[0].item(), .20)
        self.assertAlmostEqual(reflex.latched_push_time[0].item(), .06)


if __name__ == '__main__':
    unittest.main()

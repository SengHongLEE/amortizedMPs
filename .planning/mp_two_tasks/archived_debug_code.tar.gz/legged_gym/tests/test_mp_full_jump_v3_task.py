"""V3 has its own task marker and cannot alter the default task."""
import unittest

from isaacgym import gymapi  # noqa: F401; before torch.

from legged_gym.envs.a1.mp_full import MotorPrimitives
from legged_gym.envs.a1.mp_full_jump_v3 import (
    JumpMotorPrimitivesV3, JumpMotorPrimitivesV3Cfg,
    register_jump_v3_task)
from legged_gym.utils.dynamics.a1.jump_dynamics_v3 import (
    JumpAdaptiveEquilibriumDynamicsV3)
from legged_gym.utils.task_registry import task_registry


class JumpV3TaskTests(unittest.TestCase):
    def test_registration_keeps_default_task_and_action_space(self):
        original = task_registry.get_task_class('MP_full_a1')
        self.assertIs(original, MotorPrimitives)
        register_jump_v3_task()
        self.assertIs(task_registry.get_task_class('MP_full_a1'), original)
        self.assertIs(task_registry.get_task_class('MP_full_jump_v3_a1'),
                      JumpMotorPrimitivesV3)
        cfg = JumpMotorPrimitivesV3Cfg()
        self.assertEqual(cfg.env.num_actions, 19)
        self.assertEqual(cfg.env.num_modulation_params, 18)
        self.assertEqual(cfg.env.jump_variant, 'contact_reflex_v3_modulated')
        task = JumpMotorPrimitivesV3.__new__(JumpMotorPrimitivesV3)
        task.cfg = cfg
        task._validate_action_config()
        self.assertIs(task._controller_class,
                      JumpAdaptiveEquilibriumDynamicsV3)


if __name__ == '__main__':
    unittest.main()

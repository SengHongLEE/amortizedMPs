"""Flat-only tracking tail and independent training task contracts."""
import math
import unittest

from isaacgym import gymapi  # noqa: F401; import Isaac Gym before torch.
import torch

import legged_gym.envs  # noqa: F401; register tasks.
from legged_gym.envs.a1 import mp_full_obstacle_aware
from legged_gym.utils.task_registry import task_registry


class FlatTrackingRewardTests(unittest.TestCase):
    def make_env(self):
        cls = getattr(mp_full_obstacle_aware, 'FlatTrackingMotorPrimitives', None)
        self.assertIsNotNone(cls)
        env = cls.__new__(cls)
        env.cfg, _ = task_registry.get_cfgs('MP_full_signed_dense_flat_tracking_a1')
        env.num_envs, env.device, env.dt = 4, 'cpu', .02
        env.terrain_types = torch.arange(4)
        env._flat_columns = torch.tensor([True, False, False, False])
        env._obstacle_clear_targets = torch.tensor([
            [float('inf')], [float('inf')], [float('inf')], [5.55]])
        env.root_states = torch.zeros(4, 13)
        env.root_states[:, 0] = 4.
        env.base_lin_vel = torch.tensor([[1.1, 0., 0.]] * 4)
        env.commands = torch.tensor([[1., 0., 0.]] * 4)
        env.last_base_pos = torch.full((4,), 4. - 1.1 * env.dt)
        env._dense_lower_heights = torch.zeros(4, 4)
        env._dense_upper_heights = torch.zeros(4, 4)
        return env

    def test_flat_near_target_is_identical_and_far_error_has_stronger_signal(self):
        env = self.make_env()
        sigma = env.cfg.rewards.tracking_sigma
        transition = env.cfg.rewards.tracking_tail_transition
        self.assertAlmostEqual(env._reward_tracking_lin_vel()[0].item(),
                               math.exp(-.1 ** 2 / sigma), places=6)
        env.base_lin_vel[0, 0] = 2.1
        error = 1.1
        expected = math.exp(-(2 * transition * error - transition ** 2) / sigma)
        reward = env._reward_tracking_lin_vel()[0].item()
        self.assertAlmostEqual(reward, expected, places=6)
        self.assertGreater(reward, math.exp(-error ** 2 / sigma))
        self.assertLessEqual(reward, 1.)

    def test_nonflat_tracking_and_progress_are_unchanged(self):
        env = self.make_env()
        env.base_lin_vel[:, 0] = torch.tensor([2.1, 2.1, 2.1, 2.1])
        actual = env._reward_tracking_lin_vel()
        original = mp_full_obstacle_aware.ObstacleAwareMotorPrimitives._reward_tracking_lin_vel(env)
        torch.testing.assert_close(actual[1:], original[1:])
        torch.testing.assert_close(
            env._reward_locomotion_distance(),
            mp_full_obstacle_aware.ObstacleAwareMotorPrimitives._reward_locomotion_distance(env))

    def test_new_task_preserves_obstacle_aware_config_and_has_separate_run(self):
        cls = getattr(mp_full_obstacle_aware, 'FlatTrackingMotorPrimitives', None)
        self.assertIsNotNone(cls)
        old_cfg, old_train = task_registry.get_cfgs('MP_full_signed_dense_obstacle_aware_a1')
        new_cfg, new_train = task_registry.get_cfgs('MP_full_signed_dense_flat_tracking_a1')
        self.assertIs(task_registry.get_task_class('MP_full_signed_dense_flat_tracking_a1'), cls)
        self.assertEqual(new_cfg.rewards.scales.tracking_lin_vel,
                         old_cfg.rewards.scales.tracking_lin_vel)
        self.assertEqual(new_cfg.rewards.scales.locomotion_distance,
                         old_cfg.rewards.scales.locomotion_distance)
        self.assertEqual(new_cfg.env.num_observations, old_cfg.env.num_observations)
        self.assertNotEqual(new_train.runner.experiment_name, old_train.runner.experiment_name)
        self.assertNotEqual(new_train.runner.run_name, old_train.runner.run_name)


if __name__ == '__main__':
    unittest.main()

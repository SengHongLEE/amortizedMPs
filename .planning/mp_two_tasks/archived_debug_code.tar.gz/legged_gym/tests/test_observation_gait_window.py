"""Sensor-only gait-selection calibration; jump arming remains intrinsic."""
import unittest

from isaacgym import gymapi  # noqa: F401; before torch.
import torch

from legged_gym.scripts.probe_mp_full_dynamics_jump import (
    observation_gait_window, observation_gap_window,
)


class ObservationGaitWindowTests(unittest.TestCase):
    def test_selects_canter_from_gap_or_hurdle_before_edge(self):
        obs = torch.zeros(3, 5, 162)
        heights = obs[:, -1, -60:].reshape(3, 12, 5)
        heights[1, 8:, :] = 3.0  # Gap: ground height falls.
        heights[2, 6:9, :] = -.6  # Hurdle: ground height rises.
        self.assertEqual(observation_gait_window(obs, 1.05).tolist(),
                         [False, True, True])

    def test_ignores_gradual_ramp_and_edges_beyond_window(self):
        obs = torch.zeros(2, 5, 162)
        heights = obs[:, -1, -60:].reshape(2, 12, 5)
        heights[0] = torch.linspace(0, .55, 12)[:, None]
        heights[1, 10:, :] = -.6
        self.assertEqual(observation_gait_window(obs, .85).tolist(),
                         [False, False])

    def test_gap_duty_window_uses_only_ahead_downward_terrain_edges(self):
        obs = torch.zeros(4, 5, 162)
        heights = obs[:, -1, -60:].reshape(4, 12, 5)
        heights[0, 6:, :] = 3.0  # Gap edge at far sample x=.75 m.
        heights[1, 4:6, :] = -.6  # Hurdle back edge also lies in the window.
        heights[2, 11:, :] = 3.0  # Gap beyond a .85 m window.
        heights[3] = torch.linspace(0, .4, 12)[:, None]  # Ramp.
        self.assertEqual(observation_gap_window(obs, .35, .85).tolist(),
                         [True, False, False, False])
        self.assertEqual(observation_gap_window(obs[:, -1], .35, .85).tolist(),
                         [True, False, False, False])

    def test_gap_duty_window_rejects_invalid_shape_or_distance(self):
        with self.assertRaises(ValueError):
            observation_gap_window(torch.zeros(2, 161), .35, .85)
        with self.assertRaises(ValueError):
            observation_gap_window(torch.zeros(2, 5, 162), .85, .35)


if __name__ == '__main__':
    unittest.main()

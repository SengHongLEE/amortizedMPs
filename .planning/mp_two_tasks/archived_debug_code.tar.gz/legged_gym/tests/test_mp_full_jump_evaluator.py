"""The jump evaluator must refuse checkpoints trained with pronk dynamics."""
from pathlib import Path
import subprocess
import sys
import unittest


ROOT = Path(__file__).resolve().parents[2]
SCRIPT = ROOT / 'legged_gym/legged_gym/scripts/evaluate_mp_full_jump.py'
BASELINE = (ROOT / 'legged_gym/logs/A1'
            / '1026_16-15-59_A1MPfull-v3-18D-psF_3.333e+00-mpF_1.667e+01-MF_1e+03-noResume'
            / 'model_30_310.pt')


class JumpEvaluatorTests(unittest.TestCase):
    def test_help_and_wrong_variant_rejection_do_not_start_simulation(self):
        help_result = subprocess.run(
            [sys.executable, str(SCRIPT), '--help'],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        self.assertEqual(help_result.returncode, 0, help_result.stdout[-1200:])
        self.assertIn('--hazard-target', help_result.stdout)
        wrong = subprocess.run(
            [sys.executable, str(SCRIPT), '--checkpoint', str(BASELINE),
             '--output', str(ROOT / 'docs/terrain/jump_evaluator_rejection')],
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        self.assertNotEqual(wrong.returncode, 0)
        self.assertIn('contact_reflex_v1', wrong.stdout)


if __name__ == '__main__':
    unittest.main()

"""V2 jump controller and task isolation contracts."""
import unittest

from isaacgym import gymapi  # noqa: F401; Isaac Gym before torch.
import torch

from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg
from legged_gym.utils.dynamics.a1.jump_dynamics import JumpAdaptiveEquilibriumDynamics
from legged_gym.utils.dynamics.a1.jump_dynamics_v2 import JumpAdaptiveEquilibriumDynamicsV2
from legged_gym.utils.dynamics.a1.contact_jump_reflex_v2 import ContactJumpReflexV2


class JumpDynamicsV2Tests(unittest.TestCase):
    def make(self):
        cfg = MotorPrimitivesCfg()
        return JumpAdaptiveEquilibriumDynamicsV2(
            timing_cfg=cfg.control.timing,
            equilibrium_cfg=cfg.control.equilibrium,
            num_envs=2, device='cpu',
            nominal_clearance=cfg.asset.ground_clearance,
            max_clearance=cfg.asset.max_ground_clearance)

    def test_v2_keeps_library_and_action_interface(self):
        v2 = self.make()
        self.assertEqual(v2.NUM_ACTIONS, 19)
        self.assertEqual(v2.primitive_names,
                         ('walk', 'trot', 'canter', 'bound', 'jump'))
        self.assertIsInstance(v2.jump_reflex, ContactJumpReflexV2)
        old = JumpAdaptiveEquilibriumDynamics(
            timing_cfg=MotorPrimitivesCfg.control.timing,
            equilibrium_cfg=MotorPrimitivesCfg.control.equilibrium,
            num_envs=2, device='cpu')
        torch.testing.assert_close(v2._primitive_phases[:4],
                                   old._primitive_phases[:4])
        torch.testing.assert_close(v2._primitive_frequencies[:4],
                                   old._primitive_frequencies[:4])

    def test_selection_triggers_v2_and_reset_is_per_environment(self):
        v2 = self.make()
        v2.oscillator = lambda: None
        v2.X[:, 2] = 1.3 * torch.pi
        actions = torch.zeros(2, 19)
        actions[0, 0] = 4.
        command = torch.zeros(2, 3)
        forces = torch.tensor([[20., 0., 20., 0.],
                               [20., 0., 20., 0.]])
        for _ in range(70):
            x, y, z = v2.intrinsic_dynamics(
                actions, command, contact_forces=forces)
        self.assertEqual(v2.jump_reflex.launch_events.tolist(), [1, 0])
        self.assertEqual(v2.jump_reflex.state[0].item(), v2.jump_reflex.PUSH)
        self.assertEqual(x.shape, (2, 4))
        self.assertTrue(torch.isfinite(z).all())
        v2.reset(torch.tensor([0]))
        self.assertEqual(v2.jump_reflex.launch_events.tolist(), [0, 0])


if __name__ == '__main__':
    unittest.main()

"""V1 to V2 transfer preserves learned features and neutral new controls."""

import importlib.util
from pathlib import Path
import unittest

import torch


SOURCE = Path(__file__).resolve().parents[1] / 'legged_gym/utils/mp_full_warmstart.py'
spec = importlib.util.spec_from_file_location('mp_full_warmstart', SOURCE)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class WarmstartTests(unittest.TestCase):
    def test_continuous_input_output_and_critic_mapping(self):
        old = {
            'actor.linear_layers.0.weight': torch.arange(158.).reshape(1, 158),
            'actor.output_layer.weight': torch.ones(16, 2),
            'actor.output_layer.bias': torch.ones(16),
            'critic.0.weight': torch.arange(165.).reshape(1, 165),
            'std': torch.ones(16),
        }
        new = {
            'actor.linear_layers.0.weight': torch.empty(1, 166),
            'actor.output_layer.weight': torch.empty(22, 2),
            'actor.output_layer.bias': torch.empty(22),
            'critic.0.weight': torch.empty(1, 173),
            'std': torch.empty(22),
        }
        result = module.transfer_v1_state(old, new, continuous=True)
        actor = result['actor.linear_layers.0.weight'][0]
        torch.testing.assert_close(actor[:51], old['actor.linear_layers.0.weight'][0, :51])
        torch.testing.assert_close(actor[51:57], torch.zeros(6))
        torch.testing.assert_close(actor[57:104], old['actor.linear_layers.0.weight'][0, 51:98])
        torch.testing.assert_close(actor[104:106], torch.zeros(2))
        torch.testing.assert_close(actor[106:], old['actor.linear_layers.0.weight'][0, 98:])
        critic = result['critic.0.weight'][0]
        torch.testing.assert_close(critic[:58], old['critic.0.weight'][0, :58])
        torch.testing.assert_close(critic[58:64], torch.zeros(6))
        torch.testing.assert_close(critic[64:111], old['critic.0.weight'][0, 58:105])
        torch.testing.assert_close(critic[111:113], torch.zeros(2))
        torch.testing.assert_close(critic[113:], old['critic.0.weight'][0, 105:])
        for name in ('actor.output_layer.weight', 'actor.output_layer.bias', 'std'):
            torch.testing.assert_close(result[name][:16], old[name])
            torch.testing.assert_close(result[name][16:], torch.zeros_like(new[name][16:]))

    def test_discrete_reservoir_input_mapping(self):
        old = {'actor.reservoir.w_in': torch.arange(158.).reshape(1, 158),
               'critic.0.weight': torch.arange(165.).reshape(1, 165)}
        new = {'actor.reservoir.w_in': torch.empty(1, 166),
               'critic.0.weight': torch.empty(1, 173)}
        result = module.transfer_v1_state(old, new, continuous=False)
        self.assertEqual(result['actor.reservoir.w_in'][0, 57].item(), 51.)
        self.assertEqual(result['actor.reservoir.w_in'][0, 106].item(), 98.)


if __name__ == '__main__':
    unittest.main()

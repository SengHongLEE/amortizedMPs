"""Behavioral contracts for the contact-triggered sagittal jump transient."""
import unittest

from isaacgym import gymapi  # noqa: F401; Isaac Gym before torch.
import torch

from legged_gym.envs.a1.mp_full_config import MotorPrimitivesCfg  # noqa: F401
from legged_gym.utils.dynamics.a1.contact_jump_reflex_v2 import ContactJumpReflexV2


class ContactJumpReflexV2Tests(unittest.TestCase):
    def make(self, num_envs=2):
        return ContactJumpReflexV2(num_envs, 'cpu', .005, robot_height=.30)

    def test_requires_hind_support_and_remembers_support_feet(self):
        reflex = self.make()
        reflex.arm(torch.tensor([True, True]))
        x = torch.zeros(2, 4)
        z = torch.full_like(x, -.30)
        forces = torch.tensor([[20., 0., 20., 0.],
                               [20., 20., 0., 0.]])
        for _ in range(4):
            reflex.step(x, z, forces)
        self.assertEqual(reflex.state[0].item(), reflex.PRELOAD)
        self.assertEqual(reflex.state[1].item(), reflex.ARMED)
        self.assertEqual(reflex.support_mask[0].tolist(), [True, False, True, False])

    def test_pushes_support_feet_rearward_and_retracts_free_feet(self):
        reflex = self.make(1)
        reflex.arm(torch.tensor([True]))
        x = torch.zeros(1, 4)
        z = torch.full_like(x, -.30)
        forces = torch.tensor([[20., 0., 20., 0.]])
        for _ in range(22):
            out_x, out_z = reflex.step(x, z, forces)
        self.assertEqual(reflex.state[0].item(), reflex.PUSH)
        self.assertLess(out_x[0, 0].item(), -.01)
        self.assertLess(out_x[0, 2].item(), -.01)
        self.assertGreater(out_z[0, 1].item(), -.25)
        self.assertGreater(out_z[0, 3].item(), -.25)
        self.assertTrue(torch.isfinite(out_x).all())
        self.assertTrue(torch.isfinite(out_z).all())
        self.assertTrue((out_x.abs() <= .20).all())
        self.assertTrue((out_z >= -.39).all())

    def test_stage_boundaries_are_continuous_and_reset_is_per_environment(self):
        reflex = self.make()
        reflex.arm(torch.tensor([True, True]))
        x = torch.zeros(2, 4)
        z = torch.full_like(x, -.30)
        support = torch.full((2, 4), 20.)
        off = torch.zeros_like(support)
        targets = []
        for i in range(125):
            forces = support if i < 40 or i >= 85 else off
            out_x, out_z = reflex.step(x, z, forces)
            targets.append(torch.stack((out_x[0], out_z[0]), dim=-1).clone())
        target = torch.stack(targets)
        self.assertLess(torch.diff(target, dim=0).abs().max().item(), .03)
        self.assertGreater(reflex.launch_events[0].item(), 0)
        self.assertGreater(reflex.flight_events[0].item(), 0)
        reflex.reset(torch.tensor([0]))
        self.assertEqual(reflex.state[0].item(), reflex.IDLE)
        self.assertEqual(reflex.launch_events[0].item(), 0)
        self.assertGreater(reflex.launch_events[1].item(), 0)

    def test_flight_reaches_forward_to_land_after_initial_tuck(self):
        reflex = self.make(1)
        reflex.state[0] = reflex.FLIGHT
        reflex.flight_start_x[0] = 0.
        reflex.flight_start_z[0] = -.30
        reflex.flight_target_x[0] = .06
        x = torch.zeros(1, 4)
        z = torch.full_like(x, -.30)
        no_contact = torch.zeros_like(x)
        for _ in range(17):
            tuck_x, tuck_z = reflex.step(x, z, no_contact)
        self.assertGreater(tuck_z[0, 0].item(), -.22)
        for _ in range(24):
            land_x, land_z = reflex.step(x, z, no_contact)
        self.assertGreater(land_x[0, 0].item(), .09)
        self.assertLess(land_z[0, 0].item(), -.27)

    def test_live_base_modulation_is_masked_during_push_and_flight(self):
        for state in (ContactJumpReflexV2.PUSH, ContactJumpReflexV2.FLIGHT):
            first = self.make(1)
            second = self.make(1)
            for reflex in (first, second):
                reflex.state[0] = state
                reflex.elapsed[0] = .025
                reflex.support_mask[0] = True
                reflex.push_start_z[0] = -.27
                reflex.flight_start_z[0] = -.35
                reflex.flight_target_x[0] = .06
            base_x = torch.zeros(1, 4)
            base_z = torch.full_like(base_x, -.30)
            contact = torch.full_like(base_x, 20.)
            nominal = first.step(base_x, base_z, contact)
            changed = second.step(base_x + .12, base_z + .08, contact)
            for a, b in zip(nominal, changed):
                torch.testing.assert_close(a, b)

    def test_fresh_support_trigger_waits_for_new_contact_event(self):
        reflex = ContactJumpReflexV2(1, 'cpu', .02,
                                     fresh_support_trigger=True)
        x = torch.zeros(1, 4)
        z = torch.full_like(x, -.30)
        support = torch.tensor([[20., 0., 20., 0.]])
        no_support = torch.zeros_like(support)
        reflex.arm(torch.tensor([True]))
        reflex.step(x, z, support)
        self.assertEqual(reflex.state[0].item(), reflex.ARMED)
        reflex.step(x, z, no_support)
        reflex.step(x, z, support)
        self.assertEqual(reflex.state[0].item(), reflex.PRELOAD)

    def test_landing_can_wait_for_two_support_feet(self):
        reflex = ContactJumpReflexV2(1, 'cpu', .02,
                                     landing_min_contacts=2)
        reflex.state[0] = reflex.FLIGHT
        reflex.elapsed[0] = .08
        x = torch.zeros(1, 4)
        z = torch.full_like(x, -.30)
        reflex.step(x, z, torch.tensor([[20., 0., 0., 0.]]))
        self.assertEqual(reflex.state[0].item(), reflex.FLIGHT)
        reflex.step(x, z, torch.tensor([[20., 0., 20., 0.]]))
        self.assertEqual(reflex.state[0].item(), reflex.RECOVER)


if __name__ == '__main__':
    unittest.main()

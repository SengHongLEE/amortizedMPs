import os
import sys
import unittest
from types import SimpleNamespace

import torch


RSL_RL_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if RSL_RL_ROOT not in sys.path:
    sys.path.insert(0, RSL_RL_ROOT)

from rsl_rl.runners.full_policy_runner import FullPolicyRunner


class RecordingWriter:
    def __init__(self):
        self.scalars = {}

    def add_scalar(self, tag, value, step):
        self.scalars[tag] = (step, float(value))


class FullPolicyTerrainLoggingTest(unittest.TestCase):
    def test_current_assignment_uses_all_envs_once_per_iteration(self):
        runner = FullPolicyRunner.__new__(FullPolicyRunner)
        runner.writer = RecordingWriter()
        runner.env = SimpleNamespace(
            terrain_levels=torch.tensor([0, 1, 2]),
            terrain_types=torch.tensor([0, 1, 0]),
            terrain_difficulties=torch.tensor([[.1, .2], [.5, .6], [.9, 1.]]),
            terrain_curriculum=SimpleNamespace(enabled=True),
        )

        printed = runner._log_curriculum_snapshot(7, 35)

        self.assertIn('Current assigned spawn level (all envs)', printed)
        self.assertIn('Curriculum enabled:', printed)
        self.assertEqual(runner.writer.scalars['Curriculum/assigned_spawn_level_mean_all_envs'], (7, 1.))
        self.assertAlmostEqual(runner.writer.scalars['Curriculum/assigned_difficulty_mean_all_envs'][1],
                               (.1 + .6 + .9) / 3)
        self.assertEqual(runner.writer.scalars['Curriculum/enabled'], (7, 1.))


if __name__ == '__main__':
    unittest.main()
